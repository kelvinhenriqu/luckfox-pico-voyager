#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#______Firmware for VGR_LOAD______

import time
from datetime import datetime
import sys
import os       #OS Commands
import csv      #csv file manipulation
import json     #Json file create
import shutil   #SdCard Management
import gzip     #compress file
from threading import Thread

#Specific Voyager libraries
from Voyager.Settings.Config import Config_Read
from Voyager.Libraries.Battery import Fuel_Gauge 
from Voyager.Libraries.Beacon import BeaconDetector
from Voyager.Bluetooth.Bluetooth_Server import Bluetooth_Server
from Voyager.Version import __version__

#Specific Sensor library
from .FC2311 import FC2311
Sensor = FC2311()  

#General Libraries
Battery = Fuel_Gauge() #Start Fuel Gauge sensor
Battery.Wake()

BeaconDetect = BeaconDetector()

BServer = Bluetooth_Server()
BServer.Config() #Config Bluetooth socket connection server

#Get configurations in config file
Debug = Config_Read().getboolean('General','Debug')
path = Config_Read().get('Directories','Measurements_Path')
UpdatePath = Config_Read().get('Directories','Update_Path')
BoardType = Config_Read().get('General','FullName')
BoardID = Config_Read().get('General','Board_Serial')
Use_Beacons = Config_Read().getboolean('Beacon','Use_Beacons')
TimeToReset = Config_Read().getint('Bluetooth_Service','time_to_erase') #seconds to reset Measurements Array

#Logging setup
from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[Firmware]",clear=True, state=Debug)
log = SL.get_logger()

#Others variables
Running = False;Config = False;Timer = 0
Measurements = []
Beacons = []
filename = "dummy"
start_time = 0
custom_offset = 0 #tare value

def SD_Management(): #Free space in internal memory
    total, used, free = shutil.disk_usage("/")

    T = total // (2**30)
    U = used // (2**30)
    F = free // (2**30)
    
    return T,U,F

def Subtract_date(): #Get measure length
    global start_time
    now_time = datetime.now().strftime('%H:%M:%S') #hour-minute-seconds
    h1, m1, s1 = start_time.split(':')
    d1 = int(h1) * 3600 + int(m1) * 60 + int(s1)

    h2, m2, s2 = now_time.split(':')
    d2 = int(h2) * 3600 + int(m2) * 60 + int(s2)

    return d2-d1

def Json_encode(x=1, **kwargs):  # Json generate
    global BoardID, BoardType
    V1NAME, V1ID, V1UNIT = "LoadForce", "V1", "KG"
    total, used, free = SD_Management()
    
    base_response = {
        1: {"STATUS_PLAY": kwargs.get('RN', 0), "Device_Name": BoardType, "Device_Serial": BoardID, 
            "TOTAL_SPACE": total, "VERSION": str(__version__), "USED_SPACE": used, "AVAILABLE_SPACE": free,
            "Measurements": [{"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT}]},
        
        2: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), 
            "CSV_DATE": kwargs.get('csvdate'), "TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        3: {"TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        4: {"V1": kwargs.get('V1'), "V2": kwargs.get('V2')},
        
        5: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), "CSV_DATE": kwargs.get('csvdate')},
        
        6: {"DELETE_STATUS": kwargs.get('RESULT', "NOK")},
        
        7: {"STATUS": kwargs.get('RESULT', "NOK")},
        
        8: {"BATTERY_PORCENTAGE": kwargs.get('PORCENTAGE')},
        
        9: {"VALOR_1": kwargs.get('Valor1')},
        
        10: {"Measurements": [{"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT}, {"NAME": kwargs.get('V2NAME'), "ID": kwargs.get('V2ID'), "UNIT": kwargs.get('V2UNIT')}]},
        
        11: {},  # Special treatment
        
        12: {"V1": kwargs.get('V1ARRAY'), "BEACONS": kwargs.get('BEACONSARRAY')},
        
        13: {"UPDATE_STATUS": kwargs.get('RESULT', "NOK")},
        
        14: {kwargs.get('MESSAGE', "message"): kwargs.get('RESULT', "NOK")},
    }
    
    if x == 11: #its not a json, just a dictionary
        stamp = kwargs.get('V1STAMP')
        value = kwargs.get('V1VALUE')
        data = {"stamp": stamp, "value": value}
    else:
        data = json.dumps(base_response.get(x, {}))
    
    return data

def File_Compress(file): #create a compressed file and save it
    
    global path
    CSV_Directory = str(path) + str(file) + ".csv"
    log.debug(CSV_Directory)
    GZ_Directory = CSV_Directory + ".gz"
    log.debug(GZ_Directory)

    f_in = open(CSV_Directory)
    f_out = gzip.open(GZ_Directory, 'wt')
    f_out.writelines(f_in)
    f_out.close()
    f_in.close()

def Gen_Final_Json(file): #Send .csv file content over bluetooth
    global path

    File_Compress(file)

    todays_time = datetime.now().strftime('%d%m%y') #day-month-year
    Length = Subtract_date()

    BluetoothData = Json_encode(x=2,csvname=file,csvdate=todays_time,csvlen=Length)
    log.debug(BluetoothData)

    BServer.client_sock.sendall(BluetoothData.encode())

def SaveSD(Value,Beacon,IsFirst): #Save in SdCard
    global filename,start_time,path,BoardID #Product Serial Number  

    if IsFirst == 1: #is first call ?
        timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        CsvTimeStamp = datetime.now().strftime('%d%m%y%H%M%S')
        start_time = datetime.now().strftime('%H:%M:%S') #hour-minute-seconds
        filename = BoardID + CsvTimeStamp #Create the filename, example: 21002020621134600 that means 21002.02/06/21.13:46:00
        Value = "kg"
        Beacon = "Beacons"
        log.info(f"CSV File name: {filename}")
    else:
        TimeNow = datetime.now().strftime('%I%M%S')
        Mili = datetime.now().strftime('%f')
        timestamp = str(TimeNow) + str((round((int(Mili)/10000),0))).replace(".0","")
    
    Directory = str(path) + str(filename) + ".csv"

    try:
        with open(Directory, mode='a') as sensor_readings:
            sensor_write = csv.writer(sensor_readings, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            write_to_log = sensor_write.writerow([timestamp,Beacon,Value]) #write Load Cell Value and Timestamp in sdcard
            return(write_to_log)
    except FileNotFoundError as e:
        log.error(f"measurements folder does not exist, trying to create it")
        os.makedirs(str(path), exist_ok=True)
        with open(Directory, mode='a') as sensor_readings:
            sensor_write = csv.writer(sensor_readings, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            write_to_log = sensor_write.writerow([timestamp,Beacon,Value]) #write Load Cell Value and Timestamp in sdcard
            return(write_to_log)

def ArrayClear():
    global Measurements
    global TimeToReset
    global Beacons
    while True:
        time.sleep(TimeToReset)
        Measurements = []
        Beacons = []

class Treatment:

    def __init__(self):
        global custom_offset
        self.OFFSET = Config_Read().getfloat("General","Offset")
        self.SCALE = Config_Read().getfloat("General","Calibration_Factor")
        self.tare_value = custom_offset

    def Startup(self):
        global Config, custom_offset
        if Config: #if config process is necessary  
            Config = False       
            try:            
                SensorStatus = Sensor.Start()
                if SensorStatus == 0: #Pressure Sensor Test    
                    #Sensor.Tare() #Set Pressure Sensor offset and make it 0
                    for i in range (10):
                        val = Sensor.get_grams()
                    custom_offset = round(val)
                    log.warning(f"Starting with offset = {custom_offset}kg")
                    SaveSD(0,0,1) #Save the fist line of the file  
                    BluetoothData = Json_encode(x=7, RESULT="0") #STATUS 0 - OK
                    log.debug(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    Thread(target=ArrayClear).start() #Clean Measurements Array
                    #print(f"Beacons State = Use_Beacons={Use_Beacons} and BeaconDetect list = {BeaconDetect.read}")
                    if Use_Beacons and BeaconDetect.read != {}: #Only starts the beacon thread if beacons are enabled and at least one beacon were assigned
                        Thread(target=BeaconThread).start() #Start the process to keep reading for beacons data

            except ValueError as e:
                log.error(f"error: {e}")
                BluetoothData = Json_encode(x=7, RESULT="2") #STATUS 2 - SENSOR ERROR
                log.debug(BluetoothData)
                BServer.client_sock.send(BluetoothData.encode())


    def SensorRead(self):
        val = Sensor.get_grams()
        val = round(val)
        self.ValueTreated = val - self.tare_value
        #log.warning(f"value = {self.ValueTreated} kg with raw = {val} and tare = {self.tare_value}")
        return self.ValueTreated
    
    def BeaconRead(self):
        self.BeaconNearby = [] #Clear the list of detected beacons
        BeaconsStatus = BeaconDetect.read() #Read all detected beacons and parse them according to the list provived before

        for key in BeaconsStatus: #Get the detected beacons from the dict and parse it in a array to send to IOS
            SubList = BeaconsStatus[key]
            if SubList[0] == True:
                self.BeaconNearby.append(key)
                log.info(f"{key} Inside field, sending data ({self.BeaconNearby})")
            else:
                log.info(f"{key} Outside field, ignoring")

        self.BeaconTreated = self.BeaconNearby if self.BeaconNearby != [] else ""
        return self.BeaconNearby, self.BeaconTreated

def running():
    global Measurements,Beacons
    
    #-------------------------------- Get time and date -------------------------------
    timenow = datetime.now().strftime('%I:%M:%S.')
    mili = datetime.now().strftime('%f')
    timestamp = str(timenow) + str((round((int(mili)/1000),0))).replace(".0",'')
    
    #-------------------------------- Read sensor data --------------------------------
    Treated = Treatment()
    Treated.Startup()
    
    BeaconNearby,BeaconTreated = Treated.BeaconRead()
    ValueTreated = Treated.SensorRead()
    
    #---------------------------- Parse data in json format ---------------------------
    MeasureArray = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=ValueTreated)
    BeaconsArray = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=BeaconNearby)

    Measurements.append(MeasureArray)
    Beacons.append(BeaconsArray)

    SaveSD(ValueTreated,BeaconTreated,0) #Save Pressure in filename

def VerifyUpdateStatus():
    log_file = Config_Read().get('Update_Process','Log_File_Path')
    suc_bit = Config_Read().get('Update_Process','Success_Update_Message')
    bad_bit = Config_Read().get('Update_Process','Bad_Update_Message')
    try:
        with open(log_file,'r',encoding='utf-8') as file:
            #data = file.readlines()
            data = file.read()
            log.info(data)
            if suc_bit or bad_bit in data:
                if suc_bit in data:
                    return "DONE"  
                elif bad_bit in data:
                    return "ERROR"
                else:
                    return "DOING"
            else:
                log.error("File Corrupted")
                return "ERROR"
    except FileNotFoundError:
        log.error("File not found")
        return "ERROR" 

def BeaconThread(): #Start Beacon Process in the Beacon Library
    BeaconDetect.run()
    log.info("[x] Stopped Beacon Thread")

def handle_bluetooth_data(Bdata):
    global Debug,Running,Config,Timer,Measurements,Beacons,filename,UpdatePath
    
    if len(Bdata) != 0:
        log.info(f"\nReceived command: {Bdata}")
        Timer = 0
        match Bdata:
        
            case "PLAY\n" | "PLAY":   #Start Measure, outdated command
                pass

            case "STOP\n" | "STOP": #Stop Measure
                if Running:
                    log.info("STOP - Stopping measurement")
                    Running = False
                    Config = False
                    BeaconDetect.stop() #Stop beacon reading Thread
                    Gen_Final_Json(filename)

            case "MEASUREMENTS\n" | "MEASUREMENTS":   #Start Measure
                if Running:
                    data = Json_encode(x=12,V1ARRAY=Measurements,BEACONSARRAY=Beacons) 
                    bluetoothdata = str(data)
                    BServer.client_sock.send(bluetoothdata.encode())
                    log.info("MEASUREMENTS - Sending Json for live chart generation")
                    log.debug(bluetoothdata)
                    Measurements=[]
                    Beacons=[]
                    
                else:
                    m = []
                    data = Json_encode(x=12,V1ARRAY=m,BEACONSARRAY=m)
                    bluetoothdata = str(data)
                    try: BServer.client_sock.send(bluetoothdata.encode()) 
                    except: pass
                    log.info("[x] There is no data been recorded, nothing to send")

            case "exit\n" | "exit": #Force Stop program
                log.error("Brute stop")
                sys.exit()

            case "FREESPACE" | "FREESPACE\n": #send available space in SdCard
                BluetoothData = Json_encode(x=3)
                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode())

            case "CONNECT" | "CONNECT\n": #CONNECT return
                if Running:
                    BluetoothData = Json_encode(RN=1)
                else:
                    BluetoothData = Json_encode(RN=0)

                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode()) 

            case "BATTERY" | "BATTERY\n": #request battery percentage
                BatteryPorcentage = round(Battery.Read_Percentage()) if Battery.Read_Percentage() <= 100 else 100
                BluetoothData = Json_encode(x=8,PORCENTAGE=BatteryPorcentage)
                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode())

            case _:              #If Receive Unknown Data
                pass

        DIV = Bdata.split(".", 2)

        match DIV[0]:
            
            case "PLAY":
                    x = DIV[1].rstrip("\n")
                    log.info(f"[+] Starting Data collection - adjusting date to {x}")
                    try:
                        if not Running:
                            date = "sudo timedatectl set-time '" + x + "'"
                            if os.system(date) == 0:
                                Config = True
                                Running = True
                            else:
                                log.error("Error occurred while adjusting date")
                                BluetoothData = Json_encode(x=7, RESULT="1") #STATUS 1 - DATE ERROR
                                BServer.client_sock.send(BluetoothData.encode())
                                log.debug(BluetoothData)

                        else:
                            raise Exception("[x] Impossible to adjust date during data collection")
                        
                    except Exception as error:
                        BluetoothData = Json_encode(x=7, RESULT="1")
                        BServer.client_sock.send(BluetoothData.encode())
                        log.critical(f"Unknown error occurred: {error}")
                        pass
                    
            case "DELETE":
                Action = DIV[1].rstrip("\n")
                
                if (Action == "UPDATE"): #if received DELETE.UPDATE the system will delete the update directory and create a new one.
                    if not os.path.exists(UpdatePath):
                        log.info("DELETE.UPDATE - There is no update directory, creating a new one")
                        os.makedirs(UpdatePath)
                        os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                    else:
                        log.info("DELETE.UPDATE - Deleting the update directory")
                        shutil.rmtree(UpdatePath)
                        time.sleep(1)
                        log.info("DELETE.UPDATE - There is no update directory, creating a new one")
                        os.makedirs(UpdatePath)
                        os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                        
                else:
                    log.info(f"DELETE.{Action} - DELETE command received, deleting {Action}.csv")
                    file = str(path) + str(Action) + ".csv"
                    if os.path.isfile(file):
                        os.remove(file) 
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                    else:    ## Show an error ##
                        log.error(f"Error: {filename} not found")
                        BluetoothData = Json_encode(x=6, RESULT="NOK")
                    log.debug(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    
            case "UPDATE":
                Action = DIV[1].rstrip("\n")
                
                match Action:                            
                    
                    case "START":
                        log.info("UPDATE.START - Starting update process . . .")
                        BluetoothData = Json_encode(x=13,RESULT="DOING") #STATUS STARTING - Starting update process
                        BServer.client_sock.send(BluetoothData.encode())

                        from ...Update.Update import Update_firmware
                        Update_firmware()
                        sys.exit()
                
                    case "STATUS":
                        STATUS = VerifyUpdateStatus()
                        log.info(f"UPDATE.STATUS - Update status = {STATUS}")
                        BluetoothData = Json_encode(x=13,RESULT=STATUS) #STATUS DOING - Error in update process
                        BServer.client_sock.send(BluetoothData.encode())
                            
                    case _:
                        log.error("Missing arguments")
                    
            case "BEACON":
                DIV = Bdata.split(".", 3)
                Action = DIV[1]
                
                match Action:  

                    case "APPEND":
                        CommandLength = 4 #expected command need to have 4 arguments
                        try:
                            BeaconName = str(DIV[2])
                            Threshold = str(DIV[3].rstrip("\n"))

                            log.info(f"BEACON.APPEND - Adding {BeaconName}")

                            if BeaconDetect.append(BeaconName,Threshold):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="OK")
                                log.debug(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")
                            
                        except IndexError:
                            log.error(f"Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                        except Exception:
                            log.error(f"Failed to execute Append command")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "DELETE":
                        CommandLength = 3 #expected command need to have 3 arguments
                        try:
                            BeaconName = str(DIV[2].rstrip("\n"))
                            log.info(f"BEACON.DELETE - removing {BeaconName}")

                            if BeaconDetect.delete(BeaconName):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="OK")
                                log.debug(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")

                        except IndexError:
                            log.error(f"Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                            
                        except Exception:
                            log.error(f"Failed to execute Append command")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "CLEAR" | "CLEAR\n":
                        log.info(f"BEACON.CLEAR - cleaning beacon list")

                        if BeaconDetect.clear():
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="OK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                        else:
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "LIST\n" | "LIST":
                        log.info(f"BEACON.LIST - current beacon list {Action}")
                        BluetoothData = str(BeaconDetect.BeaconDict)
                        log.debug(BluetoothData)
                        BServer.client_sock.send(BluetoothData.encode())

    else:
        try:
            log.warning( "[*] No command in the buffer... Waiting command" ) 
            BServer.Startup()              
            Timer = 0
        except Exception as e: 
            log.warning(f"[*] Unknown error - {e}")

            if Running:                        
                try:
                    running()
                except: pass                        
            else:
                time.sleep(1)
                Timer += 1
                os.system("sudo poweroff") if Timer == 1900 else log.debug(f"[*] Waiting for any bluetooth connection ({Timer} - 1900)")
            pass     

def Run():  
    global Timer,Running

    while not BServer.Startup(): #wait for first bluetooth connection
        pass

    while True: #Main loop
        try:                              
            Bdata = BServer.client_sock.recv(1024).decode('utf-8') #Converts Binary data to Decimal with maximum size of 1mb and store in a buffer          
            handle_bluetooth_data(Bdata)
 
        except KeyboardInterrupt:
            log.critical("\nProgram interrupted by user\n")
            exit()

        except (BServer.socket.timeout,ConnectionResetError):
            '''if any connection remains open for more than 5 minutes, the program will close it and restart'''

            if not Running: #if there is no data received and the program is not running, wait for a connection
                time.sleep(1)                

                if Timer == 300: #reset Voyager services if any connection remains open for more than 5 minutes
                    log.critical("[x] disconnecting bluetooth because nothing happened for a long time")
                    BServer.client_sock.close()
                    BServer.server_sock.close()
                    os.system("sudo systemctl restart Voyager.service")
                    sys.exit()
                else:
                    log.debug(f"Connection still open, board will reset soon ({Timer} - 300)")
                    Timer += 1

        finally:
            '''if the program is running, it will keep reading the data from the sensor and saving it in a csv file'''
            if Running:
                BServer.start_countdown = False
                running()
            else:
                BServer.start_countdown = True