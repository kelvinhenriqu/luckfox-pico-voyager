#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Python file to control the update process
#04/09/2023
#61 - Change log file structure - 12/01/2023
#62 - Backup folder is removed after a successful update - 31/01/2024

__VERSION__ = 62

import os
import time


Debug = 1
TimeToWait = 1

Firmware_Filename = "firmware.py" 
Library_filename = ""
BoardType = ""

BackupFolder = "/home/rock/programa/OLD/"
ZipFilename = ""
path_to_zip_file = "/home/rock/programa/update/" + ZipFilename
Path = "/home/rock/" #"/home/rock/programa/"
FirmwareFile = "/home/rock/programa/" + Firmware_Filename
IDDirectory = "/home/rock/programa/Board.ID"

DoneFile = "/home/rock/programa/UpdateDone.txt"
DoingFile = "/home/rock/programa/DoingUpdate.txt"
ErrorFile = "/home/rock/programa/ErrorFile.txt"
UpdateStatusFile = "/home/rock/programa/StatusUpdate.txt"

def debugprint(msg): #debugprint in terminal
    global Debug
    if Debug > 0: print(msg) 

def GetZipName():
    global ZipFilename
    match BoardType:
        case "VIC":
            ZipFilename = "VGR_IMPACT_FIRMWARE.ZIP"
            debugprint(f"Expected zip File: {ZipFilename}")
        case "VPC":
            ZipFilename = "VGR_PRESSURE_FIRMWARE.ZIP"
            debugprint(f"Expected zip File: {ZipFilename}")
        case "VLC":
            ZipFilename = "VGR_LOAD_FIRMWARE.ZIP"
            debugprint(f"Expected zip File: {ZipFilename}")
        case "VFC":
            ZipFilename = "VGR_FORCE_FIRMWARE.ZIP"
            debugprint(f"Expected zip File: {ZipFilename}")
        case _:
            debugprint("Error in GetZipName")
            
def GetLibraryName():
    global Library_filename,IDDirectory,BoardType
    IMPACT = "VIC"
    PRESSURE = "VPC"
    LOAD = "VLC"
    FORCE = "VFC"

    ID = open(IDDirectory, "r").read()
    debugprint(f"Board.ID = {ID}")
    if (IMPACT in ID):
        Library_filename = "Scuffing.py"
        BoardType = IMPACT
        debugprint(f"Voyager type: {IMPACT} - {Library_filename}")
        
    elif (PRESSURE in ID):
        Library_filename = "I2C_SENSOR.py"
        BoardType = PRESSURE
        debugprint(f"Voyager type: {PRESSURE} - {Library_filename}")

    elif (LOAD in ID):
        Library_filename = "FC2311.py"
        BoardType = LOAD
        debugprint(f"Voyager type: {LOAD} - {Library_filename}")    

    elif (FORCE in ID):
        Library_filename = "FC2311.py"
        BoardType = FORCE
        debugprint(f"Voyager type: {FORCE} - {Library_filename}")    

    else:
        debugprint("Missing Board.ID file")    

def ResetUpdateFile():
    global UpdateStatusFile
    if os.path.exists(UpdateStatusFile): 
        debugprint("Creating Log file")
        os.remove(UpdateStatusFile)
    try:
        with open(UpdateStatusFile,'w',encoding='utf-8') as file:
                data = "__StatusUpdate__=Idle"
                file.write(data)
                return True
    except:
        debugprint("impossible to create update status log file")
        return False

def UpdateStatus(Status):
    global UpdateStatusFile

    SearchVar="__StatusUpdate__"    
    try:
        with open(UpdateStatusFile,'r',encoding='utf-8') as file:
            data = file.readlines()
            if SearchVar in data[0]:
                data[0] = "__StatusUpdate__=" + Status + "\n"
                with open(UpdateStatusFile,'w',encoding='utf-8') as file:
                    file.writelines(data)
                    return True
            else:
                debugprint("File Corrupted")
                return False
    except FileNotFoundError:
        debugprint("File not found")
        return False
            
def AppendLogFile(Status,data=""):
    global UpdateStatusFile
    debugprint(data)
    #debugprint(f"Appending {data} to the current log file")

    if not UpdateStatus(Status): return False 

    with open(UpdateStatusFile, 'a') as f:
        f.write("\n")
        f.write(data)  
        return True

def RestartFirmware():
    os.system("sudo /bin/systemctl restart pressurepackage.service")

def StopUpdateService():
    os.system("sudo /bin/systemctl stop updatefirmware.service")

def Shit():
    MESSAGE = "A function returned False"
    if not AppendLogFile("Error",data=MESSAGE): Shit()
    RollBack()

def VerifyFileIntegrity(FilePath):
    with open(FilePath,'r',encoding='utf-8') as file:
            data = file.read().strip()
            if data:
                MESSAGE = "File " + FilePath + " is ok"
                if not AppendLogFile("Doing",data=MESSAGE): Shit()
                return True 
            else:
                MESSAGE = "There is a problem with " + FilePath
                if not AppendLogFile("Error",data=MESSAGE): Shit()
                return False

def RollBack():
    debugprint("entered in RollingBack")

    MESSAGE = "Trying to roll back update"
    if not AppendLogFile("Error",data=MESSAGE): Shit()

    global Firmware_Filename
    global Library_filename
    global BackupFolder

    cmd1 = "sudo mv " + BackupFolder + Firmware_Filename + " " + "/home/rock/programa/" + Firmware_Filename
    cmd2 = "sudo mv " + BackupFolder + Library_filename + " " + "/home/rock/programa/" + Library_filename
    cmd3 = "sudo mv " + BackupFolder + "update.py" + " " + "/home/rock/programa/" + "update.py"
    os.system(cmd1)
    os.system(cmd2)
    os.system(cmd3)

    firmware = "/home/rock/programa/" + Firmware_Filename
    Library = "/home/rock/programa/" + Library_filename
    update = "/home/rock/programa/" + "update.py"

    if not VerifyFileIntegrity(firmware) or not VerifyFileIntegrity(Library) or not VerifyFileIntegrity(update):
        MESSAGE = "One or more files are corrupted, Impossible to Roll back !!!"
        if not AppendLogFile("Error",data=MESSAGE): Shit()
    else:
        MESSAGE = "Update successfully rolled back"
        if not AppendLogFile("Error",data=MESSAGE): Shit()

        MESSAGE = "Removing backup folder"
        if not AppendLogFile("Error",data=MESSAGE): Shit()

        cmd7 = "sudo rm -r " + BackupFolder
        os.system(cmd7)

    RestartFirmware()
    time.sleep(1)
    StopUpdateService()    
    exit()
            
if __name__ == "__main__":  
    GetLibraryName()
    GetZipName()

    path_to_zip_file = "/home/rock/programa/update/" + ZipFilename

    if not ResetUpdateFile(): Shit()

    MESSAGE = "Doing Update, searching for:" + path_to_zip_file
    if not AppendLogFile("Doing",data=MESSAGE): Shit()

    if not os.path.exists(path_to_zip_file):
        MESSAGE = "Update file not found"
        if not AppendLogFile("Error",data=MESSAGE): Shit()
        RollBack()
    else:
        MESSAGE = "Update file found"
        if not AppendLogFile("Doing",data=MESSAGE): Shit()

    MESSAGE = "Killing Voyager Process"
    if not AppendLogFile("Doing",data=MESSAGE): Shit()

    os.system("sudo systemctl stop pressurepackage.service") #kill voyager process
    time.sleep(TimeToWait)
    
    MESSAGE = "Creating backup before update"
    if not AppendLogFile("Doing",data=MESSAGE): Shit()

    if not os.path.exists(BackupFolder):
        os.makedirs(BackupFolder)
        MESSAGE = "Creating backup folder"
        if not AppendLogFile("Doing",data=MESSAGE): Shit()
    else:
        MESSAGE = "Folder already exists, deleting it"
        if not AppendLogFile("Doing",data=MESSAGE): Shit()
        os.system("sudo rm -r "+BackupFolder)

        MESSAGE = "Creating backup folder"
        if not AppendLogFile("Doing",data=MESSAGE): Shit()
        os.makedirs(BackupFolder)
        
    MESSAGE = "Moving files to backup folder"
    if not AppendLogFile("Doing",data=MESSAGE): Shit()

    time.sleep(TimeToWait)   
    
    cmd4 = "sudo mv /home/rock/programa/" + Firmware_Filename + " " + BackupFolder + Firmware_Filename
    cmd5 = "sudo mv /home/rock/programa/" + Library_filename + " " + BackupFolder + Library_filename
    cmd6 = "sudo mv /home/rock/programa/" + "update.py" + " " + BackupFolder + "update.py" 

    os.system(cmd4)
    os.system(cmd5)
    os.system(cmd6)

    MESSAGE = "Files moved successfully to backup folder"
    if not AppendLogFile("Doing",data=MESSAGE): Shit()  

    time.sleep(TimeToWait)   
    
    MESSAGE = "Moving update file and extracting"   
    if not AppendLogFile("Doing",data=MESSAGE): Shit()
    
    if os.path.isfile(path_to_zip_file):
        try:
            cmd7 = "unzip -o " + path_to_zip_file + " -d " + Path
            os.system(cmd7)
            MESSAGE = "File extracted"
            if not AppendLogFile("Doing",data=MESSAGE): Shit()
        except FileNotFoundError:
            MESSAGE = "Failed to extract the file:\n" + path_to_zip_file + " to " + Path
            if not AppendLogFile("Error",data=MESSAGE): Shit()
            RollBack()
    else:
        MESSAGE = "No file found in: " + path_to_zip_file
        if not AppendLogFile("Error",data=MESSAGE): Shit()
        RollBack()
    
    MESSAGE = "Updating . . ."
    if not AppendLogFile("Doing",data=MESSAGE): Shit()
        
    time.sleep(TimeToWait)  
    
    MESSAGE = "Done, Verifying if it is all ok. . ."
    if not AppendLogFile("Doing",data=MESSAGE): Shit()
        
    if not os.path.isfile(FirmwareFile):
        MESSAGE = "Error during update, rolling back\n\n"
        if not AppendLogFile("Error",data=MESSAGE): Shit()
        RollBack()
    else:
        firmware = "/home/rock/programa/" + Firmware_Filename
        Library = "/home/rock/programa/" + Library_filename
        update = "/home/rock/programa/" + "update.py"

        if not VerifyFileIntegrity(firmware) or not VerifyFileIntegrity(Library) or not VerifyFileIntegrity(update):
            MESSAGE = "One or more files are corrupted, rolling update back"
            if not AppendLogFile("Error",data=MESSAGE): Shit()
            RollBack()
        else:
            MESSAGE = "Update Done, Removing backup folder"
            if not AppendLogFile("Error",data=MESSAGE): Shit()
            cmd7 = "sudo rm -r " + BackupFolder
            os.system(cmd7)

            MESSAGE = "Restarting services"
            if not AppendLogFile("Done",data=MESSAGE): Shit()
            RestartFirmware()
            time.sleep(1)
            StopUpdateService()
            exit()
