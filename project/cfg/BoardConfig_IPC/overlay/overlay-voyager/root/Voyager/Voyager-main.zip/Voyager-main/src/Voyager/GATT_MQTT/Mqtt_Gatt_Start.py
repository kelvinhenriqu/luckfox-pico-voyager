import dbus
import dbus.exceptions
import dbus.mainloop.glib
import dbus.service

from gi.repository import GObject
from .advertising import *
from .gatt_server import *
#import argparse

import threading
import subprocess

def run_bluetoothctl_command():
    init_strings = [
        'power on',
        'agent off',
        'agent NoInputNoOutput',
        'discoverable on',
        'pairable on',         
        'default-agent',
        'exit'
    ]
    for i in init_strings:
        process = subprocess.Popen(
            ["bluetoothctl"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    
        print(f"{i}")
        x = process.stdin.write(i)
        print(x)
        #stdout, stderr = process.communicate(f"{i}\n")
        '''print(f"{stdout}")
        if stderr:
            print(f"Error executing command: {stderr}")'''
    
    process.stdin.flush()
    process.wait()
    output, errors = process.communicate()

    output_to_write_to_file = output.decode()
    print(output_to_write_to_file)

def bluetooth_start():
    
    for i in init_strings:
        try:
            output = run_bluetoothctl_command(i)
            print(output)
            time.sleep(1)
        except Exception as e:
            print(f"Error during command - {e}")


def Run():
    run_bluetoothctl_command()
    import sys
    sys.exit()
    '''threading.Thread(target=MqttTreat).start() #Starts MQTT server

    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus()

    mainloop = GObject.MainLoop()

    adapter_name = ""
    advertising_main(mainloop, bus, adapter_name)
    gatt_server_main(mainloop, bus, adapter_name)
    mainloop.run()'''


if __name__ == '__main__':
    Run()