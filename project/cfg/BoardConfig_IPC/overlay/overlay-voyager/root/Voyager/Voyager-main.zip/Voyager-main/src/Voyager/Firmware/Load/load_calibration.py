from Voyager.Settings.Config import Config_Read, config_write
from Voyager.Firmware.Load.FC2311 import FC2311
from time import sleep

import sys

class CalibrateLoad:
    def __init__(self):
        self.treated_value_zero = 0
        self.treated_value_weight = 0
        self.Sensor = FC2311()

    def run(self):
        
        print("VGR LOAD calibration tool")
        option = input("1 to test the sensor and 2 to calibrate\n ")
        print(f"option selected: ({option})")
        if option == "2":
            self.Sensor.set_scale(1)
            self.Sensor.set_offset(0)

            input("Make sure that the Weight sensor without any load and press ENTER to continue")
            x = self.average_value(50)
            self.treated_value_zero = self.average_value(50)
            self.Sensor.set_offset(self.treated_value_zero)
            sleep(2)

            self.high_level = float(input("Put a known Weight in to  the sensor and enter below the value read on the external gauge and press ENTER\n "))
            x = self.average_value(50)
            self.treated_value_weight = self.average_value(50)
            sleep(2)

            self.factor = self.factor_calculation()
            print("\nCalibration done")
            print(f'Value Read at zero: {self.treated_value_zero:.4f}')
            print(f'Value Read at {self.high_level}: {self.treated_value_weight:.4f}')
            print(f'Factor value: {self.factor}')

            self.Sensor.set_offset(round(self.treated_value_zero,3))
            self.Sensor.set_scale(self.factor)

            config_write("General","Calibration_Factor",self.factor)
            config_write("General","Offset",self.treated_value_zero)
            
            input("Press enter to test the calibration")

            self.treated_value()
        else:
            while True:
                print(f"value: {self.get_value()}")
    def get_value(self):
        try:
            indicated_value = self.Sensor.get_grams()
        except Exception as e:
            if "[Errno 6]" in str(e):
                print("The sensor is in error or not connected.")
                sys.exit()
            else:
                print(f'Unknown error: {e}')
                sys.exit()

        return indicated_value
    
    def average_value(self, times):
        try:
            raw_value = 0
            for i in range(times):
                measure = self.get_value()
                print(f'Read value: {measure:.4f}')
                raw_value = raw_value + measure
            treated_value = raw_value / times

        except Exception as e:
            print(e)
            sys.exit()
        print(f'Average Value: {treated_value}')
        return treated_value
    
    def factor_calculation(self):
        return self.high_level / self.treated_value_weight
    
    def treated_value(self):
        while True:
            read_value = self.get_value()
            value = read_value#*self.factor
            print(f'Factor applied value: {value}')