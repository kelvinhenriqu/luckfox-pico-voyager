from Voyager.Settings.Config import Config_Read, config_write
from Voyager.Firmware.Impact.Scuffing import Scuffing
from time import sleep
import sys
# from ...Settings.Config import Config_Read, config_write


class CalibrateScuffing:
    def __init__(self):
        self.Sensor = Scuffing()
        self.sensor_range = 200

    def run(self):

        print("VGR SCUFFING calibration tool")
        option = input("1 - Test the sensor\n2 - Calibrate the sensor\n")
        print(f"Option selected: {option}\n")

        if option == "1":
            self.sensor_test()
        
        elif option == "2":

            self.Sensor.set_offset(0,0,0)
            self.Sensor.set_factor(1,1,1)
            input("Make sure the VGR Scuffing is at rest before starting the measurement. Don't touch the sensors")
            values_offset_list = self.get_values(100)
            for i in range(len(values_offset_list)):
                if values_offset_list[i] >= 60:
                    print(f"WARNING: Sensor {i} has a value higher than 60. Is recommended to redo the calibration or verify the sensors")
            config_write("General","Offset",values_offset_list)
            self.Sensor.set_offset(values_offset_list[0], values_offset_list[1], values_offset_list[2])

            print(f"OFFSET DONE - values: {values_offset_list}\n")
            
            print("*CALIBRATION FACTOR*")
            input("Press the neck, shoulder and heel sensors hard to make the calibration factor")
            
            values_factor_list = self.get_values(300)
            calibration_factor = []
            for i in range(len(values_factor_list)):
                if values_factor_list[i] <= 50:
                    print(f"WARNING: Sensor {i} has a value less than 50. It is recommended to redo the calibration.")
                calibration_factor.append(self.factor_calculation(values_factor_list[i]))
            
            config_write("General","Calibration_Factor",calibration_factor)
            self.Sensor.set_factor(calibration_factor[0], calibration_factor[1], calibration_factor[2])

            print(f"CALIBRATION FACTOR DONE (dentro do código calibração): {calibration_factor}")
            print(f"CALIBRATION FACTOR DONE (dentro do código Scuffing): {self.Sensor.get_factor()}")
            input("Press Enter to test the sensors")
            self.sensor_test()


        else:
            print("Invalid option. Please try again.")
            self.run()

    def get_values(self,time):

        status_sensor = self.Sensor.Start()
        neck_list = []
        shoulder_list = []
        heel_list = []
        for i in range(time):
            m1,m2,m3= self.Sensor.read()
            neck_list.append(m1)
            shoulder_list.append(m2)
            heel_list.append(m3)
            
            print(f"Getting data ({i} - {time})")

        max_value1 = max(neck_list)
        max_value2 = max(shoulder_list)
        max_value3 = max(heel_list)
        offset_list = [max_value1, max_value2, max_value3]

        print(f"Max values: Neck: {max_value1} | Shoulder: {max_value2} | Heel: {max_value3}")
    
        return offset_list

    def sensor_test(self):
        while True:                    
            v1, v2, v3 = self.Sensor.read()
            print(f"Neck: {v1} | Shoulder: {v2} | Heel: {v3}")
            sleep(0.1)
    
    def factor_calculation(self,treated_value):
        return self.sensor_range / treated_value