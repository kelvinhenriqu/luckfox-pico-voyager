#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#04 - added battery level monitoring with FC2311.Battery()

__Version__ = 4


import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
import time
import sys
from Voyager.Settings.Config import Config_Read

i2c = busio.I2C(board.SCL3, board.SDA3)
ads = ADS.ADS1115(i2c)

class FC2311:

    def __init__(self, gain=16):
        """
        :param gain: set gain 2/3, 1, 2, 4, 8, 16
        """
        self.GAIN = 16
        self.OFFSET = Config_Read().getfloat("General","Offset")
        self.SCALE = Config_Read().getfloat("General","Calibration_Factor")
        self.grams = 0
        self.set_gain(gain)
        self.BatteryLevel = None

    def set_gain(self, gain=16):
        """
        2/3 = +- 6.144v
        1   = +- 4.096v
        2   = +- 2.084v
        4   = +- 1.024v
        8   = +- 0.512v
        16  = +- 0.256v
        """

        try:
            ads.gain = gain
        except:
            self.GAIN = 16  # Sets default GAIN at 128

        self.read()

    def set_scale(self, scale):
        """
        Set scale
        :param scale, scale
        """
        self.SCALE = scale

    def set_offset(self, offset):
        """
        Set the offset
        :param offset: offset
        """
        self.OFFSET = offset

    def get_scale(self):
        """
        Returns value of scale
        """
        return self.SCALE

    def get_offset(self):
        """
        Returns value of offset
        """
        return self.OFFSET

    def read(self):
        """
        Read data from the fc2311 chip
        :param void
        :return reading from the HX711
        """

        ads.gain = 16
        chan34 = AnalogIn(ads, ADS.P2, ADS.P3)
        Measure1 = chan34.value #value=raw voltage=voltage
        #Measure2 = chan34.voltage #value=raw voltage=voltage

        return Measure1

    def read_average(self, times=5):#16 default
        """
        Calculate average value from
        :param times: measure x amount of time to get average
        """
        sum = 0
        for i in range(times):
            sum += self.read()
        return sum / times

    def get_grams(self, times=5):#16 default
        """
        :param times: Set value to calculate average, 
        be aware that high number of times will have a 
        slower runtime speed.        
        :return float weight in grams
        """
        value = (self.read_average(times) - self.OFFSET)
        self.grams = (value * self.SCALE)
        #print(f"----------------------valor lido = {self.grams}------------------------------------------------------")
        return self.grams

    def Tare(self, times=3):#16 default
        """
        Tare functionality fpr calibration
        :param times: set value to calculate average
        """
        sum = self.read_average(times)
        self.set_offset(sum)
        
    def Battery(self):
        try:
            ads.gain = 2/3
            chan = AnalogIn(ads, ADS.P0, ADS.P1)
            AdcRead = chan.voltage
            AdcRead = AdcRead * 1000           
            
            MaxAdc = 4200
            MinAdc = 3300
            
            BP = 100 * (AdcRead - MinAdc) / (MaxAdc - MinAdc)
            if (BP > 100):
                BP = 100
                
            self.BatteryLevel = round(BP,0)
            
        except Exception as x:
            print(x)
        
        return self.BatteryLevel

    def Start(self):
        """
        Power the chip up
        """
        Test = self.grams
        try:
            print(Test)
            return 0

        except OSError:
            print("\nFATAL ERROR, is sensor connected ?\n")
            return 1

        except KeyboardInterrupt:
            print("\ncancelled by user\n")
            return 2

if __name__ == "__main__":    
    import time
    Sensor = FC2311(5)
    Sensor.Tare()
    Sensor.set_scale(1.125)  

    while True:
        time.sleep(.1)
        data = Sensor.get_grams()
        print(data)