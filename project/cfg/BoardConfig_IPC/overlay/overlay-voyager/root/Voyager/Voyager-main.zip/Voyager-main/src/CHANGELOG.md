## 4.4.2 (2025-11-14)

### Refactor

- **PRESSURE-AND-TEMPERATURE-MEASUREMENT-CONNECTED**: both measurement connected

## 4.4.1 (2025-10-16)

### Fix

- **i2c-error**: multi i2c master connection

## 4.4.0 (2025-09-17)

## 4.3.1 (2025-09-17)

### Fix

- **changed-in-the-variable-in-read-sensor-function**: updated sensor reading variable in pressure firmware

## 4.3.0 (2025-08-20)

### Feat

- **STATUS-LED**: add new status led controll

## 4.2.1 (2024-12-01)

### Refactor

- **Calibration-Webpage**: refactoration of page construction

## 4.2.0 (2025-08-04)

### Feat

- **scuffing-calibration-factor**: new scuffing calibration, added a correction factor for equally proportional readings

## 4.1.0 (2025-07-30)

### Feat

- **INPACK-FIRMWARE**: add two new classes (ADS1115, NTC) and created the inpack firmware

## 1.7.0 (2025-05-29)

## 4.0.0 (2025-05-29)

### BREAKING CHANGE

- The source code is no longer in the 'Voyager/' folder.
All imports must now reference modules from the 'src/' root path.

### Refactor

- **structure**: move source code to src/ and extract non-source content to voyager-docs

## 3.1.0 (2025-05-23)

### Feat

- **SCUFFING-CALIBRATION**: new scuffing calibration script

## 3.0.4 (2025-05-21)

### Fix

- **SLEEP-TIMER**: fix sleep timer triggering during active measurement and improve bluetooth logging

## 3.0.3 (2025-05-20)

### Fix

- **SCUFFING-FIRMWARE**: no bluetooth connected error

## 3.0.2 (2025-05-20)

### Fix

- **HTTP-CHANGE**: interface change

## 3.0.1 (2025-05-19)

### Fix

- **HTTP-CHANGES-&-GATT-FIX**: changes in http and gatt services

## 3.0.0 (2024-12-01)

### BREAKING CHANGE

- The new software version is not compatible with old hardwares because the measurement method changed

### Fix

- **VGR-SCUFFING**: changes in gpio library

## 2.5.2 (2025-04-25)

### Fix

- **FIRMWARE**: without app run

## 2.5.1 (2025-04-24)

### Fix

- **GATT_MQTT**: code review

## 2.5.0 (2025-04-22)

### Feat

- **LOGGER-LIBRARY**: debug off option added

## 2.4.3 (2025-04-22)

### Fix

- **COMMIT-FIX**: new versioning using commitizen

## 2.4.2 (2024-12-01)

### BREAKING CHANGE

- it is not reccomended to use old firmwares because it can cause random crashes

### Feat

- **PRESSURE-FIRMWARE**: new linear regretion formula added
- **PRESSURE-FIRMWARE**: new linear regretion formula added

### Fix

- **PRESSURE-CALIBRATION**: fix in calibration tool

## 2.4.1 (2025-04-09)

### Fix

- **BLUETOOTH-BUILD**: CHANGE IN PROCESS
- **GAAT**: LIBRARY IMPORT FIX

## 2.4.0 (2024-12-01)

### Feat

- add gatt mqtt

### Fix

- **VGR-LOAD**: ROUND PROCEDURE

## 2.1.9 (2025-02-13)
