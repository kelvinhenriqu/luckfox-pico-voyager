#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#04 - added battery level monitoring with FC2311.Battery()
#05 - converted to scuffing library
#06 - 13/10/2023 -now the value is in Newton

__Version__ = 6


import board
import busio
#import adafruit_ads1x15.ads1115 as ADS
#from adafruit_ads1x15.analog_in import AnalogIn
import adafruit_mpu6050
import time
#import mraa
import os

i2c = busio.I2C(board.SCL3, board.SDA3) #PIN 14 and 15
#ads = ADS.ADS1115(i2c) 

try:
    mpu = adafruit_mpu6050.MPU6050(i2c,address=0x69,)#0x68 gyro board - 0x69 voyager board
    mpu.accelerometer_range(3)
    mpu.gyro_range(3)
except Exception as e:
    print("erro de conexão com o sensor giroscopio")
    os.kill

#Gpio1 = mraa.Gpio(19)
#Gpio2 = mraa.Gpio(21)
#Gpio3 = mraa.Gpio(23) 

#Gpio1.dir(mraa.DIR_OUT)
#Gpio2.dir(mraa.DIR_OUT)
#Gpio3.dir(mraa.DIR_OUT)

class MPU6050:
    
    def __init__(self):
        self.acc_x = None
        self.acc_y = None
        self.acc_z = None

        self.Gyro_x = None
        self.Gyro_y = None
        self.Gyro_z = None

        self.STANDARD_GRAVITY = 9.80665
    
    def reset(self):
        """Reinitialize the sensor"""
        pass
        #mpu.reset()

    def read_acc(self,eixo=0):
        """Acceleration X, Y, and Z axis data in :math:`m/s^2`"""
        ax,ay,az = mpu.acceleration

        '''DivFactor = 10
        ax=round(ax,1)
        ay=round(ay,1)
        az=round(az,1)
        ax=ax*DivFactor
        ay=ay*DivFactor
        az=az*DivFactor'''

        match eixo:
            case 0:
                return (ax/self.STANDARD_GRAVITY),(ay/self.STANDARD_GRAVITY),(az/self.STANDARD_GRAVITY)
            case 1:
                return ax
            case 2:
                return ay
            case 3:
                return az
            
    def read_gyro(self,eixo=0):
        """Gyroscope X, Y, and Z axis data in :math:`º/s`"""
        x,y,z = mpu.gyro

        match eixo:
            case 0:
                return x,y,z
            case 1:
                return x
            case 2:
                return y
            case 3:
                return z
            
    def Start(self):
        try:
            #self.reset()
            return 0
        except:
            print("erro de conexão com o sensor giroscopio")
            raise ValueError("erro de conexão com o sensor giroscopio")
            
    
if __name__ == "__main__": 

    MPU = MPU6050()
    StatusMPU = MPU.Start()

    STANDARD_GRAVITY = 9.80665
    RANGE_16_G = 2048

    if StatusMPU == 0:
        while True:
            ax,ay,az = MPU.read_acc()
            gx,gy,gz = MPU.read_gyro()
            #print(f"AcX={round(ax,3)}, AcY={round(ay,3)}, AcZ={round(az,3)}")
            #print(f"GcX={round(gx,3)}, GcY={round(gy,3)}, GcZ={round(gz,3)}")
            tax = (ax / STANDARD_GRAVITY) #* RANGE_16_G
            tay = (ay / STANDARD_GRAVITY) #* RANGE_16_G
            taz = (az / STANDARD_GRAVITY) #* RANGE_16_G

            print(f"TAcX={tax} G, TAcY={tay} G, TAcZ={taz} G\n")

            #time.sleep(0.5)
            

    elif StatusMPU == 1:
        print("\nFATAL ERROR, are the sensors connected ?") 
    else:
        print("\ndo not apply force in sensor starting process")
