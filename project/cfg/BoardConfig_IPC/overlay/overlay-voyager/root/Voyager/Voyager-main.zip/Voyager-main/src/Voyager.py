
from Voyager.Settings.Config import Config_Read,config_write
#from Voyager.GATT_MQTT.Mqtt_Gatt_Start import Run as GattRun
from threading import Thread
import sys
import os
import traceback
import argparse

#Voyager Logging setup
from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[Main]", clear=True)
log = SL.get_logger()

class Voyager:

    def __init__(self):
        self.calibration_needed = False
        parser = argparse.ArgumentParser(allow_abbrev=False)
        parser.add_argument("-co", "--config", action="store_true",         help="Set up the environment and install all required dependencies.")
        parser.add_argument("-bu", "--build", action="store_true",          help="Compile and build the application from source.")
        parser.add_argument("-ig", "--ignore_version", action="store_true", help="Skip the version check and proceed with the build.")
        parser.add_argument("-au", "--autostart", action="store_true",      help="Configure the app to run automatically on system startup.")
        parser.add_argument("-ca", "--calibrate", action="store_true",      help="Launch the calibration tool based on the firmware type in the config file.")
        parser.add_argument("-up", "--update", action="store_true",         help="Manually update the firmware to the latest version.")
        parser.add_argument("-v",  "--version", action="store_true",        help="Display the current application version and exit.")
        parser.add_argument("-rm",  "--remove", action="store_true",        help="Generic remove argument placeholder.")
        #parser.add_argument("-ga", "--gatt", action="store_true",           help="Start the GATT service manually.")
        #parser.add_argument("","",)
        
        args = parser.parse_args()

        if args.config:     self.config()
        if args.autostart:  self.auto_start(args.remove)
        if args.calibrate:  self.calibrate()
        if args.update:     self.Update()
        if args.build:      self.build(args.ignore_version)
        if args.version:    self.get_app_version()
        #if args.gatt:       GattRun()

        self.threads = []

        self.isnew = Config_Read().getboolean("General","New_Board")
        self.config() if self.isnew else self.start()

    def calibrate(self):
        self.calibration_needed = True        

    '''def start_simulation(self,BoardType) -> None:
        'decides which simulation firmware to run based on board type'

        log.info(f"Running firmware - {BoardType}")
        try:
            match BoardType:
                case 'Load':
                    log.info("Running Load firmware Simulation")
                case 'Impact':
                    log.info("Running Impact firmware Simulation")
                case 'Pressure':
                    log.info("Running Pressure firmware Simulation")
                case _:
                    log.error("Invalid firmware type specified in config file")
                    sys.exit()
        except ImportError as e:
            log.error(f"Error while importing simulation firmware library: {e}")
            sys.exit()
        except Exception as e:
            log.critical(f"Unknown error while importing simulation firmware library: {e}")
            sys.exit()'''

    def start_firmware(self,BoardType) -> None:
        'decides which firmware to run based on board type'
        log.info(f"Running firmware - {BoardType}")

        try:
            if sys.platform == "win32":
                log.error("Cannot run main firmware on Windows.")
                sys.exit()
                
            match BoardType:
                case "Load":
                    if not self.calibration_needed:
                        log.info("Running main Load firmware")
                        from Voyager.Firmware.Load import firmware as Load
                        self.threads.append(Thread(target=Load.Run, daemon=True, name="Load_Firmware_Thread"))
                    else:
                        log.info(f"Running Voyager Load calibration tool")
                        from Voyager.Firmware.Load.load_calibration import CalibrateLoad
                        Load_calibration_tool = CalibrateLoad()
                        Load_calibration_tool.run()
                        sys.exit()
                        
                case 'Impact':
                    if not self.calibration_needed:
                        log.info("Running main Scuffing firmware")
                        from Voyager.Firmware.Impact import firmware as Impact
                        self.threads.append(Thread(target=Impact.Run, daemon=True, name="Impact_Firmware_Thread"))
                    else:
                        log.info(f"Running Voyager Scuffing calibration tool")
                        from Voyager.Firmware.Impact.scuffing_calibration import CalibrateScuffing
                        Scuffing_calibration_tool = CalibrateScuffing()
                        Scuffing_calibration_tool.run()
                        sys.exit()
                        
                case 'Pressure':
                    if not self.calibration_needed:
                        log.info("Running main Pressure firmware")
                        from Voyager.Firmware.Pressure import firmware as Pressure
                        self.threads.append(Thread(target=Pressure.Run, daemon=True, name="Pressure_Firmware_Thread"))
                    else:
                        log.info(f"Running Voyager Pressure calibration tool")
                        from Voyager.Firmware.Pressure.pressure_calibration import CalibratePressure
                        Pressure_calibration_tool = CalibratePressure()
                        Pressure_calibration_tool.run()
                        sys.exit()
                case 'Inpack':
                    if not self.calibration_needed:
                        log.info("Running main Inpack firmware")
                        from Voyager.Firmware.Inpack import firmware as Inpack
                        self.threads.append(Thread(target=Inpack.Run, daemon=True, name="Inpack_Firmware_Thread"))
                    else:
                        log.info(f"Running Voyager Pressure calibration tool for Inpack board (intentional: Inpack uses Pressure calibration tool)")
                        from Voyager.Firmware.Pressure.pressure_calibration import CalibratePressure
                        Pressure_calibration_tool = CalibratePressure()
                        Pressure_calibration_tool.run()
                        sys.exit()
                case 'Giro':
                    if not self.calibration_needed:
                        log.info("Running main Giro firmware")
                        from Voyager.Firmware.Giro import firmware as Giro
                        self.threads.append(Thread(target=Giro.Run, daemon=True, name="Giro_Firmware_Thread"))
                    else:
                        log.error(f"There is no Giro firmware calibration tool")
                        sys.exit()
                case _:
                    log.critical("Invalid firmware type specified in config file")
                    sys.exit()                

        except ImportError as e:
            log.critical(f"Error while importing firmware library: {e}\n{traceback.format_exc()}")
            sys.exit()

        except Exception as e:
            if "No I2C device at address: 0x36" in str(e):
                log.critical(f"Error while trying to access I2C device at address 0x36, is Voyager board connected?")
            elif "[Errno 6] No such device or address" in str(e):
                log.critical(f"Error while trying to connect to I2C device, probably ADS1115 (0x48) or Voyager Board Giroscope (0x69)\n {e}")
            else:
                log.critical(f"Unknown error while importing firmware library: {e}")
            sys.exit()

    def start_background_services(self) -> None:
        'Run background services such as http server and bluetooth server'

        if Config_Read().getboolean('GATT_Service','Start_Service'): #Start Service ?
            try:
                from Voyager.GATT_MQTT import Mqtt_Gatt_Start
                self.threads.append(Thread(target=Mqtt_Gatt_Start.Run, daemon=True, name="GATT_Service_Thread"))
            except ImportError as e:
                log.warning(f"Error during GATT service module importing - {e}")
                

        if Config_Read().getboolean('Bluetooth_Service','Start_Service'): #Start Service ?
            try:
                from Voyager.Libraries import bluetooth
                self.threads.append(Thread(target=bluetooth.Run, daemon=True, name="Bluetooth_Service_Thread"))
            except ImportError:
                log.warning("Error during Bluetooth service module importing")

        if Config_Read().getboolean('HTTP_Service','Start_Service'): #Start Service ?
            try:
                from Voyager.HTTP import Http_Start
                self.threads.append(Thread(target=Http_Start.Run, daemon=True, name="HTTP_Service_Thread"))
            except ImportError as e:
                log.warning(f"Error during HTTP service module importing - {e}")

    def start(self) -> None:
        'Reads config file and decide which kind of services and software it needs to start in background'

        BoardType = Config_Read().get('General','Device_type')
        Simulation = Config_Read().getboolean('General','Simulation')

        if Config_Read().getboolean('General','Start_Main_Firmware'): #Start Service ?
            if not Simulation:
                self.start_firmware(BoardType)
            else:
                log.error("Simulation mode is not supported in this version and will be removed in future releases.")
                '''self.start_simulation(BoardType)'''
        
        self.start_background_services()

        for thread in self.threads:
            log.info(f"starting thread: {thread}")
            thread.start()
        for thread in self.threads:
            thread.join()

    def config(self):
        'Start the config procedure, installing dependencies and changing bluetooth name'
        log.info("Starting config procedure")
        from Voyager.First_Setup.bluetooth_build import start_services

        try:
            start_services()
            board_serial = Config_Read().get("General","Board_Serial")


            if "VPC" in board_serial:
                log.info(f"according to config file, its a Pressure board - {board_serial}")
                bluetooth_name = "Voyager Pressure - " + str(board_serial)

            elif "VLC" in board_serial:
                log.info(f"according to config file, its a Load board - {board_serial}")
                bluetooth_name = "Voyager Load - " + str(board_serial)

            elif "VIC" in board_serial:
                log.info(f"according to config file, its a Impact board - {board_serial}")
                bluetooth_name = "Voyager Impact - " + str(board_serial)

            elif "VSC" in board_serial:
                log.info(f"according to config file, its a Scuffing board - {board_serial}")
                bluetooth_name = "Voyager Scuffing - " + str(board_serial)
            
            else:
                log.critical("cannot identify board type, please change name in the config file")
                sys.exit()
            
            #cmd = "sudo bluetoothctl system-alias " + '"' + str(bluetooth_name) + '"'
            cmd = f'sudo bluetoothctl system-alias "{bluetooth_name}"'

            if os.system(cmd) == 0:
                config_write("General","New_Board","False")
                log.info(f"Config procedure done successfully")
                sys.exit()

        except Exception as e:
            log.critical(f"Error while configuring bluetooth services - {e}")
            sys.exit()

    def build(self, version_ignore=False) -> None:
        log.info(f"Building the application from source... (it is recommended to use GitHub Actions instead)")
        from Voyager.First_Setup.app_build import build_app
        build_app(version_ignore)
        log.info(f"Build app done")
        sys.exit()

    def auto_start(self, remove=False) -> None:
        'Sets up the auto-start service using systemctl'
        from Voyager.First_Setup.autostart_build import SetupAutostart
        SetupAutostart(remove)
        sys.exit()

    def Update(self) -> None:
        'Updates the software manually using a zip file.'
        log.info("Trying to update the software manually using zip file...")
        from Voyager.Update.Update import Update_firmware
        Update_firmware()
        sys.exit()

    def get_app_version(self) -> None:
        from Voyager.Version import __version__
        log.info(f"app version: {__version__}")
        sys.exit()

if __name__ == '__main__':
    Voyager()
    