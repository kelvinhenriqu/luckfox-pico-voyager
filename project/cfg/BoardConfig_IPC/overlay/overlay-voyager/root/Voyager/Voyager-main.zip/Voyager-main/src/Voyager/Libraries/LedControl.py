import time
import threading
import board
import digitalio
from Voyager.Settings.Config import Config_Read

config_read = Config_Read()

LED_RED = config_read.get('LEDS','Red_Pin',fallback=board.D23)
LED_GREEN = config_read.get('LEDS','Green_Pin',fallback=board.D21)
LED_BLUE = config_read.get('LEDS','Blue_Pin',fallback=board.D19)

class RGBLed:
    def __init__(self) -> None:
        self.red = digitalio.DigitalInOut(LED_RED)
        self.red.direction = digitalio.Direction.OUTPUT

        self.green = digitalio.DigitalInOut(LED_GREEN)
        self.green.direction = digitalio.Direction.OUTPUT

        self.blue = digitalio.DigitalInOut(LED_BLUE)
        self.blue.direction = digitalio.Direction.OUTPUT

        self._blinking = False
        self._blink_thread = None

        # Desliga todos no início
        self._led_off()

    def _led_off(self):
        """Desliga todas as cores"""
        self.red.value = False
        self.green.value = False
        self.blue.value = False
    
    def kill_threads(self):
        """Para qualquer pisca em andamento"""
        self._blinking = False
        if self._blink_thread and self._blink_thread.is_alive():
            if threading.current_thread() != self._blink_thread:
                self._blink_thread.join()
        self._blink_thread = None
        self._led_off()
    
    def blink(self, *pins, interval=1.0):

        self.kill_threads()  # Para qualquer pisca anterior
        self._blinking = True

        def _do_blink():
            if len(pins) == 1:  # pisca só uma cor
                pin = pins[0]
                while self._blinking:
                    pin.value = True
                    time.sleep(interval)
                    pin.value = False
                    time.sleep(interval)

            elif len(pins) == 2:  # pisca alternando
                p1, p2 = pins
                while self._blinking:
                    p1.value = True
                    p2.value = False
                    time.sleep(interval)
                    p1.value = False
                    p2.value = True
                    time.sleep(interval)
            elif len(pins) == 3:  # pisca alternando
                p1, p2, p3 = pins
                while self._blinking:
                    p1.value = True
                    p2.value = False
                    p3.value = False
                    time.sleep(interval)
                    p1.value = False
                    p2.value = True
                    p3.value = False
                    time.sleep(interval)
                    p1.value = False
                    p2.value = False
                    p3.value = True
                    time.sleep(interval)

            # Desliga tudo quando parar
            self._led_off()

        self._blink_thread = threading.Thread(target=_do_blink)
        self._blink_thread.start()