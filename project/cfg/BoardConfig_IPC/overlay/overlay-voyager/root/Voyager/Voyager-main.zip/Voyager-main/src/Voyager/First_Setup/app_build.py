import PyInstaller.__main__
import os,sys
import subprocess
import re
import logging
from ..Version import __version__

from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[Build]")
log = SL.get_logger()

#log = SL.setup()
#SL.update_prefix("[Build]")
version = __version__


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def remove_oldfiles():

    log.info("trying to remove old files...")
    if not os.system("sudo rm -r dist/ Voyager.spec build/"):
        log.info("Old files removed")
    else:
        log.error("Error while removing old files")

    config_file = resource_path("Voyager_Settings.ini")
    log.debug(config_file)
    #build_app()

def zip_files():
    import zipfile
    global version

    zipname = "Voyager_" + version + ".zip"
    os.chdir("dist/")
    zip = zipfile.ZipFile(zipname, "w", zipfile.ZIP_DEFLATED)
    zip.write("Voyager")
    zip.write("Voyager_Settings.ini")
    zip.close()
    log.info("Zip completed successfully")
    log.info(f"files saved in dist/{zipname}")

def update_version():
    ''''Update the script version according to version numbering in git project'''

    global version
    log.info(f"current app version = {__version__}")

    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    version_file_path = os.path.join(parent_dir, 'Version.py')

    log.info(f"current path = {version_file_path}")

    try:
        version = subprocess.check_output(["git","describe","--tags", "--abbrev=0"]).strip().decode("utf-8")
        log.info(f"app version will be updated to {version}")
        with open (version_file_path) as file:
            content = file.read()

        updated_content = re.sub(r'^(__version__\s*=\s*)["\'].*?["\']', rf'\1"{version}"', content, flags=re.MULTILINE)

        with open (version_file_path,"w") as file:
            file.write(updated_content)

    except subprocess.CalledProcessError:
        log.critical(f"impossible to get currect app version from git, please commit a new build before trying to build the app or run again with --ignore_version")
        sys.exit()

    
def build_app(version_ignore=False):    

    update_version() if not version_ignore else log.warning(f"Skipping version update") 

    try:
        PyInstaller.__main__.run([
            "Voyager.py",
            "--onefile",
            "--name=Voyager",
            "--clean",
            "--add-data=Voyager/HTTP/templates:Voyager/HTTP/templates"
        ])
    except Exception as e:
        print(f"error: {e}")

    log.info(f"Moving config file to dist folder")
    os.system("sudo cp Voyager_Settings.ini dist/Voyager_Settings.ini")
    log.info(f"Trying to zip files")

    zip_files()


if __name__ == "__main__":
    #nohup pyinstaller --onefile Voyager.py --add-binary Voyager_Settings.ini:./Voyager_Settings.ini --distpath ./build --workpath ./build/temp --noconfirm --clean
    #update_version()
    #remove_oldfiles()
    pass


