#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#______Firmware for VGR_LOAD______

#41 - led control update
#42 - thread control for measurements array
#43 - creation of library
#44 - array Concat
#45 - firmware organization and library creation
#46 - Measurements array with timestamp [[timestamp,measure],[timestamp,measure]]
#47 - array adjustments for IOS 
#50 - software update via socket command and ftp. 25/04/2023
#51 - now CONNECT command return the version number - 25/04/2023
#52 - only absolute numbers
#53 - battery level command
#54 - Board.ID file to declare the board serial number - CONNECT command changed
#55 - Beacon Detection
#56 - Full code review 05/2024
#57  e V2.1.7 - version numbering changed to correspond the same as github versioning

__VERSION__ = "V2.1.9"

import time
from datetime import datetime
import sys
import os       #OS Commands
import csv      #csv file manipulation
import json     #Json file create
import shutil   #SdCard Management
import gzip     #compress file
from threading import Thread

from Voyager.Settings.Config import Config_Read
from Voyager.Libraries.Battery import Fuel_Gauge 
from Voyager.Libraries.Beacon import BeaconDetector
from Voyager.Bluetooth.Bluetooth_Server import Bluetooth_Server
from Voyager.Firmware.Giro.IPS import IPS

IPS = IPS()

Battery = Fuel_Gauge() #Start Fuel Gauge sensor
Battery.Wake()

BeaconDetect = BeaconDetector()

BServer = Bluetooth_Server()
BServer.Config() #Config Bluetooth socket connection server

#Get configurations in config file
Debug = Config_Read().getboolean('General','Debug')
path = Config_Read().get('Directories','Measurements_Path')
UpdatePath = Config_Read().get('Directories','Update_Path')
BoardType = Config_Read().get('General','FullName')
BoardID = Config_Read().get('General','Board_Serial')
Use_Beacons = Config_Read().getboolean('Beacon','Use_Beacons')

Running = False;Config = False;Timer = 0
Measurements1, Measurements2 = [],[]
Beacons = []
TimeToReset = Config_Read().getint('Bluetooth_Service','time_to_erase') #seconds to reset Measurements Array
filename = "dummy"
start_time = 0

def debugPrint(msg): #print in terminal
    global Debug
    if Debug > 0: print(msg) 

def SD_Management(): #Free space in internal memory
    total, used, free = shutil.disk_usage("/")

    T = total // (2**30)
    U = used // (2**30)
    F = free // (2**30)

    #debugPrint(f"Total: {T} GiB")
    #debugPrint(f"Used: {U} GiB")
    #debugPrint(f"Free: {F} GiB")
    
    return T,U,F

def Subtract_date(): #Get measure length
    global start_time
    now_time = datetime.now().strftime('%H:%M:%S') #hour-minute-seconds
    h1, m1, s1 = start_time.split(':')
    d1 = int(h1) * 3600 + int(m1) * 60 + int(s1)

    h2, m2, s2 = now_time.split(':')
    d2 = int(h2) * 3600 + int(m2) * 60 + int(s2)

    return d2-d1

def Json_encode(x=1, **kwargs):  # Json generate
    global BoardID, BoardType

    V1NAME, V1ID, V1UNIT = "Sensor1", "V1", "IPS"
    V2NAME, V2ID, V2UNIT = "Sensor2", "V2", "ACL"

    total, used, free = SD_Management()
    
    base_response = {
        1: {"STATUS_PLAY": kwargs.get('RN', 0), "Device_Name": BoardType, "Device_Serial": BoardID, 
            "TOTAL_SPACE": total, "VERSION": str(__VERSION__), "USED_SPACE": used, "AVAILABLE_SPACE": free,
            "Measurements":[
                {"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT},
                {"NAME": V2NAME, "ID": V2ID, "UNIT": V2UNIT},]},
        
        2: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), 
            "CSV_DATE": kwargs.get('csvdate'), "TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        3: {"TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        4: {"V1": kwargs.get('V1'), "V2": kwargs.get('V2')},
        
        5: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), "CSV_DATE": kwargs.get('csvdate')},
        
        6: {"DELETE_STATUS": kwargs.get('RESULT', "NOK")},
        
        7: {"STATUS": kwargs.get('RESULT', "NOK")},
        
        8: {"BATTERY_PORCENTAGE": kwargs.get('PORCENTAGE')},
        
        9: {"VALOR_1": kwargs.get('Valor1')},
        
        10: {"Measurements": [{"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT}, {"NAME": kwargs.get('V2NAME'), "ID": kwargs.get('V2ID'), "UNIT": kwargs.get('V2UNIT')}]},
        
        11: {},  # Special treatment
        
        12: {"V1": kwargs.get('V1ARRAY'), "V2": kwargs.get('V2ARRAY'), "BEACONS": kwargs.get('BEACONSARRAY')},
        
        13: {"UPDATE_STATUS": kwargs.get('RESULT', "NOK")},
        
        14: {kwargs.get('MESSAGE', "message"): kwargs.get('RESULT', "NOK")},
    }
    
    if x == 11: #its not a json, just a dictionary
        stamp = kwargs.get('V1STAMP')
        value = kwargs.get('V1VALUE')
        data = {"stamp": stamp, "value": value}
    else:
        data = json.dumps(base_response.get(x, {}))
    
    return data

def File_Compress(file): #create a compressed file and save it
    
    global path
    CSV_Directory = str(path) + str(file) + ".csv"
    debugPrint(CSV_Directory)
    GZ_Directory = CSV_Directory + ".gz"
    debugPrint(GZ_Directory)

    f_in = open(CSV_Directory)
    f_out = gzip.open(GZ_Directory, 'wt')
    f_out.writelines(f_in)
    f_out.close()
    f_in.close()

def Gen_Final_Json(file):
    """
    Generate and send the final JSON data for a completed measurement session.

    This function compresses the given file, calculates the session duration,
    creates a JSON-encoded string with measurement metadata, and sends it via Bluetooth.

    Parameters:
    file (str): The name of the CSV file containing the measurement data.

    Returns:
    None

    Side effects:
    - Compresses the specified file.
    - Sends JSON-encoded data through the Bluetooth connection.
    - Prints debug information if debugging is enabled.
    """
    global path

    File_Compress(file)

    todays_time = datetime.now().strftime('%d%m%y') #day-month-year
    Length = Subtract_date()

    BluetoothData = Json_encode(x=2,csvname=file,csvdate=todays_time,csvlen=Length)
    debugPrint(BluetoothData)

    BServer.client_sock.sendall(BluetoothData.encode())

def SaveSD(*args, SensorNames=None, Beacon=0, IsFirst=False):
    """
    Save sensor data to a CSV file.

    This function creates or appends to a CSV file, saving sensor readings along with timestamps and beacon information.
    Parameters:

    *args : Any
        Variable number of sensor readings to be saved.
    SensorNames : list, optional
        List of sensor names for the CSV header. Used only when IsFirst is True.
    Beacon : int, default 0
        Beacon identifier or value to be saved with each row.
    IsFirst : bool, default False
        If True, initializes the file with headers and generates a new filename.

    """
    global filename, start_time, path, BoardID  

    # Criar nome do arquivo na primeira execução
    if IsFirst:
        timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        CsvTimeStamp = datetime.now().strftime('%d%m%y%H%M')
        start_time = datetime.now().strftime('%H:%M:%S')
        filename = str(BoardID + CsvTimeStamp)
        debugPrint(f"[*] CSV File name: {filename}")

    # Criar diretório e definir caminho do arquivo
    os.makedirs(str(path), exist_ok=True)
    file_path = str(path) + str(filename) + ".csv"

    # Abrir arquivo CSV e escrever os dados
    try:
        with open(file_path, mode='a', newline='') as sensor_readings:
            sensor_write = csv.writer(sensor_readings, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)

            # Escrever cabeçalho na primeira chamada
            if IsFirst and SensorNames:
                timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                sensor_write.writerow([timestamp, "Beacon", *SensorNames])
            else:
                # Gerar timestamp para a linha de dados
                timestamp = datetime.now().strftime('%H%M%S%f')[:-4]  # HHMMSSmm
                sensor_write.writerow([timestamp, Beacon, *args])  # Escrever valores reais

    except Exception as e:
        print(f"Erro ao salvar no arquivo: {e}")

def ArrayClear():
    global Measurements1,Measurements2
    global TimeToReset
    global Beacons
    while True:
        time.sleep(TimeToReset)
        Measurements1,Measurements2 = [],[]
        Beacons = []

class Treatment:

    def __init__(self):
        self.OFFSET1 = 0
        self.MargemErro = 0.5

    def Startup(self):
        global Config
        if Config: #if config process is necessary  
            Config = False       
            try:                            
                if IPS.Start(): #IPS Sensor Test 
                    SaveSD(SensorNames=["IPS","ACL"],IsFirst=True) #Save the fist line of the file  
                    BluetoothData = Json_encode(x=7, RESULT="0") #STATUS 0 - OK
                    debugPrint(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    Thread(target=ArrayClear).start() #Clean Measurements Array
                    
                    print(f"Beacons State = Use_Beacons={Use_Beacons} and BeaconDetect list = {BeaconDetect.read}")
                    if Use_Beacons and BeaconDetect.read != {}: #Only starts the beacon thread if beacons are enabled and at least one beacon were assigned
                        Thread(target=BeaconThread).start() #Start the process to keep reading for beacons data

            except ValueError as e:
                debugPrint(f"error: {e}")
                BluetoothData = Json_encode(x=7, RESULT="2") #STATUS 2 - SENSOR ERROR
                debugPrint(BluetoothData)
                BServer.client_sock.send(BluetoothData.encode())

    def SensorRead(self):
        '''Read sensor data and return as Heel, shouder, neck and index'''

        self.Sensor1 = IPS.read()

        return self.Sensor1
    
    def BeaconRead(self):
        self.BeaconNearby = [] #Clear the list of detected beacons
        BeaconsStatus = BeaconDetect.read() #Read all detected beacons and parse them according to the list provived before

        for key in BeaconsStatus: #Get the detected beacons from the dict and parse it in a array to send to IOS
            SubList = BeaconsStatus[key]
            if SubList[0] == True:
                self.BeaconNearby.append(key)
                debugPrint(f"[*] {key} Inside field, sending data ({self.BeaconNearby})")
            else:
                debugPrint(f"[*] {key} Outside field, ignoring")

        self.BeaconTreated = self.BeaconNearby if self.BeaconNearby != [] else ""
        return self.BeaconNearby, self.BeaconTreated

def running():
    global Measurements1,Measurements2, Beacons
    
    #-------------------------------- Get time and date -------------------------------
    timenow = datetime.now().strftime('%I:%M:%S.')
    mili = datetime.now().strftime('%f')
    timestamp = str(timenow) + str((round((int(mili)/1000),0))).replace(".0",'')
    
    #-------------------------------- Read sensor data --------------------------------
    Treated = Treatment()
    Treated.Startup()
    
    BeaconNearby,BeaconTreated = Treated.BeaconRead()

    SV1,SV2 = Treated.SensorRead()
    
    #---------------------------- Parse data in json format ---------------------------
    MeasureArray1 = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=SV1)
    MeasureArray2 = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=SV2)

    BeaconsArray = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=BeaconNearby)

    Measurements1.append(MeasureArray1)
    Measurements2.append(MeasureArray2)

    Beacons.append(BeaconsArray)

    SaveSD(SV1,SV2,Beacon=BeaconTreated) #Save Pressure in filename

def VerifyUpdateStatus():
    log_file = Config_Read().get('Update_Process','Log_File_Path')
    suc_bit = Config_Read().get('Update_Process','Success_Update_Message')
    bad_bit = Config_Read().get('Update_Process','Bad_Update_Message')
    try:
        with open(log_file,'r',encoding='utf-8') as file:
            #data = file.readlines()
            data = file.read()
            print(data)
            if suc_bit or bad_bit in data:
                if suc_bit in data:
                    return "DONE"  
                elif bad_bit in data:
                    return "ERROR"
                else:
                    return "DOING"
            else:
                print("File Corrupted")
                return "ERROR"
    except FileNotFoundError:
        print("File not found")
        return "ERROR" 

def BeaconThread(): #Start Beacon Process in the Beacon Library
    BeaconDetect.run()
    debugPrint("[x] Stopped Beacon Thread")

def handle_bluetooth_data(Bdata):
    global Debug,Running,Config,Timer,Measurements1,Measurements2,Beacons,filename,UpdatePath
    
    if len(Bdata) != 0:
        debugPrint(f"\n[+] Received command: {Bdata}")
        Timer = 0
        match Bdata:
        
            case "PLAY\n" | "PLAY":   #Start Measure, outdated command
                pass

            case "STOP\n" | "STOP": #Stop Measure
                if Running:
                    debugPrint("[*] Stopping measurement")
                    Running = False
                    Config = False
                    BeaconDetect.stop() #Stop beacon reading Thread
                    Gen_Final_Json(filename)

            case "MEASUREMENTS\n" | "MEASUREMENTS":   #Start Measure
                if Running:
                    data = Json_encode(x=12,V1ARRAY=Measurements1,V2ARRAY=Measurements2,BEACONSARRAY=Beacons) 
                    bluetoothdata = str(data)
                    BServer.client_sock.send(bluetoothdata.encode())
                    debugPrint("[*] Sending Json for live chart generation")
                    debugPrint(bluetoothdata)
                    Measurements1,Measurements2 = [],[]
                    Beacons=[]
                    
                else:
                    m = []
                    data = Json_encode(x=12,V1ARRAY=m,V2ARRAY=m,BEACONSARRAY=m)
                    bluetoothdata = str(data)
                    try: BServer.client_sock.send(bluetoothdata.encode()) 
                    except: pass
                    debugPrint("[x] There is no data been recorded, nothing to send")

            case "exit\n" | "exit": #Force Stop program
                debugPrint("[x] Brute stop")
                sys.exit()

            case "FREESPACE" | "FREESPACE\n": #send available space in SdCard
                BluetoothData = Json_encode(x=3)
                BServer.client_sock.send(BluetoothData.encode())
                debugPrint(BluetoothData.encode())

            case "CONNECT" | "CONNECT\n": #CONNECT return
                if Running:
                    BluetoothData = Json_encode(RN=1)
                else:
                    BluetoothData = Json_encode(RN=0)

                BServer.client_sock.send(BluetoothData.encode())
                debugPrint(BluetoothData.encode()) 

            case "BATTERY" | "BATTERY\n": #request battery percentage
                BatteryPorcentage = round(Battery.Read_Percentage()) if Battery.Read_Percentage() <= 100 else 100
                BluetoothData = Json_encode(x=8,PORCENTAGE=BatteryPorcentage)
                BServer.client_sock.send(BluetoothData.encode())
                debugPrint(BluetoothData.encode())

            case _:              #If Receive Unknown Data
                pass

        DIV = Bdata.split(".", 2)

        match DIV[0]:
            
            case "PLAY":
                    x = DIV[1].rstrip("\n")
                    debugPrint(f"[+] Starting Data collection - adjusting date to {x}")
                    try:
                        if not Running:
                            date = "sudo timedatectl set-time '" + x + "'"
                            if os.system(date) == 0:
                                Config = True
                                Running = True
                            else:
                                debugPrint("[x] Error occurred while adjusting date")
                                BluetoothData = Json_encode(x=7, RESULT="1") #STATUS 1 - DATE ERROR
                                BServer.client_sock.send(BluetoothData.encode())
                                debugPrint(BluetoothData)

                        else:
                            raise Exception("[x] Impossible to adjust date during data collection")
                        
                    except Exception as error:
                        BluetoothData = Json_encode(x=7, RESULT="1")
                        BServer.client_sock.send(BluetoothData.encode())
                        debugPrint(f"[x] Unknown error occurred: {error}")
                        pass
                    
            case "DELETE":
                Action = DIV[1].rstrip("\n")
                
                if (Action == "UPDATE"): #if received DELETE.UPDATE the system will delete the update directory and create a new one.
                    if not os.path.exists(UpdatePath):
                        debugPrint("[*] There is no update directory, creating a new one")
                        #os.makedirs(UpdatePath)
                        #os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                    else:
                        debugPrint("[*] Deleting the update directory")
                        #shutil.rmtree(UpdatePath)
                        #time.sleep(1)
                        debugPrint("[*] There is no update directory, creating a new one")
                        #os.makedirs(UpdatePath)
                        #os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                        
                else:
                    debugPrint(f"[*] DELETE command received, deleting {Action}.csv")
                    file = str(path) + str(Action) + ".csv"
                    if os.path.isfile(file):
                        os.remove(file) 
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                    else:    ## Show an error ##
                        debugPrint(f"[x] Error: {filename} not found")
                        BluetoothData = Json_encode(x=6, RESULT="NOK")
                    debugPrint(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    
            case "UPDATE":
                Action = DIV[1].rstrip("\n")
                debugPrint(f"[*] Action is: {Action}")
                
                match Action:                            
                    
                    case "START":
                        debugPrint("[*] Starting update process . . .")
                        BluetoothData = Json_encode(x=13,RESULT="DOING") #STATUS STARTING - Starting update process
                        BServer.client_sock.send(BluetoothData.encode())
                        from ...Update.Update import Update_firmware
                        Update_firmware()
                        sys.exit()
                
                    case "STATUS":
                        STATUS = VerifyUpdateStatus()
                        debugPrint(f"[*] Update status = {STATUS}")
                        BluetoothData = Json_encode(x=13,RESULT=STATUS) #STATUS DOING - Error in update process
                        BServer.client_sock.send(BluetoothData.encode())
                            
                    case _:
                        debugPrint("[x] Missing arguments")
                    
            case "BEACON":
                DIV = Bdata.split(".", 3)
                Action = DIV[1]
                debugPrint(f"[*] Action is: {Action}")
                
                match Action:  

                    case "APPEND":
                        CommandLength = 4 #expected command need to have 4 arguments
                        try:
                            BeaconName = str(DIV[2])
                            Threshold = str(DIV[3].rstrip("\n"))

                            debugPrint(f"[+] Append command received - Adding {BeaconName}")

                            if BeaconDetect.append(BeaconName,Threshold):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="OK")
                                debugPrint(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")
                            
                        except IndexError:
                            debugPrint(f"[x] Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                        except Exception:
                            debugPrint(f"[x] Failed to execute Append command")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())


                    case "DELETE":
                        CommandLength = 3 #expected command need to have 3 arguments
                        try:
                            BeaconName = str(DIV[2].rstrip("\n"))
                            debugPrint(f"[+] Delete command - removing {BeaconName}")

                            if BeaconDetect.delete(BeaconName):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="OK")
                                debugPrint(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")

                        except IndexError:
                            debugPrint(f"[x] Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                            
                        except Exception:
                            debugPrint(f"[x] Failed to execute Append command")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "CLEAR" | "CLEAR\n":
                        debugPrint(f"[+] Clear command - cleaning list")

                        if BeaconDetect.clear():
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="OK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                        else:
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="NOK")
                            debugPrint(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "LIST\n" | "LIST":
                        debugPrint(f"[+] List command - current list {Action}")
                        BluetoothData = str(BeaconDetect.BeaconDict)
                        debugPrint(BluetoothData)
                        BServer.client_sock.send(BluetoothData.encode())

     else:
        try:
            log.warning( "[*] No command in the buffer... Waiting command" ) 
            BServer.Startup()              
            Timer = 0
        except Exception as e: 
            log.warning(f"[*] Unknown error - {e}")

            if Running:                        
                try:
                    running()
                except: pass                        
            else:
                time.sleep(1)
                Timer += 1
                os.system("sudo poweroff") if Timer == 1900 else log.debug(f"[*] Waiting for any bluetooth connection ({Timer} - 1900)")
            pass     

def Run():  
    global Timer,Running

    while not BServer.Startup(): #wait for first bluetooth connection
        pass

    while True: #Main loop
        try:                              
            Bdata = BServer.client_sock.recv(1024).decode('utf-8') #Converts Binary data to Decimal with maximum size of 1mb and store in a buffer          
            handle_bluetooth_data(Bdata)
 
        except KeyboardInterrupt:
            log.critical("\nProgram interrupted by user\n")
            exit()

        except (BServer.socket.timeout,ConnectionResetError):
            '''if any connection remains open for more than 5 minutes, the program will close it and restart'''

            if not Running: #if there is no data received and the program is not running, wait for a connection
                time.sleep(1)                

                if Timer == 300: #reset Voyager services if any connection remains open for more than 5 minutes
                    log.critical("[x] disconnecting bluetooth because nothing happened for a long time")
                    BServer.client_sock.close()
                    BServer.server_sock.close()
                    os.system("sudo systemctl restart Voyager.service")
                    sys.exit()
                else:
                    log.debug(f"Connection still open, board will reset soon ({Timer} - 300)")
                    Timer += 1

        finally:
            '''if the program is running, it will keep reading the data from the sensor and saving it in a csv file'''
            if Running:
                BServer.start_countdown = False
                running()
            else:
                BServer.start_countdown = True