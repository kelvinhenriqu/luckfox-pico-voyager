from configparser import ConfigParser
import os
import sys

CONFIGFILE = 'Voyager_Settings.ini'

def path(filename: str = 'Voyager_Settings.ini') -> str:
    'return a string with a path to a specific file, it will be different if the app is running as a .exe or as a code in vscode'

    #print("verifying if app is installed or being debugged...")
    if getattr(sys, 'frozen', False):
        #print(".Exe")
        app_path = os.path.join(os.path.dirname(sys.executable), filename)
        return app_path
    else:
        #print("Code")
        app_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), filename)#os.path.join(os.path.dirname(os.path.dirname(__file__)), CONFIGFILE)
        return app_path
    
def Config_Read():
    try:
        config = ConfigParser(comment_prefixes='#')
        settings_path = path(CONFIGFILE)
        #print(f"path to config file: {settings_path}")
        if os.path.exists(settings_path):
            config.read(settings_path, encoding='utf-8')
            return config
        else:
            print(f"Config file does not exist in {settings_path}")
            sys.exit()
            return False
    except Exception as e:
        print(f"exception {e} during config file loading...")
        sys.exit()
        return False
    
def config_write(section=None,item=None,value=None):
    if section == None and item == None and value == None:
        pass
    else:
        value = str(value)
        config = ConfigParser()
        settings = path()
        #print(f"path to config file: {settings}")
        config.read(settings, encoding='utf-8')

        config.set(section,item,value)
        
        with open(settings, 'w', encoding='utf-8') as configfile:
            config.write(configfile)