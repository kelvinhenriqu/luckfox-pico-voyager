from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from Voyager.Firmware.Pressure.I2C_SENSOR import I2C_Sensor
from Voyager.Firmware.Pressure.pressure_calibration import CalibratePressure
import os

Sensor = I2C_Sensor()
CURRENT_FACTOR = Sensor.Get_Factor()
CURRENT_OFFSET = Sensor.Get_offset()

# Define template folder relative to this file
template_folder = os.path.join(os.path.dirname(__file__), 'templates', 'pressure_calibration')
pressure_calib_bp = Blueprint('pressure_calib', __name__, 
                             url_prefix='/calibration/pressure',
                             template_folder=template_folder)

TOTAL = 7  # número de pontos de calibração recomendados

@pressure_calib_bp.route("/", methods=["GET"])
def index():
    session["calib_data"] = []
    return render_template(
        'pressure_index.html',
        current_factor=CURRENT_FACTOR,
        current_offset=CURRENT_OFFSET
    )

@pressure_calib_bp.route("/start", methods=["POST"])
def start():
    session["calib_data"] = []
    session["step"] = 1
    return redirect(url_for('pressure_calib.collect', step=1))

@pressure_calib_bp.route("/collect/<int:step>", methods=["GET", "POST"])
def collect(step):
    if request.method == "POST":
        real_pressure = float(request.form["real_pressure"])
        raw_pressure, _ = Sensor.read()
        
        # Add data point
        data = session.get("calib_data", [])
        data.append([raw_pressure, real_pressure])
        session["calib_data"] = data
        
        if step < TOTAL:
            return redirect(url_for('pressure_calib.collect', step=step+1))
        else:
            return redirect(url_for('pressure_calib.result'))
    
    # GET request - show collection form
    prevs = session.get("calib_data", [])
    if step > TOTAL:
        return redirect(url_for('pressure_calib.result'))
    
    return render_template('pressure_collect_step.html', step=step, total=TOTAL, prevs=prevs)

@pressure_calib_bp.route("/result", methods=["GET"])
def result():
    data = session.get("calib_data", [])
    if len(data) < 2:
        flash("Need at least 2 calibration points")
        return redirect(url_for('pressure_calib.index'))
    
    # Linear regression
    calibrator = CalibratePressure()
    raw_values = [point[0] for point in data]
    pressure_values = [point[1] for point in data]
    m, b = calibrator.linear_calibration(raw_values, pressure_values)
    
    return render_template('pressure_result.html', data=data, slope=f"{m:.8f}", intercept=f"{b:.5f}")

@pressure_calib_bp.route("/save", methods=["POST"])
def save():
    m = float(request.form["slope"])
    b = float(request.form["intercept"])
    
    Sensor.Set_factor(m)
    Sensor.Set_offset(b)
    
    return render_template('pressure_save.html')

@pressure_calib_bp.route("/sensor_test", methods=["GET"])
def sensor_test():
    return render_template('pressure_sensor_test.html')

@pressure_calib_bp.route("/api/sensor_reading", methods=["GET"])
def get_sensor_reading():
    try:
        raw_value, _ = Sensor.read()

        slope = Sensor.Get_Factor()
        intercept = Sensor.Get_offset()
        processed_value = slope * raw_value + intercept #linear regretion calculation

        return jsonify({
            "raw_value": raw_value,
            "processed_value": processed_value,
            "timestamp": "now"
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "raw_value": "Error",
            "processed_value": "Error"
        }), 500
