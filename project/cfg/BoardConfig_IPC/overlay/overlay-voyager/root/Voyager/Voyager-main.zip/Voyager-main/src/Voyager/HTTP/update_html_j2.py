update_html = '''
{% extends "base.html.j2" %}

{% block content %}
<h1>⬆️ Firmware Upload</h1>
<p>Select a <strong>.zip</strong> file to upload as new firmware.</p>

<form method="POST" enctype="multipart/form-data">
    <div style="margin: 20px 0;">
        <input type="file" id="fileInput" name="file" accept=".zip" required onchange="updateFileName()" style="display: none;">
        <label for="fileInput" class="btn">📁 Choose File</label>
        <span id="fileNameDisplay" style="margin-left: 10px; font-weight: bold; color: #555;">No file selected</span>
    </div>

    <input type="submit" class="btn" value="🚀 Upload Firmware">
</form>

<div style="margin-top: 30px;">
    <hr>
    <a href="/">🔙 Back</a>
</div>

<script>
    function updateFileName() {
        const input = document.getElementById('fileInput');
        const display = document.getElementById('fileNameDisplay');
        if (input.files.length > 0) {
            display.textContent = input.files[0].name;
        } else {
            display.textContent = "No file selected";
        }
    }
</script>
{% endblock %}
'''
