#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#04 - added battery level monitoring with FC2311.Battery()
#05 - converted to scuffing library
#06 - 13/10/2023 -now the value is in Newton

__Version__ = 6


import board
import busio
import digitalio
from adafruit_ads1x15.ads1115 import *
from adafruit_ads1x15.analog_in import AnalogIn
import time
import sys
from Voyager.Settings.Config import Config_Read
import ast #library to change from string to array

# Inicializa o barramento I2C
i2c = busio.I2C(board.SCL3, board.SDA3)

# Inicializa o ADS1115
ads = ADS1115(i2c) 
ads.mode = 256

# Define a taxa de ganho (amplificação). Pode ser ajustada conforme a faixa de tensão.
ads.gain = 1  # +/- 4.096V

# Cria canais de leitura analógica
canal_1 = AnalogIn(ads, P1)
canal_2 = AnalogIn(ads, P2)
canal_3 = AnalogIn(ads, P3)

#Definição dos pinos GPIO
try:
    Gpio1 = digitalio.DigitalInOut(board.D19)  # Para canal A1 (P1)
    Gpio2 = digitalio.DigitalInOut(board.D21)  # Para canal A2 (P2)
    Gpio3 = digitalio.DigitalInOut(board.D23)  # Para canal A3 (P3)

    Gpio1.direction = digitalio.Direction.OUTPUT
    Gpio2.direction = digitalio.Direction.OUTPUT
    Gpio3.direction = digitalio.Direction.OUTPUT

except OSError as e:
    if "[Errno 16]" in str(e):
        print(f"GPIO is already in use, Voyager.service is probably running... \nsudo lsof /dev/gpiochip0 can help to identify the service")
        sys.exit()

class MPU6050:
    
    def __init__(self):
        self.acc_x = None
        self.acc_y = None
        self.acc_z = None

        self.Gyro_x = None
        self.Gyro_y = None
        self.Gyro_z = None

    
    def read_acc(self,eixo=0):
        ax,ay,az = 1,1,1

        DivFactor = 10
        ax=round(ax,1)
        ay=round(ay,1)
        az=round(az,1)
        ax=ax*DivFactor
        ay=ay*DivFactor
        az=az*DivFactor

        match eixo:
            case 0:
                return ax,ay,az
            case 1:
                return ax
            case 2:
                return ay
            case 3:
                return az
            
    def read_gyro(self,eixo=0):
        x,y,z = 1,1,1

        match eixo:
            case 0:
                return x,y,z
            case 1:
                return x
            case 2:
                return y
            case 3:
                return z
            
    def Start(self):
        try:
            print(self.read_acc())
            print(self.read_gyro())
            pass
        except:
            print("erro de conexão com o sensor giroscopio")
            return 0
        return 0
    
class Scuffing:

    def __init__(self, gain=1):
        """
        :param gain: set gain 2/3, 1, 2, 4, 8, 16
        """
        self.GAIN = 1
        self.SCALE = 1
        self.grams = 0

        self.offset_list = self.var_check(
            Config_Read().get("General","offset")
            )
        
        self.factor_list = self.var_check(
        Config_Read().get("General","calibration_factor")
            )

        self.offset1 = self.offset_list[0]
        self.offset2 = self.offset_list[1]
        self.offset3 = self.offset_list[2]

        self.factor1 = self.factor_list[0]
        self.factor2 = self.factor_list[1]
        self.factor3 = self.factor_list[2]


    def _map(self, x, in_min, in_max, out_min, out_max):
        return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

    def set_gain(self, gain=1):

        """
        2/3 = +- 6.144v
        1   = +- 4.096v
        2   = +- 2.084v
        4   = +- 1.024v
        8   = +- 0.512v
        16  = +- 0.256v
        """

        try:
            ads.gain = gain
        except:
            self.GAIN = 1  # Sets default GAIN at 128

        self.read()
    
    def set_scale(self, scale):
        """
        Set scale
        :param scale, scale
        """
        self.SCALE = scale

    def set_offset(self, offset1, offset2, offset3): #three offset for all 3 sensors
        """
        Set the offset
        :param offset: offset
        """
        
        self.offset1,self.offset2,self.offset3 = offset1,offset2,offset3
    
    def set_factor(self, factor1, factor2, factor3): #three factors for all 3 sensors
        
        self.factor1,self.factor2,self.factor3 = factor1,factor2,factor3
    
    def get_scale(self):
        """
        Returns value of scale
        """
        return self.SCALE
    
    def get_offset(self):
        """
        Returns value of offset
        """
        return self.offset1,self.offset2,self.offset3
    
    def get_factor(self):
        """
        Returns value of offset
        """
        return self.factor1,self.factor2,self.factor3
    
    def GPIO_inject(self,x):
        Gpio1.value = x
        Gpio2.value = x
        Gpio3.value = x

    def adc_to_force(self, raw_adc):
        return 0.5 + (raw_adc * (150 - 0.5) / 2300)
    
    def read(self):
        """
        Read data from the scuffing sensors
        """
        self.GPIO_inject(True) #turn on 3.3v
        
        x1 = round(canal_1.voltage * 1000)
        x2 = round(canal_2.voltage * 1000)
        x3 = round(canal_3.voltage * 1000)

        TS1 = self.adc_to_force(x1)
        TS2 = self.adc_to_force(x2)
        TS3 = self.adc_to_force(x3)

        V1 = (TS1 - self.offset1) * self.factor1
        V2 = (TS2 - self.offset2) * self.factor2
        V3 = (TS3 - self.offset3) * self.factor3

        if V1 < 0: V1 = 0 #never return value below zero
        if V2 < 0: V2 = 0 #never return value below zero
        if V3 < 0: V3 = 0 #never return value below zero
        
        self.GPIO_inject(False) #turn off 3.3v
    
        
        return round(V1),round(V2),round(V3) #return Measure1, Measure2, Measure3

    def read_average(self, times=1):#16 default
        """
        Calculate average value from
        :param times: measure x amount of time to get average
        """
        sum = 0
        for i in range(times):
            sum += self.read()
        return sum / times
        

    def Start(self):
        """
        Power the ADC chip up and try to read any value
        """
        Test = self.grams
        try:
            self.GPIO_inject(1)
            time.sleep(1)
            a1,a2,a3 = self.read()      
            print(a1,a2,a3)
                  
            if (a1 > 5) and (a2 >= 0.5) and (a3 > 5):
                self.GPIO_inject(0)
                pass
            else:
                self.GPIO_inject(0)
                print("error occurred, please try again without weight")
                return 0
            
            return 0

        except OSError:
            print("\nFATAL ERROR, are the sensors connected ?\n")
            return 1

        except KeyboardInterrupt:
            print("\ncancelled by user\n")
            return 2

    def Stop(self):
        '''
        Power off the chip and stop to read from the sensor
        '''
        self.GPIO_inject(0)
    
    def var_check(self, raw):

        raw_list = ast.literal_eval(raw)
        #print(f"TIPO = {type(raw_list)} - VALOR = {raw_list}")
        if isinstance(raw_list,list):
            if len(raw_list) == 3:
                offset = raw_list
            else:
                print(f"calibration data saved in config file has a different length - {raw_list}, setting to 1")
                offset = [1,1,1]
        else:
            print(f"calibration data saved in config file is not a list - {raw_list}, setting it to 1")
            offset = [1,1,1]
            
        #print(f"OFFSET : {offset}")
        return offset

if __name__ == "__main__": 
    
    Sensor = Scuffing()
    StatusADC = Sensor.Start()

    MPU = MPU6050()
    StatusMPU = MPU.Start()
    
    #Sensor.set_offset(Sensor.config_file_check())

    if StatusADC == 0 and StatusMPU == 0:
        while True:
            RS1,RS2,RS3 = Sensor.read()
            ax,ay,az = MPU.read_acc()
            gx,gy,gz = MPU.read_gyro()
            print(f"Raw1={RS1}, Raw2={RS2}, Raw3={RS3}")
            print(f"AcX={ax}, AcY={ay}, AcZ={az}")
            #print(f"GcX={gx}, GcY={gy}, GcZ={gz}")
            time.sleep(0.1)

    elif StatusADC == 1 or StatusMPU == 1:
        print("\nFATAL ERROR, are the sensors connected ?") 
    else:
        print("\ndo not apply force in sensor starting process")
