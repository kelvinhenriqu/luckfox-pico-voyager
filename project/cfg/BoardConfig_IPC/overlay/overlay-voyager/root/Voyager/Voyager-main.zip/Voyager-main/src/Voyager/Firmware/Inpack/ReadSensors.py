#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import asyncio
from smbus2 import SMBus, i2c_msg
import digitalio
import board
import time
from Voyager.Settings.Config import Config_Read

use_custom_ntc_gain = Config_Read().getboolean('General','use_custom_ntc_gain',fallback=False)

class Ads1115:
    REG_CONVERSION = 0x00
    REG_CONFIG = 0x01

    mux_map = {0: 0b100, 1: 0b101, 2: 0b110, 3: 0b111}
    pga_values = {"2/3": 6.144, "1": 4.096, "2": 2.048, "4": 1.024, "8": 0.512, "16": 0.256}
    pga_bits = {"2/3": 0b000, "1": 0b001, "2": 0b010, "4": 0b011, "8": 0b100, "16": 0b101}

    def __init__(self, i2c, lock, address=0x48, gain="1"):
        self.i2c = i2c
        self.lock = lock
        self.address = address
        self.set_gain(gain)

    def set_gain(self, gain):
        if gain not in self.pga_values:
            raise ValueError(f"Invalid gain: {list(self.pga_values.keys())}")
        self.gain = gain
        self.pga_v = self.pga_values[gain]
        self.gain_bits = self.pga_bits[gain]

    async def read_channel(self, channel):
        if channel not in self.mux_map:
            raise ValueError("Invalid channel. Use 0, 1, 2 or 3.")
        mux_bits = self.mux_map[channel]

        config = 0
        config |= (1 << 15)
        config |= (mux_bits & 0b111) << 12
        config |= (self.gain_bits & 0b111) << 9
        config |= (1 << 8)
        config |= (0b100 << 5) if not use_custom_ntc_gain else (0b000 << 5) # 8SPS for custom NTC gain else 128SPS
        config |= 0b11

        config_bytes = [(config >> 8) & 0xFF, config & 0xFF]

        async with self.lock:
            self.i2c.write_i2c_block_data(self.address, self.REG_CONFIG, config_bytes)
            time.sleep(0.13) if use_custom_ntc_gain else None
            await asyncio.sleep(0.01)
            data = self.i2c.read_i2c_block_data(self.address, self.REG_CONVERSION, 2)

        raw = (data[0] << 8) | data[1]
        if raw > 0x7FFF:
            raw -= 0x10000
        
        if use_custom_ntc_gain:
            volts = ((raw - 3580) * (46481 - 10000) // (32760 - 3580) + 10000) / 10000
        else:
            volts = raw * (self.pga_v / 32768.0)
        
        
        return raw, volts

class NTCMF52:
    def __init__(self, i2c, lock, R1=10000, Vcc=3.2, beta=3950):
        self.lock = lock
        self.R1 = R1
        self.Vcc = Vcc
        self.beta = beta
        self.T0 = 298.15
        self.R0 = 10000
        self.Temp_temperature = -10.0
        self.Gpio1 = digitalio.DigitalInOut(board.D11)
        self.Gpio1.direction = digitalio.Direction.OUTPUT
        self.adc = Ads1115(i2c=i2c,lock=self.lock, address=0x48, gain="1")

    async def read(self):
        self.Gpio1.value = True
        try:
            _ , volts = await self.adc.read_channel(2)
            if volts > 0:
                Rntc = self.R1 * ((self.Vcc / volts) - 1)
                if Rntc > 0:
                    temp_k = 1 / (1 / self.T0 + (1 / self.beta) * math.log(Rntc / self.R0))
                    T_celsius = temp_k - 273.15
                    self.Temp_temperature = T_celsius
        except Exception as e:
            #print(f"⚠️ NTC Error: {e}")
            pass
        self.Gpio1.value = False
        return self.Temp_temperature

    def close(self):
        self.Gpio1.deinit()

class I2C_Sensor:
    def __init__(self, i2c, lock, address=0x78):
        self.lock = lock
        self.i2c = i2c
        self.address = address
        self.Pressure,self.Temperature = 0,0

    async def read(self):
        try:
            async with self.lock:
                self.i2c.write_byte(self.address, 0xAC)
                await asyncio.sleep(0.25)
                read = i2c_msg.read(self.address, 10)
                self.i2c.i2c_rdwr(read)
                data = list(read)
            
            p1 = bin(data[1])[2:].zfill(8)
            p2 = bin(data[2])[2:].zfill(8)
            p3 = bin(data[3])[2:].zfill(8)            
            t1 = bin(data[4])[2:].zfill(8)
            t2 = bin(data[5])[2:].zfill(8)

            DecPress = int(p1 + p2 + p3, 2)
            DecTemp = int(t1 + t2, 2)
            IntTemp = (((DecTemp / 65536) * 190) - 40) * 0.954
            Temperature = round(IntTemp, 1)
            
            return DecPress

        except Exception as e:
            dummy_press = -2
            return dummy_press
        
    def ReadAverage(self, times=10): #10 default

        sum = 0
        for i in range(times):
            p,t = self.read()
            sum += p

        self.Average = sum / times
        return self.Average

    def Tare(self, times=10):
        tare = self.ReadAverage(times)
        self.Set_offset(tare)


class DualReader:
    def __init__(self, i2c=SMBus(3)):
        self.i2c = i2c
        self.i2c_lock = None

    async def main(self):

        self.i2c_lock = asyncio.Lock()

        ntc = NTCMF52(i2c=self.i2c, lock=self.i2c_lock)
        pressure = I2C_Sensor(i2c=self.i2c, lock=self.i2c_lock)

        try:
            ntc_task = asyncio.create_task(ntc.read())
            pressure_task = asyncio.create_task(pressure.read())
            inicio = time.perf_counter()

            result = []

            for task in asyncio.as_completed([ntc_task, pressure_task]):
                value = await task    
                result.append(value)            
                #print(f'Result: {result} - {type(result)}')
                #print(result)
                

            results = {}
            results["ntc"] = result[0]
            results["pressure"] = result[1]

            fim = time.perf_counter()
            tempo_ms = (fim - inicio) * 1000
            
            
            # print(f"Time: {tempo_ms:.2f} ms")
            # print(f"Both tasks done: {all((ntc_task.done(), pressure_task.done()))}")
            # print("-------------------------------------------------\n")
            return results

        except KeyboardInterrupt:
            print("Terminated by user.")
