#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Python file to create a HTTPS server to manage Voyager data
# Considering 0.0.0.0 as any Ip address assigned to the board, possible urls are the following :
# https://0.0.0.0:8000/                # Just a Home screen
# https://0.0.0.0:8000/update/         # POST request to send the update file to the board, it will be in /home/rock/programa/update/ and need to be a .ZIP file.
# https://0.0.0.0:8000/measurements/   # GET request to receive a JSON data from the board containing the files in the /home/rock/programa/measurements/ directory.
# https://0.0.0.0:8000/status/         # GET request to receive the services status from the board. easy way to know if all services are running.

# REV 05 - 31/01/2024 - added /Status urls to verify that all services are running OK.

import urllib.request
from flask import Flask, request, jsonify, abort, send_file, render_template_string, render_template
from jinja2 import DictLoader
from pathlib import Path
from werkzeug.utils import secure_filename
import os
import datetime as dt
import subprocess

from Voyager.Settings.Config import Config_Read
from Voyager.HTTP.base_html_j2 import *
from Voyager.HTTP.index_html_j2 import *
from Voyager.HTTP.update_html_j2 import *
from Voyager.HTTP.status_html_j2 import *


#Get configurations in config file
DEVICE_TYPE = config.get('General','device_type')
ALLOWED_EXTENSIONS = {'txt', 'zip'}
config = Config_Read()
FOLDERPATH = config.get("Directories", "Measurements_Path")
UPLOAD_FOLDER = config.get("Directories", "Update_Path")
TEMPLATES_PATH = config.get("Directories", "Templates_Path")


CERTS_PATH = config.get("Directories", "Certs_Path")
KEYPEM_PATH = os.path.join(CERTS_PATH, "key.pem")
CERTPEM_PATH = os.path.join(CERTS_PATH, "cert.pem")

Debug = config.getboolean('HTTP_Service','Debug')

#Logging setup
from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[HTTP]", state=Debug)
log = SL.get_logger()

# Create the server instance
TEMPLATES = {
    "base.html.j2": Base_html,
    "index.html.j2": Index_html,
    "update.html.j2": update_html,
    "status.html.j2": Status_html,
}

app = Flask(__name__)
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024
app.jinja_loader = DictLoader(TEMPLATES)

match DEVICE_TYPE:
    case "Inpack":
        from Voyager.HTTP.webpage_pressure_calibration import pressure_calib_bp
        app.register_blueprint(pressure_calib_bp)
    case "Pressure":
        from Voyager.HTTP.webpage_pressure_calibration import pressure_calib_bp
        app.register_blueprint(pressure_calib_bp)
    case "Inpact":
        from Voyager.HTTP.webpage_scuffing_calibration import scuffing_calib_bp
        app.register_blueprint(scuffing_calib_bp)
    case "Load":
        from Voyager.HTTP.webpage_load_calibration import load_calib_bp
        app.register_blueprint(load_calib_bp)



def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/update', methods=['POST', 'GET'])
def upload_file():
    if request.method == "POST":
        log.debug("POST request")
        if 'file' not in request.files:
            resp = jsonify({'message': 'No file part in the request'})
            resp.status_code = 400
            return resp
        file = request.files['file']
        if file.filename == '':
            resp = jsonify({'message': 'No file selected for uploading'})
            resp.status_code = 422
            return resp
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            resp = jsonify({'message': 'File successfully uploaded'})
            resp.status_code = 201
            return resp
        else:
            resp = jsonify({'message': 'Allowed only zip files'})
            resp.status_code = 415
            return resp

    if request.method == "GET":
        log.debug("GET request")        
        return render_template("update.html.j2", title="Firmware Upload")

@app.route('/')
def index():
    return render_template("index.html.j2", title="Voyager Monitoring WebPage")

def getReadableByteSize(num, suffix='B') -> str:
    for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Y', suffix)

def getTimeStampString(tSec: float) -> str:
    tObj = dt.datetime.fromtimestamp(tSec)
    tStr = dt.datetime.strftime(tObj, '%Y-%m-%d %H:%M:%S')
    return tStr

def getIconClassForFilename(fName):
    fileExt = Path(fName).suffix
    fileExt = fileExt[1:] if fileExt.startswith(".") else fileExt
    fileTypes = ["aac", "ai", "bmp", "cs", "css", "csv", "doc", "docx", "exe", "gif", "heic", "html", "java", "jpg", "js", "json", "jsx", "key", "m4p", "md", "mdx", "mov", "mp3",
                 "mp4", "otf", "pdf", "php", "png", "pptx", "psd", "py", "raw", "rb", "sass", "scss", "sh", "sql", "svg", "tiff", "tsx", "ttf", "txt", "wav", "woff", "xlsx", "xml", "yml"]
    fileIconClass = f"bi bi-filetype-{fileExt}" if fileExt in fileTypes else "bi bi-file-earmark"
    return fileIconClass

@app.route('/measurements/', defaults={'reqPath': ''})
@app.route('/measurements/<path:reqPath>')
def getFiles(reqPath):
    absPath = os.path.join(FOLDERPATH, reqPath)

    if not os.path.exists(absPath):
        # Ensure the directory exists
        os.makedirs(absPath, exist_ok=True)
        # Return an empty list since the directory was just created
        return jsonify([])

    if os.path.isfile(absPath):
        return send_file(absPath)
    
    def fObjFromScan(x):
        fileStat = x.stat()
        return {'name': x.name, 'relativePath': os.path.relpath(x.path, FOLDERPATH).replace("\\", "/")}
    
    fileObjs = [fObjFromScan(x) for x in os.scandir(absPath)]
    return jsonify(fileObjs)

@app.route('/status', methods=['POST', 'GET'])
def Home():
    if request.method == "POST":
        return "method not allowed in this url."
    if request.method == "GET":
        pressurepackage = IsRunning("Voyager.service")
        HTTPService = IsRunning("HTTPVOYAGER.service")
        BluetoothService = IsRunning("VoyagerBluetooth.service")

        return render_template("status.html.j2",
                               pressure=pressurepackage,
                               bluetooth=BluetoothService,
                               http=HTTPService,
                               title="Voyager Status")

def IsRunning(service_name):
    stat = subprocess.call(["systemctl", "is-active", "--quiet", service_name]) 
    if stat == 0:
        log.info(f"Process {service_name} : Running")
        return True
    else:
        log.info(f"Process {service_name} : Stopped")
        return False

def command(cmd):
    os.system(cmd)

def create_certificates():
    log.warning("creating folders")
    command('sudo mkdir -p ' + CERTS_PATH)
    
    log.warning("creating certificates files") 

    ssl_command = [
        "openssl", "req",
        "-newkey", "rsa:2048",
        "-new",
        "-nodes",
        "-x509",
        "-days", "3650",
        "-keyout", "key.pem",
        "-out", "cert.pem",
        "-subj", "/C=BR/ST=Sao Paulo/L=Jundiai/O=Voyager/CN=example.local",
        "-addext", "subjectAltName=DNS:example.local,DNS:localhost"
    ]

    try:
        subprocess.run(ssl_command, check=True)
        log.info("SSL certificate and key generated successfully.")
    except subprocess.CalledProcessError as e:
        log.critical(f"An error occurred while generating the certificate: {e}")
    except Exception as e:
        log.critical(f"Unknown Error: {e}")

    #command(ssl_command)
    
    log.warning("moving files to folders")
    command("sudo mv cert.pem " + CERTPEM_PATH)
    command("sudo mv key.pem " + KEYPEM_PATH)

    log.warning("DONE")

def run_server():
    IP = config.get("HTTP_Service", "IP")
    PORT = config.getint("HTTP_Service", "Port")

    #IP = '0.0.0.0'
    #PORT = 8000
    app.run(host=IP, port=PORT, ssl_context=(CERTPEM_PATH, KEYPEM_PATH))

def Create_HTTP_Template():
    """
    Creates the files.html.j2 template in the specified TEMPLATES_PATH directory.
    """
    try:
        log.info(f"Trying to create http templates")
        # Ensure the directory exists
        os.makedirs(CERTS_PATH, exist_ok=True)

        # Define the full file path
        file_path = TEMPLATES_PATH #os.path.join(TEMPLATES_PATH, "files.html.j2")

        # Define the template content
        template_content = """<!--Template file-->
<!--templates/files.html.j2-->
<h2>Measurements Directory Listing</h2>
<table class="table table-striped table-responsive">
    <thead>
        <tr>
            <th>Name</th>
            <th>Modified Time</th>
            <th>Size</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <a href="{{ url_for('getFiles', reqPath=data['parentFolder']) }}">
                    <span><i class="bi bi-folder-symlink" style="margin-right:0.3em"></i>Parent Directory</span>
                </a>
            </td>
            <td></td>
            <td></td>
        </tr>
        {% for fileObj in data['files'] %}
        <tr>
            <td>
                <a href="{{ url_for('getFiles', reqPath=fileObj['relPath']) }}">
                    <span><i class="{{fileObj['fIcon']}}" style="margin-right:0.3em"></i>{{ fileObj['name'] }}</span>
                </a>
            </td>
            <td>{{fileObj['mTime']}}</td>
            <td>{{fileObj['size']}}</td>
        </tr>
        {% endfor %}
    </tbody>
</table>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

<style>
table {table-layout:fixed; width:100%;}
table td, th {word-wrap:break-word;}
th {text-align: left;}
</style>
"""

        # Write the content to the file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(template_content) 
            log.info(f"OK")
            return True

    except Exception as e:
        log.critical(f"critical error: {e}") 
        return False

def Run():
    log.info("trying to run http server...")
    if not os.path.exists(KEYPEM_PATH) or not os.path.exists(CERTPEM_PATH):
        log.error("certificates files not found")
        log.warning("creating certificates files")
        create_certificates()
    else:
        log.info("certificates files found")

    run_server()

    '''if os.path.exists(TEMPLATES_PATH): 
        log.info("OK, starting server...")
        run_server()
    else:
        log.error("ERROR, no HTTP templates found")
        #os.system("sudo wget https://raw.githubusercontent.com/kelvinhenriqu/Voyager-Public/main/files.html.j2 -P "+ str(TEMPLATES_PATH))
        #status = Create_HTTP_Template()        
        if status:
            Run()
        else:
            log.critical(f"critical error occured . . .")'''

if __name__ == '__main__':
    Run()
