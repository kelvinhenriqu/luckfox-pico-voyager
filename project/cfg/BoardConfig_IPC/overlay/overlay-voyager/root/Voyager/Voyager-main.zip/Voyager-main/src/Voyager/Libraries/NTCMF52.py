#Decrapted - not used in any current firmware

import time
import math
import digitalio
import board
from Voyager.Libraries.Ads1115 import Ads1115

class NTCMF52():
    def __init__(self, R1=10000, Vcc=3.2, beta=3950):
        self.R1 = R1         # Resistor fixo do divisor de tensão (Ohms)
        self.Vcc = Vcc          # Tensão de alimentação do divisor (V)
        self.beta = beta
        self.T0 = 298.15        # Temperatura de referência (25°C = 298.15 K)
        self.R0 = 10000         # Resistência do termistor a T0 (10kΩ)
        self.Temp_temperature = -10.0
        
        # Inicializa GPIO uma vez
        self.Gpio1 = digitalio.DigitalInOut(board.D11)
        self.Gpio1.direction = digitalio.Direction.OUTPUT
        
        # Instância do ADC uma vez
        self.adc = Ads1115(bus_num=3, address=0x48, gain=1)

    def read(self):
        self.Gpio1.value = True
        
        try:
            raw, volts = self.adc.read_channel(2)
            if volts <= 0:
                print(f"⚠️ Tensão inválida: {volts:.3f}V — verifique conexões.")
            else:
                Rntc = self.R1 * ((self.Vcc / volts) - 1)
                if Rntc > 0:
                    try:
                        temp_k = 1 / (1 / self.T0 + (1 / self.beta) * math.log(Rntc / self.R0))
                        T_celsius = temp_k - 273.15
                        print(f"Raw = {raw}, Rntc = {Rntc:.2f}Ω, Voltage = {volts:.2f}V, Temp = {T_celsius:.2f}°C")
                    except Exception as e:
                        print(f"⚠️ Erro ao calcular temperatura: {e}")
                else:
                    print(f"⚠️ Rntc inválido: {Rntc:.2f}Ω (Vcc = {self.Vcc:.2f}V, V = {volts:.2f}V)")
            
            self.Temp_temperature = T_celsius
        except OSError as e:
            #print(f"⚠️ Erro de leitura (OSError), retornando o último valor de temperatura disponível - {e}")
            print(f"Unknown error during temperature measurement - {e}")
            pass
        
        except Exception as e:
            print(f"⚠️ Erro desconhecido na leitura de temperature - {e}")
        self.Gpio1.value = False
        return self.Temp_temperature