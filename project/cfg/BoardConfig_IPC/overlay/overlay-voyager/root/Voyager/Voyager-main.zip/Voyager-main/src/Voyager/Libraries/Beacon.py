import asyncio
import time

from uuid import UUID

from construct import Array, Byte, Const, Int8sl, Int16ub, Struct
from construct.core import ConstError

from bleak import BleakScanner
from bleak.backends.device import BLEDevice
from bleak.backends.scanner import AdvertisementData

import traceback #Debug erros inside the Thread with print(traceback.format_exc()) after expect

from Voyager.Settings.Config import Config_Read

ibeacon_format = Struct(
    "Type_Lenght" / Const(b"\x02\x15"),
    "uuid" / Array(16, Byte),
    "major" / Int16ub,
    "minor" / Int16ub,
    "power" / Int8sl,
)

class BeaconDetector():

    def __init__(self):
        self.BeaconDict = {}    #Dictionary with all assigned beacons
        self.Debug = Config_Read().getboolean("Beacon","Debug")      #show print or not 
        self.ScanSleep = 1      #Sleep time between BLE scan
        self.StopEvent = False  #Break asyncio loop
        self.target_uuid = Config_Read().get("Beacon","Beacon_UUID")
        
    def DebugPrint(self,data):
        print(data) if self.Debug else None

    def append(self,name,threshold): #append a specific beacon to the allowed list
        name = int(name) #BeaconName need to be a int number
        if not name in self.BeaconDict:
            self.BeaconDict[name]=[False,threshold]
            self.DebugPrint(f"** appending {name}, {threshold} as threshold, new list: {self.BeaconDict}")
            return True
        else:
            self.DebugPrint(f"** {name} already in the list: {self.BeaconDict}")
    
    def delete(self,name): #Delete a specific beacon from the allowed list
        self.BeaconDict.pop(name,None)
        self.DebugPrint(f"** removing {name}, new list: {self.BeaconDict}")
        return True

    def clear(self): #Clear the list of allowed beacons
        self.BeaconDict.clear()
        self.DebugPrint(f"** list cleared: {self.BeaconDict}")
        return True

    def Device_Found(self, device: BLEDevice, advertisement_data: AdvertisementData): #Identify if the device is a Ibeacon and parse the data
        try:
            apple_data = advertisement_data.manufacturer_data.get(0x004C)#identify Ibeacon

            if apple_data: #Verify if it is a Ibeacon
                ibeacon = ibeacon_format.parse(apple_data) #Format the data to Ibeacon format
                uuid = UUID(bytes=bytes(ibeacon.uuid))

                if str(uuid) == str(self.target_uuid): #Verify if it is a Voyager beacon

                    self.DebugPrint(47 * "_")
                    self.DebugPrint(f"** Allowed devices list: {self.BeaconDict}")
                    self.DebugPrint(f"** Voyager Beacon detected: {ibeacon.minor}")

                    NFactor = 1.2
                    Distance = round(10**((ibeacon.power - advertisement_data.rssi)/(10*NFactor)),1)

                    if ibeacon.minor in self.BeaconDict: #if Beacon in the allowed list and in the allowed distance
                        try:
                            self.Threshold = self.BeaconDict[ibeacon.minor][1]
                            self.State = self.BeaconDict[ibeacon.minor][0]

                            self.DebugPrint(f"      ** {ibeacon.minor} is in list {self.BeaconDict}, threshold is {self.State}")
                            self.DebugPrint(f"      ** Distance = {Distance} Meters")

                            self.BeaconDict[ibeacon.minor][0] = int(Distance) <= int(self.Threshold)
                            self.DebugPrint(f"      ** {ibeacon.minor} {'close enough' if self.BeaconDict[ibeacon.minor][0] else 'too far'}, changing to {self.BeaconDict[ibeacon.minor][0]}")

                            self.DebugPrint(f"      ** new list: {self.BeaconDict}")

                        except Exception as e:
                            print(20*"& ",f"({e})",20*" &")
                            print(traceback.format_exc())
                        
                    else:
                        self.DebugPrint(f"** {ibeacon.minor} is a Voyager Beacon but its not in the allowed list ({self.BeaconDict})")

                else:
                    self.DebugPrint(f"** Not a Voyager beacon, expected ({self.target_uuid}) but ({uuid})")

        except KeyError as e:
            pass
        except ConstError:
            pass 
        except Exception as e:
            print(f"Error {e}") 
            pass  

    async def main(self): #Scan for BLE devices

        scanner = BleakScanner(detection_callback=self.Device_Found)
        
        await scanner.start()
        try:
            while not self.StopEvent:
                await asyncio.sleep(0.1)
        finally:
            await scanner.stop()

        print("Loop broken")
 
    def run(self): #Start the Ble reading asyncio function
        self.StopEvent = False
        self.task = asyncio.run(self.main())

    def read(self): #send the Dictionary to main script 
        return self.BeaconDict

    def stop(self): #Set the stop event to break the loop
        self.StopEvent = True


if __name__ == "__main__":

    BeaconDetector = BeaconDetector()
    BeaconDetector.clear()
    BeaconDetector.append(15902,10)

    BeaconDetector.run()
    print("depois do asyncio",10*"_")
