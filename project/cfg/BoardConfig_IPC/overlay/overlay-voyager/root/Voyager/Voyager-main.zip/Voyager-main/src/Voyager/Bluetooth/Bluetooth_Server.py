import socket  # sockets connection
import os
import time
from Voyager.Settings.Config import Config_Read
import sys

#Get configurations in config file
Debug = Config_Read().getboolean('General','Debug')

#Logging setup
from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[BSERVER]", state=Debug)
log = SL.get_logger()

class Bluetooth_Server():
    
    def __init__(self):
        self.timer = 0
        self.debug = Config_Read().getboolean("General", "Debug")
        self.addrs = Config_Read().get("General", "IP")
        self.port = Config_Read().getint("General", "Port")
        self.server_sock = None
        self.client_sock = None
        self.address = None
        self.socket = socket
        self.start_countdown = True

        self.IDLE_TIMEOUT = 600000  #maximum time to wait for new connections (miliseconds) - 600000 = 10 minutes
        self.CONNECTION_TIMEOUT = 0.01  #wait this amount of time after a new connection attempt before save it in the socket
        self.SLEEP_INTERVAL = .001  #if no connection is established, wait this amount of seconds before reconnecting

    def Config(self) -> None:
        'Try to create host bluetooth connection in an specified port and ip'
        
        try:
            self.server_sock = socket.socket()
            self.server_sock.bind((self.addrs, self.port))
            self.server_sock.listen(1)
            log.info(f"[*] Listening as {self.addrs}:{self.port}")
        except OSError as error:
            log.error(f"Error: {error}")
            log.critical("[x] Error 98 - address in use, killing process . . .")
            os.system("sudo pkill -9 python")
            if self.server_sock:
                self.server_sock.close()
            sys.exit()

    def Startup(self) -> bool:
        'After Bluetooth host server creation, it will start listening for new connections attempts and return True if successful connection'

        try:
            self.server_sock.settimeout(self.CONNECTION_TIMEOUT)
            self.client_sock, self.address = self.server_sock.accept()
            self.client_sock.settimeout(self.CONNECTION_TIMEOUT)
            log.info(f"[+] Accepted connection from {self.address}")
            self.timer = 0
            return True

        except socket.timeout:
            if self.start_countdown:
                time.sleep(self.SLEEP_INTERVAL)
                self.timer += .1
                if self.timer >= self.IDLE_TIMEOUT:
                    log.critical("[x] Shutting down due to inactivity")
                    os.system("sudo poweroff")
                else:
                    log.debug(f"[*] Idle mode, waiting for connection ({round(self.timer,1)}/{self.IDLE_TIMEOUT})")
            else:
                log.debug("[*] Idle mode without timeout")

            return False
        except OSError as e:
            log.critical(f"Socket error: {e}")
            return False

    def close(self)->None:
        'Close server and cliente sockets to prevent more then one socket using the same ip/port'
        if self.client_sock:
            self.client_sock.close()
        if self.server_sock:
            self.server_sock.close()