#novo arquivo
import os
import shutil
import zipfile
from Voyager.Settings.Config import Config_Read
import sys

# Global variables from config file

class Update_firmware:
    def __init__(self):
        self.expected_zip_file_name = Config_Read().get("Update_Process", "ZIP_Filename")
        self.main_folder_path = Config_Read().get("Update_Process", "Main_Folder_Path")
        self.log_file_path = Config_Read().get("Update_Process", "Log_File_Path")
        self.Debug = Config_Read().get("Update_Process", "Save_Log")
        self.update_path = Config_Read().get("Directories", "Update_Path")

        self.success_bit = Config_Read().get("Update_Process", "Success_Update_Message")
        self.bad_bit = Config_Read().get("Update_Process", "Bad_Update_Message")
        self.zip_file_path = f"{self.update_path}{self.expected_zip_file_name}"

        self.update_main_folder()

    def log(self,message,delete=False): # Function to log messages into the update log file and print to the screen
        if delete:
            print(message)
            with open(self.log_file_path, "w") as log_file:
                log_file.write("")
        if self.Debug == "True":
            print(message)
            with open(self.log_file_path, "a") as log_file:
                log_file.write(message + "\n")

    def make_backup(self):
        'Performs a backup of the Main folder by removing the old backup folder if it exists and then copying the current Main folder to the backup location.'
        backup_path = f"{self.main_folder_path}_backup/"
        try:
            shutil.rmtree(backup_path)
            self.log("Removed old backup Folder")
        except Exception as e:
            self.log(f"error during backup folder deletion: {e}")

        try:
            shutil.copytree(self.main_folder_path, backup_path,dirs_exist_ok=True)
            self.log("Backup of the Main folder has been successfully created.")
        except FileNotFoundError:
            self.log(f"folder {self.main_folder_path} or {backup_path} not found . . .")
            self.restore_backup()    

    def move_zip_file(self):
        'Move the zip file to the root folder'
        new_path = self.main_folder_path + "/" + self.expected_zip_file_name
        shutil.copy(self.zip_file_path,new_path)
        self.zip_file_path = new_path
        self.log("ZIP file has been moved to the project folder.")
    
    def verify_zip_file(self):
        'Verify if the zip file exists'
        path = self.zip_file_path
        if not os.path.exists(path):
            self.log("There is no zip file")
            self.restore_backup()
        else:
            self.log("Zip file exists in the project folder")
            pass
            
    def remove_main_folder(self):
        'Remove the files before extracting '
        try:
            shutil.rmtree(self.main_folder_path)
            self.log("Removed Main Folder")
        except FileNotFoundError:
            pass

    def extract_zip_file(self):
        'Extract the zip file into the root folder'
        try:
            with zipfile.ZipFile(self.zip_file_path, 'r') as zip_ref:
                zip_ref.extractall(self.main_folder_path)
            self.log("ZIP file has been successfully extracted.")
        except FileNotFoundError:
            self.log(f"Zip file not found in {self.zip_file_path}")
            self.restore_backup()
        except zipfile.BadZipFile :
            self.log("Zip file is corrupted or its not a zip file")
            self.restore_backup()

    def verify_extraction(self):
        'Verify if the ZIP file has been extracted correctly and restore backup if it isnt.'
        main_folder_content = os.listdir(self.main_folder_path)
        if main_folder_content:
            self.log("Extraction of the ZIP file has been successfully verified.")
        else:
            self.log("Error: The ZIP file has not been extracted correctly.")
            self.restore_backup()

    def remove_files(self):# Delete files used during update
        '''This function removes the backup folder and the zip file used for the update process.
        If any error occurs during the deletion process, it logs a message indicating that it's not necessary to restore backups.'''
        backup_path = f"{self.main_folder_path}_backup"
        try:
            shutil.rmtree(backup_path)
            os.remove(self.zip_file_path)
            self.log("files used during update flushed successfully")
        except:
            self.log("Impossible to remove files used during update, no need to restore backups.")

    def set_permissions(self):
        'This function sets the permissions of the main folder to 777.'
        try:
            os.system(f"sudo chmod 777 {self.main_folder_path}")
            os.system(f"sudo chmod 777 {self.main_folder_path}Voyager")
            self.log("Folders and files permissions set to 777")
        except Exception as e:
            print(e)
            self.log("Impossible to set permissions, not need to restore backups.")

    def restart_process(self):
        'Restart Voyager process'
        os.system("sudo /bin/systemctl start Voyager.service")
        sys.exit()

    def restore_backup(self):
        'Rollback to old files if anything wrong happens during the update process.'
        try:
            backup_path = f"{self.main_folder_path}_backup"
            if not os.path.exists(backup_path):
                self.log("Backup folder not found, impossible to restore.")
                self.log(self.bad_bit)
                self.restart_process()
                sys.exit()
            else:            
                shutil.rmtree(self.main_folder_path)
                shutil.copytree(backup_path, self.main_folder_path)
                self.log("Backup has been successfully restored.")
                self.log(self.bad_bit)
                self.restart_process()
                sys.exit()
        except Exception as e:
            self.log(f"Unknown error during backup restoration: {e}")
            self.log(self.bad_bit)
            self.restart_process()
            sys.exit()

    def update_main_folder(self):# Main function to perform the update
        self.log("Log Cleaned.",True)
        # Check if the ZIP file exists and has the expected name
        if os.path.exists(self.zip_file_path) and os.path.basename(self.zip_file_path) == self.expected_zip_file_name:
            self.make_backup()
            self.move_zip_file()
            self.verify_zip_file()
            #self.remove_main_folder()
            self.extract_zip_file()
            self.verify_extraction()
            self.log("Successfully updated.")
            #self.remove_files()
            self.set_permissions()
            self.log("Setting success bit")
            self.log(self.success_bit)
            self.log("Restarting process.")
            self.restart_process()
        else:
            self.log("Error: ZIP file not found or incorrect name.")
            self.log(self.bad_bit)

if __name__ == "__main__": # Call the main function to start the update process
    print("Not possible to start like that")
