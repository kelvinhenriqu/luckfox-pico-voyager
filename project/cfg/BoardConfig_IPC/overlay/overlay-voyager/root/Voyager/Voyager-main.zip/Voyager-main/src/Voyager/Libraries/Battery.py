#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#01 - Battery Management Controller using Voyager IO Board 

__VERSION__ = 54

import adafruit_max1704x
import busio
import board
import time
from Voyager.Settings.Config import Config_Read

class Fuel_Gauge():
    def __init__(self,LowAlert=3.5,HighAlert=4.1):

        self.config = Config_Read()

        i2c = busio.I2C(board.SCL3, board.SDA3) #PIN 14 and 15
        self.Gauge = adafruit_max1704x.MAX17048(i2c)

        self.Gauge.voltage_alert_min = LowAlert #Min Voltage for Alert
        self.Gauge.voltage_alert_max = HighAlert #Max Voltage for Alert

        # print("Quick starting")
        self.Gauge.quick_start = False

        self.changer_state = False
    
    def Hibernate(self):
        self.Gauge.hibernate()
        print("Hibernating")
        
    def Wake(self):
        self.Gauge.wake()
        print("Waking")

    def Calibrate(self):
        self.Gauge.reset()
        time.sleep(2)

    def Read_Voltage(self):
        return self.Gauge.cell_voltage
    
    def Read_Percentage(self):
        if self.Gauge.SOC_change_alert:
            self.changer_state = True
            print("Battering charging")
            self.Gauge.SOC_change_alert = False  # clear the alert

        if self.Gauge.hibernating:
            print("Hibernating!")
            self.Wake()
        return self.Gauge.cell_percent
    
    def Battery_Status(self):
        HighStatus = self.Gauge.voltage_high_alert
        LowStatus = self.Gauge.voltage_low_alert

        self.Gauge.voltage_high_alert = False
        self.Gauge.voltage_low_alert = False

        return HighStatus, LowStatus #Charging state,Low battery
    
    def Charge_State(self):
        self.Gauge.SOC_change_alert

if __name__ == "__main__":
    Battery = Fuel_Gauge()
    Battery.Wake()
    tt = 0
    while True:
        tt = tt+1
        if (tt==2):
            Battery.Calibrate()
            break
