from Voyager.Settings.Config import Config_Read

config = Config_Read()

DEVICE_TYPE = config.get('General','device_type')
DEVICE_NAME = config.get('General','fullname')
DEVICE_BOARD_SERIAL = config.get('General','board_serial')

cal_endpoints = {
    "Pressure": "/calibration/pressure",
    "Impact": "/calibration/scuffing",
    "Inpack": "/calibration/pressure",
    "Load": "/calibration/load"
}
cal_endpoint = cal_endpoints.get(DEVICE_TYPE, "/")

Index_html = f'''
{{% extends "base.html.j2" %}}

{{% block content %}}
<h1>Voyager Interface</h1>
<div id="sensor-data" style="font-family: monospace; font-size: 18px; padding: 20px; background: #f0f0f0; margin: 20px 0;">
    <div>Device Name: {DEVICE_NAME}</div>
    <div>Device Type: {DEVICE_TYPE}</div>
    <div>Board Serial: {DEVICE_BOARD_SERIAL}</div>
</div>
<ul>
    <form method="GET" action="/measurements/">
        <button class="btn" type="submit" style="width: 350px">📂 Measurements</button>
    </form>
    <form method="GET" action="/status">
        <button class="btn" type="submit" style="width: 350px">⚙️ Service Status</button>
    </form>
    <form method="GET" action="/update">
        <button class="btn" type="submit" style="width: 350px">⬆️ Firmware Update</button>
    </form>
    <form method="GET" action={cal_endpoint}>
        <button class="btn" type="submit" style="width: 350px">🛠️ Calibrate Sensor</button>
    </form>
</ul>
{{% endblock %}}
'''