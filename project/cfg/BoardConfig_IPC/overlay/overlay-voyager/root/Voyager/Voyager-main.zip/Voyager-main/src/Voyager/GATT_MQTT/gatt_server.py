from __future__ import print_function
import dbus
import dbus.exceptions
import dbus.mainloop.glib
import dbus.service 
from dbus import ByteArray

import paho.mqtt.client as mqtt

import json
import base64
import random
import time
import datetime
import threading

import functools

from .exceptions import *
from .adapters import *

from Voyager.Settings.Config import Config_Read

#Get configurations in config file
Debug = Config_Read().getboolean('GATT_Service','Debug')
Model_Number_String = Config_Read().get('General','fullname')
Serial_Number_String = Config_Read().get('General','board_serial')

from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[BLE]", state=Debug)
log = SL.get_logger()

BLUEZ_SERVICE_NAME = 'org.bluez'
LE_ADVERTISING_MANAGER_IFACE = 'org.bluez.LEAdvertisingManager1'
DBUS_OM_IFACE = 'org.freedesktop.DBus.ObjectManager'
DBUS_PROP_IFACE = 'org.freedesktop.DBus.Properties'

LE_ADVERTISEMENT_IFACE = 'org.bluez.LEAdvertisement1'

GATT_MANAGER_IFACE = 'org.bluez.GattManager1'

GATT_SERVICE_IFACE = 'org.bluez.GattService1'
GATT_CHRC_IFACE =    'org.bluez.GattCharacteristic1'
GATT_DESC_IFACE =    'org.bluez.GattDescriptor1'

MANUFACTURER_NAME = 'Voyager Beyond Technologies'
MANUFACTURER_NUMBER = Model_Number_String
MANUFACTURER_SERIAL = Serial_Number_String

Status = [0]
Status_update = True
data = [0]
data_update = True
command = []

class MqttTreat:
    'Treats connection,read and write MQTT functions'

    def __init__(self):
        # Configuração do MQTT
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message
        self.mqtt_client.connect("localhost", 1883, 60)
        self.mqtt_client.loop_start()

        self.data = ["measurements/data","measurements/status","measurements/command"]

        threading.Thread(target=self.write_mqtt_example).start() #Keep sending random values

    
    def on_connect(self, client, userdata, flags, rc):
        'Callback para conexão MQTT'
        log.info(f"[MQTT] Connected! Code: {rc}")
        client.subscribe(self.data[0])
        client.subscribe(self.data[1])
        client.subscribe(self.data[2])

    def on_message(self, client, userdata, msg):
        'Callback para mensagens MQTT'
        try:
            
            value = msg.payload.decode()             
            #log.info(f"[MQTT] Value {value} received on {msg.topic}")

            value_str = json.dumps(value)
            value_bytes = value_str.encode("utf-8")
            value_base64 = base64.b64encode(value_bytes)

            if msg.topic == self.data[0]: #"measurements/data"
                global data,data_update
                #log.info(f"[GATT] Updating {self.data[0]} to {value} in base64 - {value_base64}")
                data = value_base64
                data_update=True

            elif msg.topic == self.data[1]: #"measurements/status"
                global Status,Status_update
                #log.info(f"[GATT] Updating {self.data[1]} to {value} in base64 - {value_base64}")
                Status = value_base64
                Status_update=True

            elif msg.topic == self.data[2]: #"measurements/command"
                global command
                #log.info(f"[GATT] Command received on {self.data[2]} = {value}")
                

        except ValueError:
            log.error("[ERROR] Invalid value in MQTT.")
    
    def write_to_topic(self,topic,data):
        'Writes payload to an specic topic'
        #log.info(f"[MQTT] Writing {data} to {topic}")
        self.mqtt_client.publish(topic,data)
    
    def write_mqtt_example(self):
        'Dummy function to keep writing values to MQTT server'

        log.warning(f"[MQTT] Starting writing example in 5 seconds")
        time.sleep(5)
        while True:

            now = datetime.datetime.now()
            time_formatted = now.strftime("%Y%m%d%H%M%S%f")
            data1 = random.triangular(10, 50)
            data2 = random.triangular(50, 100)
            data3 = random.triangular(100, 150)
            data4 = random.triangular(150, 200)

            json_value = {
                "Timestamp": time_formatted,
                "Beacon": "",
                "Data1": data1,
                "Data2": data2,
                "Data3": data3,
                "Data4": data4
            }
            json_str = json.dumps(json_value)
            self.write_to_topic("measurements/data",json_str)

            time.sleep(.1)

#Services classes
class Application(dbus.service.Object):
    """
    org.bluez.GattApplication1 interface implementation
    """
    def __init__(self, bus):
        self.path = '/'
        self.services = []
        dbus.service.Object.__init__(self, bus, self.path)
        self.add_service(DeviceInformationService(bus, 0))
        self.add_service(DataService(bus, 1))

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_service(self, service):
        self.services.append(service)

    @dbus.service.method(DBUS_OM_IFACE, out_signature='a{oa{sa{sv}}}')
    def GetManagedObjects(self):
        response = {}
        log.info('[GATT] GetManagedObjects')

        for service in self.services:
            response[service.get_path()] = service.get_properties()
            chrcs = service.get_characteristics()
            for chrc in chrcs:
                response[chrc.get_path()] = chrc.get_properties()
                descs = chrc.get_descriptors()
                for desc in descs:
                    response[desc.get_path()] = desc.get_properties()

        return response

class Service(dbus.service.Object):
    """
    org.bluez.GattService1 interface implementation
    """
    PATH_BASE = '/org/bluez/Voyager/service'

    def __init__(self, bus, index, uuid, primary):
        self.path = self.PATH_BASE + str(index)
        self.bus = bus
        self.uuid = uuid
        self.primary = primary
        self.characteristics = []
        dbus.service.Object.__init__(self, bus, self.path)

    def get_properties(self):
        return {
                GATT_SERVICE_IFACE: {
                        'UUID': self.uuid,
                        'Primary': self.primary,
                        'Characteristics': dbus.Array(
                                self.get_characteristic_paths(),
                                signature='o')
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_characteristic(self, characteristic):
        self.characteristics.append(characteristic)

    def get_characteristic_paths(self):
        result = []
        for chrc in self.characteristics:
            result.append(chrc.get_path())
        return result

    def get_characteristics(self):
        return self.characteristics

    @dbus.service.method(DBUS_PROP_IFACE,in_signature='s',out_signature='a{sv}')
    def GetAll(self, interface):
        if interface != GATT_SERVICE_IFACE:
            raise InvalidArgsException()

        return self.get_properties()[GATT_SERVICE_IFACE]

class Characteristic(dbus.service.Object):
    """
    org.bluez.GattCharacteristic1 interface implementation
    """
    def __init__(self, bus, index, uuid, flags, service):
        self.path = service.path + '/char' + str(index)
        self.bus = bus
        self.uuid = uuid
        self.service = service
        self.flags = flags
        self.descriptors = []
        dbus.service.Object.__init__(self, bus, self.path)

    def get_properties(self):
        return {
                GATT_CHRC_IFACE: {
                        'Service': self.service.get_path(),
                        'UUID': self.uuid,
                        'Flags': self.flags,
                        'Descriptors': dbus.Array(
                                self.get_descriptor_paths(),
                                signature='o')
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_descriptor(self, descriptor):
        self.descriptors.append(descriptor)

    def get_descriptor_paths(self):
        result = []
        for desc in self.descriptors:
            result.append(desc.get_path())
        return result

    def get_descriptors(self):
        return self.descriptors

    @dbus.service.method(DBUS_PROP_IFACE,in_signature='s',out_signature='a{sv}')
    def GetAll(self, interface):
        if interface != GATT_CHRC_IFACE:
            raise InvalidArgsException()

        return self.get_properties()[GATT_CHRC_IFACE]

    @dbus.service.method(GATT_CHRC_IFACE,in_signature='a{sv}',out_signature='ay')
    def ReadValue(self, options):
        log.error('[GATT] Default ReadValue called, returning error')
        raise NotSupportedException()

    @dbus.service.method(GATT_CHRC_IFACE, in_signature='aya{sv}')
    def WriteValue(self, value, options):
        log.error('[GATT] Default WriteValue called, returning error')
        raise NotSupportedException()

    @dbus.service.method(GATT_CHRC_IFACE)
    def StartNotify(self):
        log.error('[GATT] Default StartNotify called, returning error')
        raise NotSupportedException()

    @dbus.service.method(GATT_CHRC_IFACE)
    def StopNotify(self):
        log.error('[GATT] Default StopNotify called, returning error')
        raise NotSupportedException()

    @dbus.service.signal(DBUS_PROP_IFACE,signature='sa{sv}as')
    def PropertiesChanged(self, interface, changed, invalidated):
        pass

class Descriptor(dbus.service.Object):
    """
    org.bluez.GattDescriptor1 interface implementation
    """
    def __init__(self, bus, index, uuid, flags, characteristic):
        self.path = characteristic.path + '/desc' + str(index)
        self.bus = bus
        self.uuid = uuid
        self.flags = flags
        self.chrc = characteristic
        dbus.service.Object.__init__(self, bus, self.path)

    def get_properties(self):
        return {
                GATT_DESC_IFACE: {
                        'Characteristic': self.chrc.get_path(),
                        'UUID': self.uuid,
                        'Flags': self.flags,
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    @dbus.service.method(DBUS_PROP_IFACE,in_signature='s',out_signature='a{sv}')
    def GetAll(self, interface):
        if interface != GATT_DESC_IFACE:
            raise InvalidArgsException()

        return self.get_properties()[GATT_DESC_IFACE]

    @dbus.service.method(GATT_DESC_IFACE,in_signature='a{sv}',out_signature='ay')
    def ReadValue(self, options):
        log.error('[GATT] Default ReadValue called, returning error')
        raise NotSupportedException()

    @dbus.service.method(GATT_DESC_IFACE, in_signature='aya{sv}')
    def WriteValue(self, value, options):
        log.error('[GATT] Default WriteValue called, returning error')
        raise NotSupportedException()



class DataService(Service):
    """
    A service that manages two primary characteristics:
    
    1. **Measurement Status (Boolean)**: 
       A flag indicating whether the measurement process is currently active (True) or inactive (False).
       
    2. **Data (JSON)**: 
       A JSON object that stores all relevant data, including timestamp, Beacons and measurements data.
    """

    DATA_SVC_UUID = '2B00'

    def __init__(self, bus, index):
        Service.__init__(self, bus, index, self.DATA_SVC_UUID, True)
        self.add_characteristic(StatusCharacteristic(bus, 5, self))
        self.add_characteristic(DataCharacteristic(bus, 6, self))


class StatusCharacteristic(Characteristic):
    """
    Characteristic that manages measurement status:

    **Measurement Status (Boolean)**: 
       A flag indicating whether the measurement process is currently active (True) or inactive (False).

    """
    DATA_CHRC_UUID = '2B10'

    def __init__(self, bus, index, service):
        Characteristic.__init__(
                self, bus, index,
                self.DATA_CHRC_UUID,
                ['read'],
                service)
        self.add_descriptor(StatusDescriptor(bus, 0, self))

    def ReadValue(self, options):
        global Status
        try:
            decoded_value = base64.b64decode(Status).decode("utf-8")
            decoded_value = json.loads(decoded_value)
        except Exception as e:
            log.error(f"Error during json loads of {Status} - {e} / decoded_value = {decoded_value}")
            decoded_value = 0

        log.info(f"Service Read: {repr(Status)}  -  {decoded_value}")
        return Status

class StatusDescriptor(Descriptor):
    """
    Dummy test descriptor. Returns a static value.

    """
    TEST_DESC_UUID = '2B11'

    def __init__(self, bus, index, characteristic):
        Descriptor.__init__(
                self, bus, index,
                self.TEST_DESC_UUID,
                ['read', 'write'],
                characteristic)
        self.value = "Measurement Status"
        self.value = ByteArray(self.value.encode('utf-8'))        

    def ReadValue(self, options):
        log.info(self.value)
        return self.value


class DataCharacteristic(Characteristic):
    """
    Characteristic that manages measurement data:

    **Data (JSON)**: 
       A JSON object that stores all relevant data, including timestamp, Beacons and measurements data.

    """
    DATA_CHRC_UUID = '2B20'

    def __init__(self, bus, index, service):
        Characteristic.__init__(
                self, bus, index,
                self.DATA_CHRC_UUID,
                ['read', 'notify'],
                service)
        self.add_descriptor(DataDescriptor(bus, 0, self))
        self.notifying = False
        threading.Thread(target=self.notify_loop).start()

    def ReadValue(self, options):
        global data
        try:
            decoded_value = base64.b64decode(data).decode("utf-8")
            decoded_value = json.loads(decoded_value)
        except Exception as e:
            log.warning(f"error: {e}")
            decoded_value = 0

        log.info(f"Service Read: {repr(data)}  -  {decoded_value}")
        return data

    def StartNotify(self):
        if self.notifying:
            log.info('[GATT] Already notifying, nothing to do')
            return
        log.info("Notification started")
        self.notifying = True
        self.notify_data()

    def StopNotify(self):
        if not self.notifying:
            log.info('[GATT] Not notifying, nothing to do')
            return
        log.info("Notification stopped")
        self.notifying = False

    def notify_data(self):
        global data,data_update
        
        if self.notifying:
            if data_update:
                #log.info(f"[GATT] Updating data value to {data} and notifying")
                data_update=False
                self.PropertiesChanged(
                        GATT_CHRC_IFACE,
                        {'Value': dbus.Array([dbus.Byte(c) for c in data], signature=dbus.Signature('y'))},[])
        else:
            #log.info("[GATT] inside notify function but its not notifying")
            time.sleep(1)

    def notify_loop(self):
        while True:
            self.notify_data()

class DataDescriptor(Descriptor):
    """
    Dummy test descriptor. Returns a static value.

    """
    TEST_DESC_UUID = '2B21'

    def __init__(self, bus, index, characteristic):
        Descriptor.__init__(
                self, bus, index,
                self.TEST_DESC_UUID,
                ['read', 'write'],
                characteristic)
        self.value = "Measurement Data Json"
        self.value = ByteArray(self.value.encode('utf-8'))        

    def ReadValue(self, options):
        log.info(self.value)
        return self.value



class DeviceInformationService(Service):
    """
    A service that provides device information, such as the manufacturer name and model number.
    """
    DIS_UUID = '180A'  # UUID para o Device Information Service

    def __init__(self, bus, index):
        Service.__init__(self, bus, index, self.DIS_UUID, True)
        self.add_characteristic(ManufacturerNameCharacteristic(bus, 0, self))
        self.add_characteristic(ModelNumberCharacteristic(bus, 1, self))
        self.add_characteristic(SerialNumberCharacteristic(bus, 2, self))

class ManufacturerNameCharacteristic(Characteristic):
    """
    A characteristic that returns the name of the device manufacturer.
    """

    MANUFACTURER_NAME_UUID = '2A29'  # UUID para Manufacturer Name

    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, self.MANUFACTURER_NAME_UUID,
                                ['read'], service)
        self.value = MANUFACTURER_NAME.encode("utf-8")

    def ReadValue(self, options):
        return self.value

class ModelNumberCharacteristic(Characteristic):
    """
    A characteristic that returns the model name and number.
    """

    MODEL_NUMBER_UUID = '2A24'  # UUID para Model Number

    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, self.MODEL_NUMBER_UUID,
                                ['read'], service)
        self.value = MANUFACTURER_NUMBER.encode("utf-8")

    def ReadValue(self, options):
        return self.value

class SerialNumberCharacteristic(Characteristic):
    """
    A characteristic that returns the model name and number.
    """

    MODEL_NUMBER_UUID = '2A25'  # UUID para Model Number

    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, self.MODEL_NUMBER_UUID,
                                ['read'], service)
        self.value = MANUFACTURER_SERIAL.encode("utf-8")

    def ReadValue(self, options):
        return self.value


def register_app_cb():
    """
    Callback function for successful GATT application registration.
    Prints a confirmation message once the application is registered.
    """

    log.info('[GATT] GATT application registered')

def register_app_error_cb(mainloop, error):
    """
    Callback function for GATT application registration failure.
    Prints an error message and exits the main loop.
    """

    log.info('[GATT] Failed to register application: ' + str(error))
    mainloop.quit()

def gatt_server_main(mainloop, bus, adapter_name):
    """
    Main function for setting up the GATT server and registering the application.
    Finds the GATT adapter, creates a service manager, and registers the application.
    """

    adapter = find_adapter(bus, GATT_MANAGER_IFACE, adapter_name)
    if not adapter:
        raise Exception('GattManager1 interface not found')

    service_manager = dbus.Interface(
            bus.get_object(BLUEZ_SERVICE_NAME, adapter),
            GATT_MANAGER_IFACE)
    log.info(f"service manager = {service_manager}")

    app = Application(bus)

    log.info('[GATT] Registering GATT application...')

    service_manager.RegisterApplication(app.get_path(), {},
                                    reply_handler=register_app_cb,
                                    error_handler=functools.partial(register_app_error_cb, mainloop))

