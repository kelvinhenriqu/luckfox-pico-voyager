from Voyager.Settings.Config import Config_Read, config_write
from Voyager.Firmware.Pressure.I2C_SENSOR import I2C_Sensor
from time import sleep
# from ...Settings.Config import Config_Read, config_write
import sys
import time

class CalibratePressure:
    def __init__(self):
        self.Sensor = I2C_Sensor()
        self.slope = self.Sensor.Get_Factor()
        self.intercept = self.Sensor.Get_offset()
        print(f"Slop in file: {self.slope}\nIntercept in file: {self.intercept}")

    def linear_calibration(self, xs, ys):
        """
        Least squares linear regression to calculate slope (m) and intercept (b).
        """
        n = len(xs)
        sum_x = sum(xs)
        sum_y = sum(ys)
        sum_x2 = sum(x**2 for x in xs)
        sum_xy = sum(x*y for x, y in zip(xs, ys))

        m = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x**2)
        b = (sum_y - m * sum_x) / n

        return m, b

    def flush_sensor(self, count=1000):
        """
        Reads the sensor multiple times to flush old values.
        Returns the last pressure reading only.
        """
        last_pressure = 0
        for _ in range(count):
            last_pressure, _ = self.Sensor.read()
        return last_pressure

    def run(self):
        """
        Runs the calibration process using self.Sensor.read() for raw pressure.
        """
        x = input(f"Voyager Calibration tool - Pressure Sensor\nPress 1 to test, 2 to calibrate - ")

        if (int(x) == 2):
            calibration_range = 7
            input(f"""
Calibration Procedure:

* Using a calibrated external pressure reader in tandem with the Voyager equipment, provide {calibration_range} known pressure values when prompted.

* It is important that the values are as stable as possible and fall within the sensor's full operating range.

* Example for a sensor with a range of -1 to 5 bar: -0.5, 0 , 1, 2, 3, 4, 4.5

* Note 1: The 0 value must be taken with the sensor completely unpressurized (open to atmosphere) to avoid offset or calibration errors.
* Note 2: Avoid using the extremes of the scale (e.g., -1 and 5 bar) during calibration.

**PRESS ENTER TO START**
""")
            raw_values = []
            pressures = []
            
            for i in range(calibration_range):
                input(f"\nPosition the sensor at known pressure point #{i+1} - {calibration_range}, then press ENTER...")
                raw_pressure = self.flush_sensor()
                real_pressure = float(input("Enter the real pressure (bar): "))

                raw_values.append(raw_pressure)
                pressures.append(real_pressure)
                print(f"→ Captured raw: {raw_pressure:.2f} at {real_pressure:.3f} bar")

            self.slope, self.intercept = self.linear_calibration(raw_values, pressures)

            self.Sensor.Set_factor(f"{self.slope:.8f}")
            self.Sensor.Set_offset(self.intercept)

            print(f"\n✅ Calibration completed.")
            print(f"Calibration formula: pressure = {self.slope:.8f} * raw + {self.intercept:.5f}\n")

            y = input("Entering live mode... Press ENTER to start or Press Ctrl+C to exit\n")
            time.sleep(2)
            try:
                while True:
                    raw_pressure, _ = self.Sensor.read()
                    pressure_calibrated = self.slope * raw_pressure + self.intercept
                    print(f"Raw: {raw_pressure:.2f} → Calibrated Pressure: {pressure_calibrated:.3f} bar")

            except KeyboardInterrupt:
                print("\nLive mode ended.")

        elif (int(x) == 1):
            while True:
                raw_pressure, _ = self.Sensor.read()
                pressure_calibrated = self.slope * raw_pressure + self.intercept
                print(f"Raw: {raw_pressure:.2f} → Calibrated Pressure: {pressure_calibrated:.3f} bar → round pressure: {round(pressure_calibrated,2)}")

        else:
            print(f"wrong number - {x}")
            self.run()