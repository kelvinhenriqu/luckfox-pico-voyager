# Voyager

> Voyager project private repository


## 💻 Explanation:

* src/ folder contains voyager source code


## 📫 Connections :

[![Common Errors](https://img.shields.io/badge/Common%20Errors-%23323330.svg?&style=for-the-badge&logo=Common%20Errorsff&logoColor=black&color=8000FF)](https://github.com/kelvinhenriqu/Voyager-Docs/tree/main/Docs)
[![VOYAGER SOURCE](https://img.shields.io/badge/VOYAGER%20SOURCE%20-%23323330.svg?&style=for-the-badge&logo=VOYAGER%20SOURCE%20ff&logoColor=black&color=8000FF)](https://github.com/kelvinhenriqu/Voyager/tree/main/src)
[![Como clonar o repositorio](https://img.shields.io/badge/Como%20clonar%20repositorio%20-%23323330.svg?&style=for-the-badge&logo=Como%20clonar%20repositorio%20ff&logoColor=black&color=8000FF)](https://github.com/kelvinhenriqu/Voyager?tab=readme-ov-file#-procedimento-para-conex%C3%A3o-via-ssh-com-o-github-e-clonagem-de-reposit%C3%B3rio-privado)
[![Como criar commit no Git](https://img.shields.io/badge/Como%20criar%20commit%20no%20Git%20-%23323330.svg?&style=for-the-badge&logo=Como%20criar%20commit%20no%20Git%20ff&logoColor=black&color=8000FF)](https://github.com/kelvinhenriqu/Voyager?tab=readme-ov-file#procedimento-de-cria%C3%A7%C3%A3o-e-publica%C3%A7%C3%A3o-de-nova-vers%C3%A3o-com-git--commitizen)
[![.Bashrc](https://img.shields.io/badge/.BASHRC%20-%23323330.svg?&style=for-the-badge&logo=.BASHRC%20ff&logoColor=black&color=8000FF)](https://github.com/kelvinhenriqu/Voyager-Docs/tree/main/.bashrc%20commands)

# 💻 Procedimento para conexão via SSH com o GitHub e clonagem de repositório privado

### ✉️ E-mail: kel.henrique@hotmail.com.br  
### 🗃️Repositório: git@github.com:kelvinhenriqu/Voyager.git

---

### 1. Gerar nova chave SSH

Abra o terminal e execute:

```bash
ssh-keygen -t ed25519 -C "kel.henrique@hotmail.com.br"
```

- Pressione `Enter` para aceitar o caminho padrão: `~/.ssh/id_ed25519`
- Pressione `Enter` novamente para deixar a senha em branco (ou defina uma se desejar mais segurança)


### 2. Iniciar o ssh-agent e adicionar a chave gerada

```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```


### 3. Copiar a chave pública para adicionar no GitHub

```bash
cat ~/.ssh/id_ed25519.pub
```

- Copie o conteúdo exibido, que começa com `ssh-ed25519`


### 4. Adicionar a chave SSH no GitHub

1. Acesse: https://github.com/settings/keys
2. Clique em **"New SSH key"**
3. Em **Title**, coloque por exemplo: `Linux laptop`
4. No campo **Key**, cole a chave pública copiada do passo anterior
5. Clique em **"Add SSH key"**


### 5. Testar conexão com o GitHub via SSH

```bash
ssh -T git@github.com
```

- Espera-se a seguinte mensagem:

```text
Hi kelvinhenriqu! You've successfully authenticated, but GitHub does not provide shell access.
```


### 6. Clonar o repositório privado

```bash
git clone git@github.com:kelvinhenriqu/Voyager.git
```


# Procedimento de Criação e Publicação de Nova Versão com Git + Commitizen

Este documento descreve o processo para criar uma nova versão de um projeto utilizando Git e Commitizen, incluindo como resolver conflitos com o repositório remoto.

## 🚀 Etapas para Criar e Publicar uma Nova Versão

### 0. Configurar o usuário Git (necessário apenas uma vez ou ao trocar de máquina)

```bash
git config user.name "Seu Nome"
git config user.email "seu@email.com"
```

> Essas configurações são usadas para identificar quem fez os commits. É importante que o e-mail seja o mesmo usado na sua conta do GitHub para evitar problemas de associação de commits.
> 
### 1. Atualizar a data e hora da placa (aplicável para sistemas embarcados)

Antes de fazer o commit, certifique-se de que a data e hora do sistema estão corretas. Isso evita problemas de histórico incorreto no GitHub.

```bash
sudo date -s "mm/dd/yyyy hh:mm"
```
### 2. Adicionar alterações ao Git
Você pode adicionar todas as alterações de uma vez:
```bash
git add .
```
Ou adicionar arquivos específicos:
```bash
git add nome_do_arquivo.py outro_arquivo.txt
```

### 3. Verificar o status do repositório
```bash
git status
```
> Verifique se todos os arquivos desejados estão marcados como "staged".

### 4. Criar um commit usando o Commitizen
```bash
cz commit
```
> Um assistente interativo ajudará a gerar uma mensagem de commit semântica (como `feat:`, `fix:`, `docs:` etc).

### 5. Atualizar o changelog
```bash
cz changelog
```
> Gera ou atualiza automaticamente um arquivo `CHANGELOG.md` com base nos commits semânticos realizados.

### 6. Atualizar automaticamente a versão
```bash
cz bump
```
> Atualiza o número de versão e cria uma tag com a nova versão (ex: `v2.3.1`).

### 7. Subir as mudanças para o repositório remoto
```bash
git push
git push --tags
```

---

## ⚠️ Caso o Push Seja Rejeitado

Se você receber o seguinte erro:
```
error: failed to push some refs to 'github.com:usuario/repositorio.git'
hint: Updates were rejected because the remote contains work that you do not have locally.
```

### Solução recomendada: Atualizar com rebase
```bash
git pull --rebase origin main
git push
```
> Essa opção sincroniza seu código local com o remoto sem sobrescrever nada.

### Alternativa (com cuidado): Forçar o push
```bash
git push --force origin main
```
> Use apenas se tiver certeza de que é seguro sobrescrever o histórico remoto (ex: repositório pessoal).

---

## 🃃 Checklist Rápido
- [ ] `git add .` ou `git add <arquivos>`
- [ ] `git status`
- [ ] `cz commit`
- [ ] `cz changelog`
- [ ] `cz bump`
- [ ] `git push && git push --tags`
- [ ] Caso erro: `git pull --rebase origin main`
- [ ] Se necessário: `git push --force origin main`

---
