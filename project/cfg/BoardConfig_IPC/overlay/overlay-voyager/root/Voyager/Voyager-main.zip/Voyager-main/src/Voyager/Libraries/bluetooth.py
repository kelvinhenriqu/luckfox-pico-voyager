#!/usr/bin/python3 -u
#This script is used to manage all the incoming bluetooth requests as well as remove the device after a disconnection. avoiding errors when reconnecting.
#rev 01 - 30/11/2023 - working but slower than expected.
#rev 02 - 19/01/2023 - if any bluetooth devices disconnected in less than 15 read calls (approximately 10 seconds) it'll be removed from the paired devices, possibly is error
#rev 03 - 27/05/2024 - code implemented in Voyager package

import asyncio, re
import os
from asyncio.subprocess import PIPE
from Voyager.Settings.Config import Config_Read

re_conn = re.compile('.*Device ([0-9A-Z:]+) Connected: (yes|no).*')

init_strings = [
    b'power on\r',
    b'discoverable on\r',
    b'pairable on\r', 
    b'agent NoInputNoOutput\r',
    b'default-agent\r'
]

class BT:
    def __init__(self):
        self.p = None
        self.ready = False
        self.init_step = -1
        self.init_done = False
        self.no_data_cnt = 0
        self.conn_dev = None
        self.new_dev = None
        self.MAC = None
        self.TIMER = 0
        self.Debug = Config_Read().getboolean('Bluetooth_Service','Debug')

    def debugPrint(self,msg): #print in terminal
        print(msg, flush=True) if self.Debug else None

    async def send(self, s):
        self.debugPrint(f"  >> {s}")
        self.p.stdin.write(s)
        await self.p.stdin.drain()

    async def read(self):
        try:
            self.TIMER = self.TIMER + 1
            self.debugPrint (self.TIMER)
            l = await asyncio.wait_for(self.p.stdout.readline(), 1)
        except asyncio.TimeoutError:
            pass
        else:
            if l is None:
                raise Exception('EOF')
            self.debugPrint(f"  << {l}")
            return l
        return None

    async def handle(self, l):
        if l is None:
            if self.init_step == -1:
                self.ready = True
                self.init_step = 0
            elif self.init_step < len(init_strings) and self.no_data_cnt > 2:
                self.ready = True
            else:
                return

        if l is not None and ('succeeded' in l or 'Agent registered' in l or 'Default agent request successful' in l):
            self.init_step += 1
            self.ready = True

        if self.ready and self.init_step < len(init_strings):
            await self.send(init_strings[self.init_step])
            self.ready = False
            return
        elif self.ready:
            if not self.init_done:
                self.init_done = True
                await self.send(b'disconnect\r')

        match = re_conn.match(l)
        if match:
            dev = match.group(1)
            connected = match.group(2)
            if connected == 'yes':
                if self.conn_dev is not None and dev != self.conn_dev:
                    await self.send(b'disconnect\r')
                    self.new_dev = dev
                else:
                    self.debugPrint(f"New device connected: {dev}")
                    self.TIMER = 0
                    self.conn_dev = dev
                return
            else:
                if self.conn_dev is not None and dev == self.conn_dev:
                    self.debugPrint(f"Device disconnected: {dev}")
                    self.MAC = dev
                    self.conn_dev = None
                    if (self.TIMER <= 15): #if any connection is disconnected in less than 15 calls (less than 10 seconds), delete device, it may be in error
                        self.debugPrint(f"Device {self.MAC} disconnected too fast")
                        self.debugPrint(f"Removing device: {self.MAC} to avoid errors")
                        await self.send(bytes('remove {}\r'.format(self.MAC), 'utf-8'))


        if 'Successful disconnected' in l:
            if self.new_dev is not None:
                await self.send(bytes('connect {}\r'.format(self.new_dev), 'utf-8'))
            return

        if 'Connection successful' in l:
            self.debugPrint(f"New device connected: {self.new_dev}")
            self.conn_dev = self.new_dev
            self.new_dev = None
            return

        if 'KAuthorize service' in l:
            await self.send(b'yes\r')
            return

        if 'Failed to connect: org.bluez.Error.Failed' in l:
            if self.new_dev is not None:
                await self.send(bytes('connect {}\r'.format(self.new_dev), 'utf-8'))
            return


    async def run(self):
        self.p = await asyncio.create_subprocess_shell('bluetoothctl', stdin=PIPE, stdout=PIPE)

        while True:
            try:
                l = await self.read()
            except:
                break
            else:
                if l is None:
                    self.no_data_cnt += 1
                    await self.handle(None)
                else:
                    self.no_data_cnt = 0
                    await self.handle(str(l))
                continue

        return await self.p.wait()

def Run():
    os.system('sudo systemctl start systemd-networkd')
    os.system('sudo systemctl start bt-agent')
    os.system('sudo systemctl start bt-network')
    os.system('sudo bt-adapter --set Discoverable 1')

    bt = BT()
    loop = asyncio.new_event_loop()
    #loop = asyncio.get_event_loop()
    loop.run_until_complete(bt.run())

if __name__ == '__main__':
    Run()
    