#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Library to control I2C Pressure and Temperature Sensor
#works with firmware v51+
#52 - Battery gauge 

#Decrapted - not used in any current firmware

__VERSION__ = 52

#import mraa     #i2c connection
import time
#import busio
from smbus2 import SMBus, i2c_msg
import board
import periphery as periphery

from Voyager.Settings.Config import Config_Read, config_write

class Fuel_Gauge():
    def __init__(self,LowAlert=3.5,HighAlert=4.1):
        import adafruit_max1704x

        i2c = busio.I2C(board.SCL3, board.SDA3) #PIN 14 and 15
        self.Gauge = adafruit_max1704x.MAX17048(i2c)

        self.Gauge.voltage_alert_min = LowAlert #Min Voltage for Alert
        self.Gauge.voltage_alert_max = HighAlert #Max Voltage for Alert

        # print("Quick starting")
        self.Gauge.quick_start = True
    
    def Hibernate(self):
        self.Gauge.hibernate()
        
    def Wake(self):
        self.Gauge.wake()

    def Read_Voltage(self):
        return self.Gauge.cell_voltage
    
    def Read_Percentage(self):
        if self.Gauge.hibernating:
            print("Hibernating!")
            self.Wake()
        return self.Gauge.cell_percent
    
    def Battery_Status(self):
        HighStatus = self.Gauge.voltage_high_alert
        LowStatus = self.Gauge.voltage_low_alert

        self.Gauge.voltage_high_alert = False
        self.Gauge.voltage_low_alert = False

        return HighStatus, LowStatus #Charging state,Low battery

class I2C_Sensor():

    def __init__(self):
        self.offset = Config_Read().get("General","offset",fallback=0)
        self.CalibrationFactor = Config_Read().get("General","Calibration_Factor",fallback=0) #1.042
        self.Pressure,self.Temperature = 0,0
    
        self.address = 0x78


    def Set_offset(self, Offset):
        '''Sets Intercept value and save it in config file'''
        print(f"Offset being set to = {Offset}")
        self.offset = Offset
        config_write("General","Offset",Offset)

    def Get_offset(self):
        '''Returns Intercept value'''
        if type(eval(self.offset)) == list:
            return 1
        return eval(self.offset)
    
    def Set_factor(self, Factor):
        '''Sets Slop value and save it in config file'''
        self.CalibrationFactor = Factor
        config_write("General","Calibration_Factor",Factor)
    
    def Get_Factor(self):
        '''Returns Slop value'''
        if type(eval(self.CalibrationFactor)) == list:
            return 1
        return eval(self.CalibrationFactor)

    def read(self):
        
        try:
            with SMBus(3) as bus:
                bus.write_byte(0x78, 0xAC)
                time.sleep(0.01)

                # Lê 10 bytes de resposta
                read = i2c_msg.read(0x78, 10)
                bus.i2c_rdwr(read)
                data = list(read)

            
                # i2c = busio.I2C(board.SCL3, board.SDA3)
                # command = bytearray([0xAC])
                # i2c.writeto(0x78, command)        
                # data = bytearray(10)
                # i2c.readfrom_into(0x78, data)
                # time.sleep(.01)
            
                self.Status = bin(data[0])[2:].zfill(8)  #status
                p1 = bin(data[1])[2:].zfill(8)  #BridgeDat1
                p2 = bin(data[2])[2:].zfill(8)  #BridgeDat2
                p3 = bin(data[3])[2:].zfill(8)  #BridgeDat3
                t1 = bin(data[4])[2:].zfill(8)  #TempDat1
                t2 = bin(data[5])[2:].zfill(8)  #TempDat2

                BinPress = p1+p2+p3                   #concatenate values in bytes
                self.DecPress = int(BinPress, 2)      #convert to Decimal

                BinTemp = t1+t2                #concatenate values in bytes
                DecTemp = int(BinTemp, 2)        #convert to Decimal
                IntTemp = (((DecTemp/65536)*190)-40)*0.954 #calibration factor is 0.954

                Temperature = round(IntTemp,1) #round the number to 3 number after dot
                
                self.Temperature = Temperature

                return self.DecPress, self.Temperature

        except Exception as e:
            print(f"Critical error during Pressure Sensor reading - {e}")
            dummy_press = -99
            dummy_temp = 0
            return dummy_press, dummy_temp

    
    def ReadAverage(self, times=10): #10 default

        sum = 0
        for i in range(times):
            p,t = self.read()
            sum += p

        self.Average = sum / times
        return self.Average

    def Tare(self, times=10):
        tare = self.ReadAverage(times)
        self.Set_offset(tare)

    def Start(self):
        try:
            print(self.read())
            return True,None

        except OSError:
            print("\nFATAL ERROR, is sensor connected ?\n")
            return False,1

        except KeyboardInterrupt:
            print("\ncancelled by user\n")
            return False,2



if __name__ == "__main__":
    print("Start Sensor")
    
    Sensor = I2C_Sensor() #Start Sensor with the name "Sensor"
    Sensor.Start() #Sensor Test
    
    print("Sensor Tare...\n")
    
    pp,tt = Sensor.read() #Get Pressure and Temperature in the same call
    
    print(f"Before Tare (Tare = {Sensor.offset}):")
    print(f"Pressure = {pp}, Temperature = {tt} \n") #Debug Print

    Sensor.Tare()
    
    print(f"After Tare (Tare = {Sensor.offset}):")
    print(f"Pressure = {pp}, Temperature = {tt} \n") #Debug Print
    
    while True:
        pp,tt = Sensor.read() #Get Pressure and Temperature in the same call
        print(f"Pressure = {Sensor.Pressure}, Temperature = {Sensor.Temperature}") #Debug Print
        print(f"Pressure = {pp}, Temperature = {tt}\n") #Debug Print
        time.sleep(1)

'''if __name__ == "__main__":
    Battery = Fuel_Gauge()
    Battery.Wake()

    while True:
        BatteryChargingState,LowBatteryState = Battery.Battery_Status()
        print(f"Battery percetage = {Battery.Read_Percentage():.0f}%")
        print(f"Battery Status:\nCharging:{BatteryChargingState}, Low Battery Alert:{LowBatteryState}\n")
        time.sleep(0.5)'''