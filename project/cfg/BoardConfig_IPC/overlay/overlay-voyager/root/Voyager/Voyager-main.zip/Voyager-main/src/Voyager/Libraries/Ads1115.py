import time
from smbus2 import SMBus

class Ads1115:
    # Registers
    REG_CONVERSION = 0x00
    REG_CONFIG     = 0x01

    # Mapping of AINx channels to MUX
    mux_map = {
        0: 0b100,  # AIN0 - GND
        1: 0b101,  # AIN1 - GND
        2: 0b110,  # AIN2 - GND
        3: 0b111,  # AIN3 - GND
    }

    # Available gains and their respective maximum voltages (V)
    pga_values = {
        "2/3": 6.144,
        "1":   4.096,
        "2":   2.048,
        "4":   1.024,
        "8":   0.512,
        "16":  0.256,
    }

    pga_bits = {
        "2/3": 0b000,
        "1":   0b001,
        "2":   0b010,
        "4":   0b011,
        "8":   0b100,
        "16":  0b101,
    }

    def __init__(self, bus_num=3, address=0x48, gain="1"):
        #self.bus = SMBus(bus_num)
        self.bus_num = bus_num
        self.address = address
        self.set_gain(str(gain))

    def set_gain(self, gain):
        gain = str(gain)
        if gain not in self.pga_values:
            raise ValueError(f"Ganho inválido. Valores possíveis: {list(self.pga_values.keys())}")
        self.gain = gain
        self.pga_v = self.pga_values[gain]
        self.gain_bits = self.pga_bits[gain]

    def read_channel(self, channel):
        """
        Reads the specified ADC channel.

        Parameters:
            channel (int): The channel number to read (0, 1, 2, or 3).

        Returns:
            tuple: (raw, volts) where 'raw' is the raw ADC value (int) and 'volts' is the calculated voltage (float).
        """
        if channel not in self.mux_map:
            raise ValueError("Canal inválido. Use 0, 1, 2 ou 3.")

        mux_bits = self.mux_map[channel]

        # Monta o registrador de configuração
        config = 0
        config |= (1 << 15)                # Bit OS = 1 (start single conversion)
        config |= (mux_bits & 0b111) << 12 # MUX
        config |= (self.gain_bits & 0b111) << 9  # PGA
        config |= (1 << 8)                 # Modo single-shot
        config |= (0b100 << 5)             # Data rate = 128SPS
        config |= 0b11                     # Desabilita comparador

        # Escreve configuração
        config_bytes = [(config >> 8) & 0xFF, config & 0xFF]
        with SMBus(3) as bus:
            bus.write_i2c_block_data(self.address, self.REG_CONFIG, config_bytes)

            # Espera conversão (~8ms para 128SPS)
            time.sleep(0.01)

            # Lê dados do registrador de conversão
            data = bus.read_i2c_block_data(self.address, self.REG_CONVERSION, 2)
            raw = (data[0] << 8) | data[1]
            if raw > 0x7FFF:
                raw -= 0x10000

            volts = raw * (self.pga_v / 32768.0)
            return raw, volts

if __name__ == "__main__":
    import digitalio
    import board

    gpio1 = digitalio.DigitalInOut(board.D11)
    gpio1.direction = digitalio.Direction.OUTPUT
    gpio1.value = True
    adc = Ads1115(bus_num=3, address=0x48, gain="1")
    try:
        while True:
            raw, volts = adc.read_channel(2)
            print(f"Raw = {raw}, Voltage = {volts:.3f}V")
            time.sleep(1)

    except KeyboardInterrupt:
        print("Encerrado.")
    finally:
        adc.close()
