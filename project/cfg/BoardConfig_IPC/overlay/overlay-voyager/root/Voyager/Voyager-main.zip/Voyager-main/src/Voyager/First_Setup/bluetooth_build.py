#!/usr/bin/env python3.10
'''
Script to build the background dependencies necessary to run Voyager softwares:

Start Bluetooth services and make it start every boot
'''

import apt
import sys
import os
import subprocess
import sys

from ..Log.setup_logger import SetupLogger
SL = SetupLogger("[Bluetooth Service]")
log = SL.get_logger()

def verify_root():
    'Verify if the user is root'
    username = subprocess.check_output(['whoami'])
    if not "root" in str(username):
        log.warning (f"({username}) - You aren't root")
        return False
    else:
        log.info (f"Hello, {str(username)}")
        return True

def install_back_services():
    'Create background systemctl service to run bluetooth PAN'
    os.system(
        '''sudo echo "
[NetDev]
Name=pan0
Kind=bridge" > /etc/systemd/network/pan0.netdev'''
    )

    os.system(
        '''sudo echo "
[Match]
Name=pan0

[Network]
Address=172.20.1.1/24
DHCPServer=yes " > /etc/systemd/network/pan0.network'''
    )

    os.system(
        '''sudo echo "
[Unit]
Description=Bluetooth Auth Agent

[Service]
ExecStart=/usr/bin/bt-agent -c NoInputNoOutput
Type=simple

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/bt-agent.service'''
    )

    os.system(
        '''sudo echo "
[Unit]
Description=Bluetooth NEP PAN
After=pan0.network

[Service]
ExecStart=/usr/bin/bt-network -s nap pan0
Type=simple

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/bt-network.service'''
    )

    os.system("sudo systemctl enable systemd-networkd")
    os.system("sudo systemctl enable bt-agent")
    os.system("sudo systemctl enable bt-network")

    os.system("sudo systemctl start systemd-networkd")
    os.system("sudo systemctl start bt-agent")
    os.system("sudo systemctl start bt-network")

    os.system("sudo systemctl status systemd-networkd")
    os.system("sudo systemctl status bt-agent")
    os.system("sudo systemctl status bt-network")

    path1 = "/etc/systemd/network/pan0.netdev"
    path2 = "/etc/systemd/network/pan0.network"
    path3 = "/etc/systemd/system/bt-agent.service"
    path4 = "/etc/systemd/system/bt-network.service"

    if os.path.isfile(path1) and path2 and path3 and path4:
        log.info("Background services installed successfully")
    else:
        log.error("Error while installing background services, some files are missing")

def install_pip_packages(pkg_name_list):
    """Install a list of pip packages."""

    for package_name in pkg_name_list:
        try:
            log.info(f"Trying to install {package_name}")
            subprocess.check_call(["sudo", "python3.11", "-m", "pip", "install", package_name])
            log.info(f"Successfully installed: {package_name}")
        except subprocess.CalledProcessError:
            log.warning(f"Failed to install: {package_name}")

def install_apt_packages(pkg_name):
    'Install Bluez package using apt'

    log.info(f"Trying to install {pkg_name}")
    cache = apt.cache.Cache()
    cache.update()
    cache.open()

    pkg = cache[pkg_name]
    if pkg.is_installed:
        log.info (f"{pkg_name} already installed")
    else:
        pkg.mark_install()

        try:
            cache.commit()
        except Exception as e:
            log.error (f">> {sys.stderr}, Sorry, package installation failed [{e}]")
    
    install_back_services()

def start_services():
    'Install bluetooth services and make it start every boot'

    if not verify_root():
        log.critical("script must be executed with root rights")
        sys.exit()
    else:
    
        log.info(f"Starting bluetooth services")          
        os.system("sudo service bluetooth start")

        log.info(f"keep it on forever")
        os.system("sudo update-rc.d bluetooth enable")
        
        try:
            log.info(f"Trying to enable time syncronization to syncronize date/time") 
            response = subprocess.check_call(["sudo", "timedatectl", "set-ntp", "true"]) #sudo timedatectl set-ntp true
            log.info(f"Done - {response}") 
        except Exception as e:
            log.warning(f"Warning during time syncronization enable: {e}")
            pass

        try:
            log.info(f"Trying to disable time syncronization") 
            response = subprocess.check_call(["sudo", "timedatectl", "set-ntp", "false"]) #sudo timedatectl set-ntp false
            log.info(f"Done - {response}") 
        except Exception as e:
            log.warning(f"Warning during time syncronization disable: {e}")
            pass

        try:
            log.info(f"Trying to set date/time using internet") 
            command = 'sudo date -s "$(wget --method=HEAD -qSO- --max-redirect=0 google.com 2>&1 | sed -n \'s/^ *Date: *//p\')"'
            response = subprocess.check_call(command, shell=True) #sudo timedatectl set-ntp false
            log.info(f"Done - {response}") 
        except Exception as e:
            log.warning(f"Warning during internet time syncronization: {e}")
            pass


        install_apt_packages("bluez-tools")
        install_apt_packages("python3.11-dev")
        install_apt_packages("mosquitto")

        try:
            log.info(f"Trying to remove python package protection") 
            response = subprocess.check_call(["sudo", "rm", "-r", "/usr/lib/python3.11/EXTERNALLY-MANAGED"]) #sudo rm /usr/lib/python3.11/EXTERNALLY-MANAGED
            log.info(f"Done - {response}") 
        except Exception as e:
            log.warning(f"Warning about python package removal: {e}")
            pass

            

        pip_list = [
            "Adafruit-Blinka",
            "adafruit-circuitpython-ads1x15",
            "adafruit-circuitpython-mpu6050",
            "adafruit-circuitpython-busdevice",
            "adafruit-circuitpython-connectionmanager",
            "adafruit-circuitpython-max1704x",
            "adafruit-circuitpython-register",
            "adafruit-circuitpython-requests",
            "adafruit-circuitpython-typing",
            "Adafruit-PlatformDetect",
            "Adafruit-PureIO",
            "cmake",
            "pyinstaller",
            "pyinstaller-hooks-contrib",
            "pyserial",
            "bleak",
            "Flask",
            "gpiod",
            "construct",
            "colorlog",
            "Commitizen",
            "python-periphery",
            "paho-mqtt",
            "smbus",
            "smbus2",
            "numpy",
        ]

        install_pip_packages(pip_list)

if __name__ == "__main__":
    if verify_root():
        start_services()
    else:
        log.critical("Execute script with root rights")