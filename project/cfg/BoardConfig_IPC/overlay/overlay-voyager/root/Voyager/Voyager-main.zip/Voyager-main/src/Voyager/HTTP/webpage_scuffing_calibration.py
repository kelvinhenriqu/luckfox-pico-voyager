from flask import Blueprint, render_template_string, request, redirect, url_for, session, flash, jsonify
from Voyager.Firmware.Impact.Scuffing import Scuffing
from Voyager.Settings.Config import Config_Read, config_write
import time

Sensor = Scuffing()
SENSOR_RANGE = 200

# Get current calibration values
try:
    config = Config_Read()
    current_offset = config.get("General", "Offset") or [0, 0, 0]
    current_factor = Sensor.get_factor() or [1, 1, 1]
except:
    current_offset = [0, 0, 0]
    current_factor = [1, 1, 1]

scuffing_calib_bp = Blueprint('scuffing_calib', __name__, url_prefix='/calibration/scuffing')

# Templates inline
step1_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h1>Scuffing Sensor Calibration</h1>
<p>Welcome to the scuffing sensor calibration wizard. This process calibrates the Neck, Shoulder, and Heel sensors.</p>
<p>Current offset: <b>{{ current_offset }}</b></p>
<p>Current factor: <b>{{ current_factor }}</b></p>
<div style="display: flex; gap: 10px; align-items: center;">
    <form method="POST" action="{{ url_for('scuffing_calib.start') }}">
        <button class="btn" type="submit">Start Calibration</button>
    </form>
    <form method="GET" action="{{ url_for('scuffing_calib.sensor_test') }}">
        <button class="btn" type="submit" style="background-color: #007bff;">Sensor Test</button>
    </form>
    <form method="GET" action="/">
        <button class="btn" type="submit" style="background-color: #6c757d;">Back</button>
    </form>
</div>
{% endblock %}
'''

offset_step_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h2>Step 1/2: Offset Calibration</h2>
<p><strong>IMPORTANT:</strong> Make sure the VGR Scuffing is at rest before starting the measurement.</p>
<p><strong>Don't touch the sensors during this step!</strong></p>
<p>This step will collect 100 readings from each sensor to determine the baseline offset values.</p>

<div id="status" style="margin: 20px 0;">
    <p>Status: <span id="status-text">Ready to start</span></p>
    <div style="background: #f0f0f0; padding: 20px; margin: 10px 0; font-family: monospace;">
        <div>Progress: <span id="progress">0/100</span></div>
        <div>Neck: <span id="neck-value">-</span></div>
        <div>Shoulder: <span id="shoulder-value">-</span></div>
        <div>Heel: <span id="heel-value">-</span></div>
    </div>
</div>

<button id="start-offset" class="btn" onclick="startOffsetCalibration()">Start Offset Calibration</button>
<form method="GET" action="{{ url_for('scuffing_calib.index') }}">
    <button class="btn" type="submit" style="background-color: #6c757d;">Cancel</button>
</form>

<script>
let isRunning = false;

function startOffsetCalibration() {
    if (isRunning) return;
    
    isRunning = true;
    document.getElementById('start-offset').disabled = true;
    document.getElementById('status-text').textContent = 'Collecting offset data...';
    
    fetch('{{ url_for("scuffing_calib.calculate_offset") }}', {method: 'POST'})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '{{ url_for("scuffing_calib.factor_step") }}';
            } else {
                alert('Error: ' + data.error);
                isRunning = false;
                document.getElementById('start-offset').disabled = false;
                document.getElementById('status-text').textContent = 'Error occurred';
            }
        })
        .catch(error => {
            alert('Error: ' + error);
            isRunning = false;
            document.getElementById('start-offset').disabled = false;
            document.getElementById('status-text').textContent = 'Error occurred';
        });
}

// Update progress during calibration
function updateProgress() {
    if (!isRunning) return;
    
    fetch('{{ url_for("scuffing_calib.get_calibration_progress") }}')
        .then(response => response.json())
        .then(data => {
            document.getElementById('progress').textContent = data.progress + '/100';
            document.getElementById('neck-value').textContent = data.neck || '-';
            document.getElementById('shoulder-value').textContent = data.shoulder || '-';
            document.getElementById('heel-value').textContent = data.heel || '-';
            
            if (data.progress < 100 && isRunning) {
                setTimeout(updateProgress, 500);
            }
        });
}

// Start progress updates when calibration begins
document.getElementById('start-offset').addEventListener('click', () => {
    setTimeout(updateProgress, 1000);
});
</script>
{% endblock %}
'''

factor_step_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h2>Step 2/2: Factor Calibration</h2>
<p><strong>Offset calibration completed!</strong></p>
<p>Offset values: Neck: {{ offset_values[0] }}, Shoulder: {{ offset_values[1] }}, Heel: {{ offset_values[2] }}</p>

{% if warnings %}
<div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <h4>⚠️ Warnings:</h4>
    <ul>
        {% for warning in warnings %}
        <li>{{ warning }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

<p>
    <strong>NEXT STEP:</strong> Press each sensor (neck, shoulder, and heel) one at a time, all the way to the end of its range.<br>
    <strong>Take your time!</strong> You do not need to rush. The system will record the highest value for each sensor during this step.<br>
    When you are ready, click "Start Factor Calibration" and press each sensor fully, one at a time, in any order.
</p>
<p>This step will collect 300 readings to determine the maximum sensor response.</p>

<div id="status" style="margin: 20px 0;">
    <p>Status: <span id="status-text">Ready to start factor calibration</span></p>
    <div style="background: #f0f0f0; padding: 20px; margin: 10px 0; font-family: monospace;">
        <div>Progress: <span id="progress">0/300</span></div>
        <div>Neck: <span id="neck-value">-</span></div>
        <div>Shoulder: <span id="shoulder-value">-</span></div>
        <div>Heel: <span id="heel-value">-</span></div>
    </div>
</div>

<button id="start-factor" class="btn" onclick="startFactorCalibration()">Start Factor Calibration</button>
<form method="GET" action="{{ url_for('scuffing_calib.index') }}">
    <button class="btn" type="submit" style="background-color: #6c757d;">Cancel</button>
</form>

<script>
let isRunning = false;

function startFactorCalibration() {
    if (isRunning) return;
    
    isRunning = true;
    document.getElementById('start-factor').disabled = true;
    document.getElementById('status-text').textContent = 'Collecting factor data...';
    
    fetch('{{ url_for("scuffing_calib.calculate_factor") }}', {method: 'POST'})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '{{ url_for("scuffing_calib.result") }}';
            } else {
                alert('Error: ' + data.error);
                isRunning = false;
                document.getElementById('start-factor').disabled = false;
                document.getElementById('status-text').textContent = 'Error occurred';
            }
        })
        .catch(error => {
            alert('Error: ' + error);
            isRunning = false;
            document.getElementById('start-factor').disabled = false;
            document.getElementById('status-text').textContent = 'Error occurred';
        });
}

// Update progress during calibration
function updateProgress() {
    if (!isRunning) return;
    
    fetch('{{ url_for("scuffing_calib.get_calibration_progress") }}')
        .then(response => response.json())
        .then(data => {
            document.getElementById('progress').textContent = data.progress + '/300';
            document.getElementById('neck-value').textContent = data.neck || '-';
            document.getElementById('shoulder-value').textContent = data.shoulder || '-';
            document.getElementById('heel-value').textContent = data.heel || '-';
            
            if (data.progress < 300 && isRunning) {
                setTimeout(updateProgress, 500);
            }
        });
}

// Start progress updates when calibration begins
document.getElementById('start-factor').addEventListener('click', () => {
    setTimeout(updateProgress, 1000);
});
</script>
{% endblock %}
'''

result_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h2>Calibration Complete!</h2>
<p>Scuffing sensor calibration has been completed successfully.</p>

<h3>Results:</h3>
<div style="background: #f0f0f0; padding: 20px; margin: 20px 0; font-family: monospace;">
    <h4>Offset Values:</h4>
    <ul>
        <li>Neck: {{ offset_values[0] }}</li>
        <li>Shoulder: {{ offset_values[1] }}</li>
        <li>Heel: {{ offset_values[2] }}</li>
    </ul>
    
    <h4>Calibration Factors:</h4>
    <ul>
        <li>Neck: {{ factor_values[0] }}</li>
        <li>Shoulder: {{ factor_values[1] }}</li>
        <li>Heel: {{ factor_values[2] }}</li>
    </ul>
</div>

{% if warnings %}
<div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <h4>⚠️ Warnings:</h4>
    <ul>
        {% for warning in warnings %}
        <li>{{ warning }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

<form method="POST" action="{{ url_for('scuffing_calib.save') }}">
    <button class="btn" type="submit">Save Calibration</button>
</form>
<form method="GET" action="{{ url_for('scuffing_calib.index') }}">
    <button class="btn" type="submit" style="background-color: #6c757d;">Redo Calibration</button>
</form>
{% endblock %}
'''

save_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h2>Calibration Saved!</h2>
<p>The new calibration values have been saved to the system configuration.</p>
<form method="GET" action="{{ url_for('scuffing_calib.sensor_test') }}">
    <button class="btn" type="submit" style="background-color: #007bff;">Test Sensors</button>
</form>
<a class="btn" href="/">Back to start</a>
{% endblock %}
'''

sensor_test_html = '''
{% extends "base.html.j2" %}
{% block content %}
<h1>Scuffing Sensor Test</h1>
<p>Live sensor readings from all three scuffing sensors:</p>
<div id="sensor-data" style="font-family: monospace; font-size: 18px; padding: 20px; background: #f0f0f0; margin: 20px 0;">
    <div>Neck: <span id="neck-value">Loading...</span></div>
    <div>Shoulder: <span id="shoulder-value">Loading...</span></div>
    <div>Heel: <span id="heel-value">Loading...</span></div>
    <div>Last Update: <span id="last-update">-</span></div>
</div>
<div style="margin: 20px 0;">
    <button id="start-test" class="btn" onclick="startTest()">Start Test</button>
    <button id="stop-test" class="btn" onclick="stopTest()" style="background-color: #dc3545;">Stop Test</button>
    <form method="GET" action="{{ url_for('scuffing_calib.index') }}">
        <button class="btn" type="submit" style="background-color: #6c757d;">Back to calibration</button>
    </form>
</div>

<script>
let testInterval = null;

function startTest() {
    if (testInterval) return; // Already running
    
    document.getElementById('start-test').disabled = true;
    testInterval = setInterval(fetchSensorData, 100); // Update every 100ms like the original
    fetchSensorData(); // Get first reading immediately
}

function stopTest() {
    if (testInterval) {
        clearInterval(testInterval);
        testInterval = null;
        document.getElementById('start-test').disabled = false;
    }
}

function fetchSensorData() {
    fetch('{{ url_for("scuffing_calib.get_sensor_reading") }}')
        .then(response => response.json())
        .then(data => {
            document.getElementById('neck-value').textContent = data.neck;
            document.getElementById('shoulder-value').textContent = data.shoulder;
            document.getElementById('heel-value').textContent = data.heel;
            document.getElementById('last-update').textContent = new Date().toLocaleTimeString();
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('neck-value').textContent = 'Error';
            document.getElementById('shoulder-value').textContent = 'Error';
            document.getElementById('heel-value').textContent = 'Error';
        });
}

// Auto-stop test when leaving page
window.addEventListener('beforeunload', stopTest);
</script>
{% endblock %}
'''

# Global variables for calibration progress
calibration_data = {
    'progress': 0,
    'neck_values': [],
    'shoulder_values': [],
    'heel_values': [],
    'offset_values': None,
    'factor_values': None,
    'warnings': []
}

# --- Routes ---

@scuffing_calib_bp.route("/", methods=["GET"])
def index():
    global calibration_data
    calibration_data = {
        'progress': 0,
        'neck_values': [],
        'shoulder_values': [],
        'heel_values': [],
        'offset_values': None,
        'factor_values': None,
        'warnings': []
    }
    session["calib_data"] = {}
    return render_template_string(
        step1_html,
        current_offset=current_offset,
        current_factor=current_factor
    )

@scuffing_calib_bp.route("/start", methods=["POST"])
def start():
    session["calib_data"] = {}
    return redirect(url_for('scuffing_calib.offset_step'))

@scuffing_calib_bp.route("/offset_step", methods=["GET"])
def offset_step():
    return render_template_string(offset_step_html)

@scuffing_calib_bp.route("/calculate_offset", methods=["POST"])
def calculate_offset():
    global calibration_data
    try:
        # Reset sensor to baseline
        Sensor.set_offset(0, 0, 0)
        Sensor.set_factor(1, 1, 1)
        
        # Start sensor
        status_sensor = Sensor.Start()
        if not status_sensor:
            return jsonify({"success": False, "error": "Failed to start sensor"})
        
        # Collect 100 readings
        neck_list = []
        shoulder_list = []
        heel_list = []
        
        for i in range(100):
            calibration_data['progress'] = i + 1
            m1, m2, m3 = Sensor.read()
            neck_list.append(m1)
            shoulder_list.append(m2)
            heel_list.append(m3)
            
            calibration_data['neck_values'] = neck_list
            calibration_data['shoulder_values'] = shoulder_list
            calibration_data['heel_values'] = heel_list
            
            time.sleep(0.01)  # Small delay
        
        # Calculate max values (offset)
        max_value1 = max(neck_list)
        max_value2 = max(shoulder_list)
        max_value3 = max(heel_list)
        offset_list = [max_value1, max_value2, max_value3]
        
        # Check for warnings
        warnings = []
        for i, val in enumerate(offset_list):
            sensor_names = ["Neck", "Shoulder", "Heel"]
            if val >= 60:
                warnings.append(f"{sensor_names[i]} sensor has a value higher than 60 ({val}). It is recommended to redo the calibration or verify the sensors.")
        
        calibration_data['offset_values'] = offset_list
        calibration_data['warnings'] = warnings
        session['offset_values'] = offset_list
        
        # Apply offset to sensor
        Sensor.set_offset(offset_list[0], offset_list[1], offset_list[2])
        
        return jsonify({"success": True, "offset_values": offset_list, "warnings": warnings})
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@scuffing_calib_bp.route("/factor_step", methods=["GET"])
def factor_step():
    offset_values = session.get('offset_values', [0, 0, 0])
    warnings = calibration_data.get('warnings', [])
    return render_template_string(factor_step_html, offset_values=offset_values, warnings=warnings)

@scuffing_calib_bp.route("/calculate_factor", methods=["POST"])
def calculate_factor():
    global calibration_data
    try:
        # Collect 300 readings for factor calculation
        neck_list = []
        shoulder_list = []
        heel_list = []
        
        calibration_data['progress'] = 0
        
        for i in range(300):
            calibration_data['progress'] = i + 1
            m1, m2, m3 = Sensor.read()
            neck_list.append(m1)
            shoulder_list.append(m2)
            heel_list.append(m3)
            
            calibration_data['neck_values'] = neck_list
            calibration_data['shoulder_values'] = shoulder_list
            calibration_data['heel_values'] = heel_list
            
            time.sleep(0.01)  # Small delay
        
        # Calculate max values for factor
        max_value1 = max(neck_list)
        max_value2 = max(shoulder_list)
        max_value3 = max(heel_list)
        values_factor_list = [max_value1, max_value2, max_value3]
        
        # Calculate calibration factors
        calibration_factor = []
        warnings = calibration_data.get('warnings', [])
        
        for i, val in enumerate(values_factor_list):
            sensor_names = ["Neck", "Shoulder", "Heel"]
            if val <= 50:
                warnings.append(f"{sensor_names[i]} sensor has a value less than 50 ({val}). It is recommended to redo the calibration.")
            calibration_factor.append(SENSOR_RANGE / val)
        
        calibration_data['factor_values'] = calibration_factor
        calibration_data['warnings'] = warnings
        session['factor_values'] = calibration_factor
        
        return jsonify({"success": True, "factor_values": calibration_factor, "warnings": warnings})
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@scuffing_calib_bp.route("/result", methods=["GET"])
def result():
    offset_values = session.get('offset_values', [0, 0, 0])
    factor_values = session.get('factor_values', [1, 1, 1])
    warnings = calibration_data.get('warnings', [])
    
    return render_template_string(
        result_html,
        offset_values=offset_values,
        factor_values=factor_values,
        warnings=warnings
    )

@scuffing_calib_bp.route("/save", methods=["POST"])
def save():
    try:
        offset_values = session.get('offset_values', [0, 0, 0])
        factor_values = session.get('factor_values', [1, 1, 1])
        
        # Save to config
        config_write("General", "Offset", offset_values)
        config_write("General", "Calibration_Factor", factor_values)
        
        # Apply to sensor
        Sensor.set_offset(offset_values[0], offset_values[1], offset_values[2])
        Sensor.set_factor(factor_values[0], factor_values[1], factor_values[2])
        
        return render_template_string(save_html)
        
    except Exception as e:
        flash(f"Error saving calibration: {str(e)}")
        return redirect(url_for('scuffing_calib.result'))

@scuffing_calib_bp.route("/sensor_test", methods=["GET"])
def sensor_test():
    return render_template_string(sensor_test_html)

@scuffing_calib_bp.route("/api/sensor_reading", methods=["GET"])
def get_sensor_reading():
    try:
        v1, v2, v3 = Sensor.read()
        return jsonify({
            "neck": round(v1, 3),
            "shoulder": round(v2, 3),
            "heel": round(v3, 3),
            "timestamp": time.time()
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "neck": "Error",
            "shoulder": "Error",
            "heel": "Error"
        }), 500

@scuffing_calib_bp.route("/api/calibration_progress", methods=["GET"])
def get_calibration_progress():
    global calibration_data
    try:
        neck_current = calibration_data['neck_values'][-1] if calibration_data['neck_values'] else None
        shoulder_current = calibration_data['shoulder_values'][-1] if calibration_data['shoulder_values'] else None
        heel_current = calibration_data['heel_values'][-1] if calibration_data['heel_values'] else None
        
        return jsonify({
            "progress": calibration_data['progress'],
            "neck": round(neck_current, 3) if neck_current is not None else None,
            "shoulder": round(shoulder_current, 3) if shoulder_current is not None else None,
            "heel": round(heel_current, 3) if heel_current is not None else None
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
