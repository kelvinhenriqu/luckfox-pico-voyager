from Voyager.Settings.Config import Config_Read,config_write
import subprocess, os

class SetupAutostart:
    def __init__(self, remove_existing=False):
        self.path = Config_Read().get("Update_Process","Main_Folder_Path")
        self.remove_existing_service if remove_existing else self.create_service()

    def verify_autostart(self):
        'Verify if the autostart service already exists'

        stat = subprocess.call(["systemctl", "is-active", "--quiet", "Voyager"])
        if(stat == 0):  # if 0 (active), print "Active"
            print("Service already exists")
            return True
        else:
            print("Service do not exists")
            return False
        
    def remove_existing_service(self):
        'Remove existing service file'

        print("Stopping and disabling existing service")            
        stat = subprocess.call(["sudo", "systemctl", "stop", "Voyager.service"])
        stat2 = subprocess.call(["sudo", "systemctl", "disable", "Voyager.service"])
        
        print("Removing existing service file")
        stat3 = subprocess.call(["sudo", "rm", "/lib/systemd/system/Voyager.service"])
        
        if stat == 0 and stat2 == 0 and stat3 == 0:
            print("Existing service file removed successfully")
        else:
            print("Failed to remove existing service file")
    
    def create_service_file(self):
        'Create the service file'
        systemctl_path = self.path + "/Voyager"
        print(f"New service file path is {systemctl_path}")

        cmd = os.system(f'''sudo echo " 
[Unit]
Description=Voyager_service
After=network.target
StartLimitIntervalSec=3
StartLimitBurst=10

[Service]
Type=idle
Restart=on-failure
RestartSec=3s
User=root
ExecStart=/bin/bash -c '{systemctl_path}'

[Install]
WantedBy=multi-user.target" > /lib/systemd/system/Voyager.service''')

        if cmd == 0:
            print("Systemctl service created successfully")
            feedback = os.path.isfile(systemctl_path)
            if feedback:
                print("Command successfully executed, service file created")
                self.enable_services()
            else:
                print(f"Service created but the executable file does not exist ({systemctl_path})")
            
    def create_service(self):
        'Create systemctl service to start voyager process automatically'

        if not self.verify_autostart():
            print(f"Creating systemctl service")
            self.create_service_file()


        else:
            print(f"Service already exists")

    def enable_services(self):
        'Enable and start systemctl services'

        print(f"Reloading systemctl services")
        stat1 = subprocess.call(["systemctl", "daemon-reload"])

        if stat1 == 0:
            print(f"Enabling Voyager service")
            stat2 = subprocess.call(["systemctl", "enable", "Voyager.service"])
            if stat2 == 0:
                print(f"Starting Voyager service")
                stat3 = subprocess.call(["systemctl", "start", "Voyager.service"])
                if stat3 == 0:
                    print(f"Service Status")
                    stat4 = subprocess.call(["systemctl", "status", "Voyager.service"])

if __name__ == '__main__':
    print("Starting Systemctl service creation procedure")
    Main = SetupAutostart()
    Main.create_service()