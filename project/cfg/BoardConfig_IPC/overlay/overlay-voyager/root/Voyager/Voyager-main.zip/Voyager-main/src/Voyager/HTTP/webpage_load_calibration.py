from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from Voyager.Firmware.Load.FC2311 import FC2311
from Voyager.Firmware.Load.load_calibration import CalibrateLoad
from Voyager.Settings.Config import config_write, path
import os

Sensor = FC2311()
CURRENT_SCALE = Sensor.get_scale()
CURRENT_OFFSET = Sensor.get_offset()

# Define template folder relative to this file
template_folder = os.path.join(os.path.dirname(__file__), 'templates', 'load_calibration')
load_calib_bp = Blueprint('load_calib', __name__, 
                         url_prefix='/calibration/load',
                         template_folder=template_folder)

@load_calib_bp.route("/", methods=["GET"])
def index():
    session["calib_data"] = {}
    return render_template(
        'load_index.html',
        current_scale=CURRENT_SCALE,
        current_offset=CURRENT_OFFSET
    )

@load_calib_bp.route("/start", methods=["POST"])
def start():
    session["calib_data"] = {}
    return redirect(url_for('load_calib.zero_step'))

@load_calib_bp.route("/zero_step", methods=["GET"])
def zero_step():
    zero_value = session.get("calib_data", {}).get("zero_value")
    return render_template('load_zero_step.html', zero_value=zero_value)

@load_calib_bp.route("/zero_calibration", methods=["POST"])
def zero_calibration():
    try:
        # Reset sensor to defaults for calibration
        Sensor.set_scale(1)
        Sensor.set_offset(0)
        
        # Take average of 50 readings for zero point
        calibrator = CalibrateLoad()
        zero_value = calibrator.average_value(50)
        
        # Store in session
        calib_data = session.get("calib_data", {})
        calib_data["zero_value"] = zero_value
        session["calib_data"] = calib_data
        
        # Set the offset temporarily
        Sensor.set_offset(zero_value)
        
        return redirect(url_for('load_calib.zero_step'))
    except Exception as e:
        flash(f"Error during zero calibration: {str(e)}")
        return redirect(url_for('load_calib.index'))

@load_calib_bp.route("/weight_step", methods=["GET"])
def weight_step():
    zero_value = session.get("calib_data", {}).get("zero_value")
    if not zero_value:
        flash("Zero calibration required first")
        return redirect(url_for('load_calib.zero_step'))
    return render_template('load_weight_step.html', zero_value=zero_value)

@load_calib_bp.route("/weight_calibration", methods=["POST"])
def weight_calibration():
    try:
        known_weight = float(request.form["known_weight"])
        calib_data = session.get("calib_data", {})
        
        if "zero_value" not in calib_data:
            flash("Zero calibration required first")
            return redirect(url_for('load_calib.zero_step'))
        
        # Take average reading with known weight
        calibrator = CalibrateLoad()
        weight_reading = calibrator.average_value(50)
        
        # Calculate scale factor
        zero_value = calib_data["zero_value"]
        scale_factor = known_weight / weight_reading
        
        # Store calibration results
        calib_data.update({
            "weight_value": weight_reading,
            "known_weight": known_weight,
            "scale_factor": scale_factor,
            "offset": zero_value
        })
        session["calib_data"] = calib_data
        
        return redirect(url_for('load_calib.result'))
    except Exception as e:
        flash(f"Error during weight calibration: {str(e)}")
        return redirect(url_for('load_calib.weight_step'))

@load_calib_bp.route("/result", methods=["GET"])
def result():
    calib_data = session.get("calib_data", {})
    if not all(key in calib_data for key in ["zero_value", "weight_value", "known_weight", "scale_factor"]):
        flash("Incomplete calibration data")
        return redirect(url_for('load_calib.index'))
    
    return render_template(
        'load_result.html',
        zero_value=f"{calib_data['zero_value']:.4f}",
        weight_value=f"{calib_data['weight_value']:.4f}",
        known_weight=calib_data['known_weight'],
        scale_factor=f"{calib_data['scale_factor']:.8f}",
        offset=f"{calib_data['offset']:.4f}"
    )

@load_calib_bp.route("/save", methods=["POST"])
def save():
    try:
        scale_factor = float(request.form["scale_factor"])
        offset = float(request.form["offset"])
        
        # Save to sensor
        Sensor.set_scale(scale_factor)
        Sensor.set_offset(offset)
        
        # Save to configuration file
        config_write("General", "Calibration_Factor", scale_factor)
        config_write("General", "Offset", offset)
        
        return render_template('load_save.html')
    except Exception as e:
        flash(f"Error saving calibration: {str(e)}")
        return redirect(url_for('load_calib.result'))

@load_calib_bp.route("/sensor_test", methods=["GET"])
def sensor_test():
    return render_template('load_sensor_test.html')

@load_calib_bp.route("/api/sensor_reading", methods=["GET"])
def get_sensor_reading():
    try:
        raw_value = Sensor.read()
        weight_value = Sensor.get_grams()
        battery_level = Sensor.Battery()
        
        return jsonify({
            "raw_value": raw_value,
            "weight_value": round(weight_value, 3),
            "battery_level": battery_level if battery_level is not None else "N/A",
            "timestamp": request.environ.get('REQUEST_TIME', 'unknown')
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "raw_value": "Error",
            "weight_value": "Error",
            "battery_level": "Error"
        }), 500

@load_calib_bp.route("/api/tare", methods=["POST"])
def tare_sensor():
    try:
        Sensor.Tare()
        return jsonify({"success": True, "message": "Sensor tared successfully"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
