#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#______Firmware for VGR_INPACK______

import time
from datetime import datetime
import sys
import os       #OS Commands
import csv      #csv file manipulation
import json     #Json file create
import shutil   #SdCard Management
import gzip     #compress file
from threading import Thread

#Specific Voyager libraries
from Voyager.Settings.Config import Config_Read
from Voyager.Libraries.Battery import Fuel_Gauge 
from Voyager.Libraries.Beacon import BeaconDetector
from Voyager.Bluetooth.Bluetooth_Server import Bluetooth_Server
from Voyager.Libraries.LedControl import RGBLed
from Voyager.Version import __version__

#Specific Sensor library 
import asyncio
from Voyager.Firmware.Inpack.ReadSensors import DualReader

Sensor = DualReader()


#General Libraries
Battery = Fuel_Gauge() #Start Fuel Gauge sensor
Battery.Wake()

BeaconDetect = BeaconDetector()

BServer = Bluetooth_Server()
BServer.Config() #Config Bluetooth socket connection server

StatusLed = RGBLed()
StatusLed.blink(StatusLed.blue)

#Get configurations in config file
Debug = Config_Read().getboolean('General','Debug')
path = Config_Read().get('Directories','Measurements_Path')
UpdatePath = Config_Read().get('Directories','Update_Path')
BoardType = Config_Read().get('General','FullName')
BoardID = Config_Read().get('General','Board_Serial')
Use_Beacons = Config_Read().getboolean('Beacon','Use_Beacons')
TimeToReset = Config_Read().getint('Bluetooth_Service','time_to_erase') #seconds to reset Measurements Array

#Logging setup
from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[Firmware]",clear=True, state=Debug)
log = SL.get_logger()

#Others variables
Running = False;Config = False;Timer = 0
Measurements1, Measurements2 = [],[]
Beacons = []
filename = "dummy"
start_time = 0


def SD_Management(): #Free space in internal memory
    total, used, free = shutil.disk_usage("/")

    T = total // (2**30)
    U = used // (2**30)
    F = free // (2**30)
    
    return T,U,F

def Subtract_date(): #Get measure length
    global start_time
    now_time = datetime.now().strftime('%H:%M:%S') #hour-minute-seconds
    h1, m1, s1 = start_time.split(':')
    d1 = int(h1) * 3600 + int(m1) * 60 + int(s1)

    h2, m2, s2 = now_time.split(':')
    d2 = int(h2) * 3600 + int(m2) * 60 + int(s2)

    return d2-d1

def Json_encode(x=1, **kwargs):  # Json generate
    global BoardID, BoardType
    V1NAME, V1ID, V1UNIT = "Pressure", "V1", "Bar"
    V2NAME, V2ID, V2UNIT = "Temperature", "V2", "°C"
    total, used, free = SD_Management()
    
    base_response = {
        1: {"STATUS_PLAY": kwargs.get('RN', 0), "Device_Name": BoardType, "Device_Serial": BoardID, 
            "TOTAL_SPACE": total, "VERSION": str(__version__), "USED_SPACE": used, "AVAILABLE_SPACE": free,
            "Measurements":[
                {"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT},
                {"NAME": V2NAME, "ID": V2ID, "UNIT": V2UNIT}]},
        
        2: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), 
            "CSV_DATE": kwargs.get('csvdate'), "TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        3: {"TOTAL_SPACE": total, "USED_SPACE": used, "AVAILABLE_SPACE": free},
        
        4: {"V1": kwargs.get('V1'), "V2": kwargs.get('V2')},
        
        5: {"CSV_NAME": kwargs.get('csvname'), "CSV_LENGTH": kwargs.get('csvlen'), "CSV_DATE": kwargs.get('csvdate')},
        
        6: {"DELETE_STATUS": kwargs.get('RESULT', "NOK")},
        
        7: {"STATUS": kwargs.get('RESULT', "NOK")},
        
        8: {"BATTERY_PORCENTAGE": kwargs.get('PORCENTAGE')},
        
        9: {"VALOR_1": kwargs.get('Valor1')},
        
        10: {"Measurements": [{"NAME": V1NAME, "ID": V1ID, "UNIT": V1UNIT}, {"NAME": kwargs.get('V2NAME'), "ID": kwargs.get('V2ID'), "UNIT": kwargs.get('V2UNIT')}]},
        
        11: {},  # Special treatment
        
        12: {"V1": kwargs.get('V1ARRAY'), "V2": kwargs.get('V2ARRAY'), "BEACONS": kwargs.get('BEACONSARRAY')},
        
        13: {"UPDATE_STATUS": kwargs.get('RESULT', "NOK")},
        
        14: {kwargs.get('MESSAGE', "message"): kwargs.get('RESULT', "NOK")},
    }
    
    if x == 11: #its not a json, just a dictionary
        stamp = kwargs.get('V1STAMP')
        value = kwargs.get('V1VALUE')
        data = {"stamp": stamp, "value": value}
    else:
        data = json.dumps(base_response.get(x, {}))
    
    return data

def File_Compress(file): #create a compressed file and save it
    
    global path
    CSV_Directory = str(path) + str(file) + ".csv"
    log.debug(CSV_Directory)
    GZ_Directory = CSV_Directory + ".gz"
    log.debug(GZ_Directory)

    f_in = open(CSV_Directory)
    f_out = gzip.open(GZ_Directory, 'wt')
    f_out.writelines(f_in)
    f_out.close()
    f_in.close()

def Gen_Final_Json(file): #Send .csv file content over bluetooth
    global path

    File_Compress(file)

    todays_time = datetime.now().strftime('%d%m%y') #day-month-year
    Length = Subtract_date()

    BluetoothData = Json_encode(x=2,csvname=file,csvdate=todays_time,csvlen=Length)
    log.debug(BluetoothData)

    BServer.client_sock.sendall(BluetoothData.encode())

def SaveSD(Value,Value2,Beacon,IsFirst): #Save in SdCard
    '''Gets data from the sensor and save it in a csv file

    IsFirst = 1 means that is the first time the function is called, so it will create the file and write the header'''

    log.warning(f"Saving data in SD card")
    global filename,start_time,path,BoardID #Product Serial Number  

    if IsFirst == 1: #is first call ?
        timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        CsvTimeStamp = datetime.now().strftime('%d%m%y%H%M%S')
        start_time = datetime.now().strftime('%H:%M:%S') #hour-minute-seconds
        filename = BoardID + CsvTimeStamp #Create the filename, example: 21002020621134600 that means 21002.02/06/21.13:46:00
        Value = "Pressure"
        Value2 = "Temperature"
        Beacon = "Beacons"
        log.info(f"CSV File name: {filename}")
    else:
        TimeNow = datetime.now().strftime('%I%M%S')
        Mili = datetime.now().strftime('%f')
        timestamp = str(TimeNow) + str((round((int(Mili)/10000),0))).replace(".0","")
    
    Directory = str(path) + str(filename) + ".csv"
    try:
        with open(Directory, mode='a') as sensor_readings:
            sensor_write = csv.writer(sensor_readings, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            write_to_log = sensor_write.writerow([timestamp,Beacon,Value,Value2]) #write Load Cell Value and Timestamp in sdcard
            return(write_to_log)
        
    except FileNotFoundError as e:
        print(f"measurements folder does not exist, trying to create it")
        os.makedirs(str(path), exist_ok=True)
        with open(Directory, mode='a') as sensor_readings:
            sensor_write = csv.writer(sensor_readings, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            write_to_log = sensor_write.writerow([timestamp,Beacon,Value,Value2]) #write Load Cell Value and Timestamp in sdcard
            return(write_to_log)

def ArrayClear():
    global Measurements1, Measurements2
    global TimeToReset
    global Beacons
    while True:
        #log.warning(f"Resseting array")
        time.sleep(TimeToReset)
        Measurements1, Measurements2 = [], []
        Beacons = []

class Treatment:

    def __init__(self):
        self.slope = Config_Read().getfloat('General','calibration_factor',fallback=1.0)
        self.intercept = Config_Read().getfloat('General','offset',fallback=0)

    def Startup(self):
        global Config
        if Config: #if config process is necessary  
            Config = False       
            try:            
                SensorStatus = [True]#Sensor.Start()
                if SensorStatus[0]: #Pressure Sensor Test    
                    #Sensor.Tare() #Set Pressure Sensor offset and make it 0
                    SaveSD(0,0,0,1) #Save the fist line of the file  
                    BluetoothData = Json_encode(x=7, RESULT="0") #STATUS 0 - OK
                    log.debug(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    Thread(target=ArrayClear).start() #Clean Measurements Array
                    if Use_Beacons and BeaconDetect.read != {}: #Only starts the beacon thread if beacons are enabled and at least one beacon were assigned
                        Thread(target=BeaconThread).start() #Start the process to keep reading for beacons data

            except ValueError as e:
                log.error(f"error: {e}")
                BluetoothData = Json_encode(x=7, RESULT="2") #STATUS 2 - SENSOR ERROR
                log.debug(BluetoothData)
                BServer.client_sock.send(BluetoothData.encode())

    def SensorRead(self):
        values_dict = asyncio.run(Sensor.main())
        
        self.ValueTreated = self.slope * values_dict["pressure"] + self.intercept #linear regretion calculation
        self.ValueTreated = round(self.ValueTreated,2)
        self.ValueTreated = -10 if self.ValueTreated < -1 else self.ValueTreated
        self.ValueTemperature = values_dict["ntc"]
        
        return self.ValueTreated,self.ValueTemperature
    
    def BeaconRead(self):
        self.BeaconNearby = [] #Clear the list of detected beacons
        BeaconsStatus = BeaconDetect.read() #Read all detected beacons and parse them according to the list provived before

        for key in BeaconsStatus: #Get the detected beacons from the dict and parse it in a array to send to IOS
            SubList = BeaconsStatus[key]
            if SubList[0] == True:
                self.BeaconNearby.append(key)
                log.info(f"{key} Inside field, sending data ({self.BeaconNearby})")
            else:
                log.info(f"{key} Outside field, ignoring")

        self.BeaconTreated = self.BeaconNearby if self.BeaconNearby != [] else ""
        return self.BeaconNearby, self.BeaconTreated

def running():
    global Measurements1, Measurements2, Beacons
    
    #-------------------------------- Get time and date -------------------------------
    timenow = datetime.now().strftime('%I:%M:%S.')
    mili = datetime.now().strftime('%f')
    timestamp = str(timenow) + str((round((int(mili)/1000),0))).replace(".0",'')
    
    try:
        #-------------------------------- Read sensor data --------------------------------
        Treated = Treatment()
        Treated.Startup()
        
        BeaconNearby,BeaconTreated = Treated.BeaconRead()

        ValueTreated, ValueTemperature = Treated.SensorRead()
        #print(f"Pressão: {ValueTreated} | Temperatura {ValueTemperature}")
        
        #---------------------------- Parse data in json format ---------------------------
        MeasureArrayP = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=ValueTreated)
        MeasureArrayT = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=ValueTemperature)
        BeaconsArray = Json_encode(x=11,V1STAMP=timestamp,V1VALUE=BeaconNearby)

        Measurements1.append(MeasureArrayP)
        Measurements2.append(MeasureArrayT)
        Beacons.append(BeaconsArray)

        SaveSD(ValueTreated, ValueTemperature, BeaconTreated,0) #Save Pressure in filename
    except OSError as e:
        log.error(f"{e} - Sensor not ready")
        pass

def VerifyUpdateStatus():
    log_file = Config_Read().get('Update_Process','Log_File_Path')
    suc_bit = Config_Read().get('Update_Process','Success_Update_Message')
    bad_bit = Config_Read().get('Update_Process','Bad_Update_Message')
    try:
        with open(log_file,'r',encoding='utf-8') as file:
            #data = file.readlines()
            data = file.read()
            print(data)
            if suc_bit or bad_bit in data:
                if suc_bit in data:
                    return "DONE"  
                elif bad_bit in data:
                    return "ERROR"
                else:
                    return "DOING"
            else:
                print("File Corrupted")
                return "ERROR"
    except FileNotFoundError:
        print("File not found")
        return "ERROR" 

def BeaconThread(): #Start Beacon Process in the Beacon Library
    BeaconDetect.run()
    log.warning("Stopped Beacon Thread")

def handle_bluetooth_data(Bdata):
    global Debug,Running,Config,Timer,Measurements1,Measurements2, Beacons,filename,UpdatePath
    
    if len(Bdata) != 0:
        log.info(f"\n[+] Received command: {Bdata}")
        Timer = 0
        match Bdata:
        
            case "PLAY\n" | "PLAY":   #Start Measure, outdated command
                pass

            case "STOP\n" | "STOP": #Stop Measure
                if Running:
                    print(f"battery percentage: {Battery.Read_Percentage()}")
                    if Battery.Read_Percentage() > 20:
                        StatusLed.blink(StatusLed.green,interval=2)
                    else:
                        StatusLed.blink(StatusLed.green,StatusLed.red,interval=2)
                    log.info("[*] Stopping measurement")
                    Running = False
                    Config = False
                    BeaconDetect.stop() #Stop beacon reading Thread
                    Gen_Final_Json(filename)

            case "MEASUREMENTS\n" | "MEASUREMENTS":   #Start Measure
                if Running:
                    data = Json_encode(x=12, V1ARRAY=Measurements1, V2ARRAY=Measurements2, BEACONSARRAY=Beacons) 
                    BluetoothData = str(data)
                    BServer.client_sock.send(BluetoothData.encode())
                    log.info("[*] Sending Json for live chart generation")
                    log.debug(BluetoothData)
                    Measurements1, Measurements2 = [],[]
                    Beacons=[]
                    
                else:
                    m = []
                    data = Json_encode(x=12,V1ARRAY=m,BEACONSARRAY=m)
                    BluetoothData = str(data)
                    try: BServer.client_sock.send(BluetoothData.encode()) 
                    except: pass
                    log.info("[x] There is no data been recorded, nothing to send")

            case "exit\n" | "exit": #Force Stop program
                log.critical("[x] Brute stop command received")
                sys.exit()

            case "FREESPACE" | "FREESPACE\n": #send available space in SdCard
                BluetoothData = Json_encode(x=3)
                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode())

            case "CONNECT" | "CONNECT\n": #CONNECT return
                print(f"battery percentage: {Battery.Read_Percentage()}")
                if Battery.Read_Percentage() > 20:
                    StatusLed.blink(StatusLed.green,interval=2)
                else:
                    StatusLed.blink(StatusLed.green,StatusLed.red,interval=2)

                if Running:
                    BluetoothData = Json_encode(RN=1)                    
                else:
                    BluetoothData = Json_encode(RN=0)


                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode()) 

            case "BATTERY" | "BATTERY\n": #request battery percentage
                BatteryPorcentage = round(Battery.Read_Percentage()) if Battery.Read_Percentage() <= 100 else 100
                BluetoothData = Json_encode(x=8,PORCENTAGE=BatteryPorcentage)
                BServer.client_sock.send(BluetoothData.encode())
                log.debug(BluetoothData.encode())

            case _:              #If Receive Unknown Data
                pass

        DIV = Bdata.split(".", 2)

        match DIV[0]:
            
            case "PLAY":
                    x = DIV[1].rstrip("\n")
                    log.info(f"Starting Data collection - adjusting date to {x}")
                    try:
                        if not Running:
                            os.system("timedatectl set-ntp false")
                            date = "sudo timedatectl set-time '" + x + "'"
                            if os.system(date) == 0:
                                Config = True
                                Running = True
                                StatusLed.blink(StatusLed.green,interval=0.25)
                            else:
                                log.error("Error occurred while adjusting date")
                                BluetoothData = Json_encode(x=7, RESULT="1") #STATUS 1 - DATE ERROR
                                BServer.client_sock.send(BluetoothData.encode())
                                log.debug(BluetoothData)

                        else:
                            raise Exception("[x] Impossible to adjust date during data collection")
                        
                    except Exception as error:
                        BluetoothData = Json_encode(x=7, RESULT="1")
                        BServer.client_sock.send(BluetoothData.encode())
                        log.error(f"Unknown error occurred: {error}")
                        pass
                    
            case "DELETE":
                Action = DIV[1].rstrip("\n")
                
                if (Action == "UPDATE"): #if received DELETE.UPDATE the system will delete the update directory and create a new one.
                    if not os.path.exists(UpdatePath):
                        log.info("No update directory found, creating folder")
                        os.makedirs(UpdatePath)
                        os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                    else:
                        log.info("Deleting update directory")
                        shutil.rmtree(UpdatePath)
                        time.sleep(1)
                        log.info("No update directory, creating folder")
                        os.makedirs(UpdatePath)
                        os.system("sudo chmod 777 /home/rock/programa/update/")
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                        BServer.client_sock.send(BluetoothData.encode())
                        
                else:
                    log.info(f"DELETE command received, deleting {Action}.csv")
                    file = str(path) + str(Action) + ".csv"
                    if os.path.isfile(file):
                        os.remove(file) 
                        BluetoothData = Json_encode(x=6, RESULT="OK")
                    else:    ## Show an error ##
                        log.error(f"Error: {filename} not found")
                        BluetoothData = Json_encode(x=6, RESULT="NOK")
                    log.debug(BluetoothData)
                    BServer.client_sock.send(BluetoothData.encode())
                    
            case "UPDATE":
                Action = DIV[1].rstrip("\n")
                log.info(f"UPDATE command received with Action: {Action}")
                
                match Action:                            
                    
                    case "START":
                        log.info("UPDATE.START - Starting update process . . .")
                        BluetoothData = Json_encode(x=13,RESULT="DOING") #STATUS STARTING - Starting update process
                        BServer.client_sock.send(BluetoothData.encode())
                        #from ...Update.Update import Update_firmware
                        from Voyager.Update.Update import Update_firmware
                        Update_firmware()
                        sys.exit()
                
                    case "STATUS":
                        STATUS = VerifyUpdateStatus()
                        log.info(f"UPDATE.STATUS - Update status = {STATUS}")
                        BluetoothData = Json_encode(x=13,RESULT=STATUS) #STATUS DOING - Error in update process
                        BServer.client_sock.send(BluetoothData.encode())
                            
                    case _:
                        log.error("Missing arguments")
                    
            case "BEACON":
                DIV = Bdata.split(".", 3)
                Action = DIV[1]
                log.info(f"BEACON command received with Action: {Action}")
                
                match Action:  

                    case "APPEND":
                        CommandLength = 4 #expected command need to have 4 arguments
                        try:
                            BeaconName = str(DIV[2])
                            Threshold = str(DIV[3].rstrip("\n"))

                            log.info(f"BEACON.APPEND command received - Adding {BeaconName}")

                            if BeaconDetect.append(BeaconName,Threshold):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="OK")
                                log.debug(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")
                            
                        except IndexError:
                            log.error(f"Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                        except Exception as e:
                            log.error(f"Failed to execute Append command")
                            log.debug(f"error description: {e}")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_APPEND", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())


                    case "DELETE":
                        CommandLength = 3 #expected command need to have 3 arguments
                        try:
                            BeaconName = str(DIV[2].rstrip("\n"))
                            log.info(f"BEACON.DELETE command - removing {BeaconName}")

                            if BeaconDetect.delete(BeaconName):
                                BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="OK")
                                log.debug(BluetoothData)
                                BServer.client_sock.send(BluetoothData.encode())
                            else: raise Exception("Command error")

                        except IndexError:
                            log.error(f"Expected {CommandLength} arguments but {len(DIV)} were given")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                            
                        except Exception as e:
                            log.error(f"Failed to execute Append command")
                            log.debug(f"error description: {e}")
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_DELETE", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "CLEAR" | "CLEAR\n":
                        log.info(f"BEACON.CLEAR command - cleaning beacon list")

                        if BeaconDetect.clear():
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="OK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())
                        else:
                            BluetoothData = Json_encode(x=14,MESSAGE="BEACON_CLEAR", RESULT="NOK")
                            log.debug(BluetoothData)
                            BServer.client_sock.send(BluetoothData.encode())

                    case "LIST\n" | "LIST":
                        log.info(f"BEACON.LIST command - current list {Action}")
                        BluetoothData = str(BeaconDetect.BeaconDict)
                        log.debug(BluetoothData)
                        BServer.client_sock.send(BluetoothData.encode())

    else:
        try:
            log.warning( "[*] No command in the buffer... Waiting command" ) 
            BServer.Startup()              
            Timer = 0
        except Exception as e: 
            log.warning(f"[*] Unknown error - {e}")

            if Running:                        
                try:
                    running()
                except: pass                        
            else:
                time.sleep(1)
                Timer += 1
                os.system("sudo poweroff") if Timer == 1900 else log.debug(f"[*] Waiting for any bluetooth connection ({Timer} - 1900)")
            pass     

def Run():  
    global Timer,Running

    while not BServer.Startup(): #wait for first bluetooth connection
        pass

    while True: #Main loop
        try:                              
            Bdata = BServer.client_sock.recv(1024).decode('utf-8') #Converts Binary data to Decimal with maximum size of 1mb and store in a buffer          
            handle_bluetooth_data(Bdata)
 
        except KeyboardInterrupt:
            log.critical("\nProgram interrupted by user\n")
            exit()

        except (BServer.socket.timeout,ConnectionResetError):
            '''if any connection remains open for more than 5 minutes, the program will close it and restart'''

            if not Running: #if there is no data received and the program is not running, wait for a connection
                time.sleep(1)                

                if Timer == 300: #reset Voyager services if any connection remains open for more than 5 minutes
                    log.critical("[x] disconnecting bluetooth because nothing happened for a long time")
                    BServer.client_sock.close()
                    BServer.server_sock.close()
                    os.system("sudo systemctl restart Voyager.service")
                    sys.exit()
                else:
                    log.debug(f"Connection still open, board will reset soon ({Timer} - 300)")
                    Timer += 1

        finally:
            '''if the program is running, it will keep reading the data from the sensor and saving it in a csv file'''
            if Running:
                BServer.start_countdown = False
                running()
            else:
                BServer.start_countdown = True