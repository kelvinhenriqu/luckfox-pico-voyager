Status_html = '''
{% extends "base.html.j2" %}

{% block content %}
<h1>🚦 Voyager Services Status</h1>

<table style="width:100%; border-collapse: collapse;">
    <tr>
        <th style="text-align: left; padding: 8px;">Service</th>
        <th style="text-align: left; padding: 8px;">Status</th>
    </tr>
    <tr>
        <td style="padding: 8px;"><strong>Voyager Service</strong></td>
        <td style="padding: 8px;">
            <span style="color: {{ 'green' if pressure == 'TRUE' else 'red' }};">
                {{ pressure | upper }}
            </span>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px;"><strong>Bluetooth Service</strong></td>
        <td style="padding: 8px;">
            <span style="color: {{ 'green' if bluetooth == 'TRUE' else 'red' }};">
                {{ bluetooth | upper }}
            </span>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px;"><strong>HTTP Service</strong></td>
        <td style="padding: 8px;">
            <span style="color: {{ 'green' if http == 'TRUE' else 'red' }};">
                {{ http | upper }}
            </span>
        </td>
    </tr>
</table>

<br>
<hr>
<form method="GET" action="/">
        <button class="btn" type="submit" style="background-color: #007bff;">Back</button>
    </form>
{% endblock %}

'''