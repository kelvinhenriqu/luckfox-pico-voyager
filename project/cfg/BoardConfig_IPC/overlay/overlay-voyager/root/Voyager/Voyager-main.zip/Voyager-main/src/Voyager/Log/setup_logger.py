'''
Voyager logging config file:

import the library in any script you want to use:

from Voyager.Log.setup_logger import SetupLogger
SL = SetupLogger("[prefix_here]")
log = SL.get_logger()

types of logs:
log.debug("Informação útil para debug.")
log.info( "Mensagem informativa.")
log.warning( "Algo pode estar errado.")
log.error( "Algo deu errado.")
log.critical( "Erro crítico!")

'''

import logging
import colorlog

class SetupLogger:
    """Configura o logger com cores no terminal e sobrescrita no arquivo de log."""

    def __init__(self, prefix="", clear=False, state=True):   
        self.prefix = prefix
        self.logger = logging.getLogger(f"Voyager_Log_{self.prefix}")
        self.filename = "Voyager.log"
        self._handlers_set = False  # Flag para verificar se os handlers já foram configurados
        self.state = state

        if clear: self.clear()
        self.setup()
    
    def setup(self):      
        # Verify if the log already exists
        if self._handlers_set:
            return self.logger
            #logger.handlers.clear
              
        # Creating the log instance
        #logger = logging.getLogger("Voyager_Log")
        self.logger.setLevel(logging.DEBUG)

        # Color Handler
        console_handler = logging.StreamHandler()
        console_formatter = colorlog.ColoredFormatter(
            f"[%(log_color)s%(asctime)s][%(levelname)s]{self.prefix} %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            log_colors={
                'DEBUG': 'cyan',
                'INFO': 'green',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'bold_red'
            }
        )
        console_handler.setFormatter(console_formatter)

        # file Handler
        file_handler = logging.FileHandler(self.filename, mode="a")
        file_formatter = logging.Formatter(f"[%(asctime)s][%(levelname)s]{self.prefix} %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        file_handler.setFormatter(file_formatter)

        # append handlers into log
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

        self._handlers_set = True

        if self.state == False : #Turn off logs
            self.logger.setLevel(logging.CRITICAL + 1)

        return self.logger
    
    def clear(self):
        '''Clear Handlers'''
        if self.logger.hasHandlers():
            self.logger.handlers.clear()            
        open(self.filename, "w") 

    def get_logger(self,clear=False):
        """Retorna o logger configurado"""
        return self.logger

    def update_prefix(self, prefix):
        """Atualiza o prefixo dinamicamente."""
        self.prefix = prefix
        # Atualiza o formato do logger com o novo prefixo
        for handler in self.logger.handlers:
            if isinstance(handler, logging.StreamHandler):
                handler.setFormatter(colorlog.ColoredFormatter(
                    f"[%(log_color)s%(asctime)s][%(levelname)s]{self.prefix} %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S",
                    log_colors={
                        'DEBUG': 'cyan',
                        'INFO': 'green',
                        'WARNING': 'yellow',
                        'ERROR': 'red',
                        'CRITICAL': 'bold_red'
                    }
                ))
            elif isinstance(handler, logging.FileHandler):
                handler.setFormatter(logging.Formatter(f"[%(asctime)s][%(levelname)s]{self.prefix} %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
