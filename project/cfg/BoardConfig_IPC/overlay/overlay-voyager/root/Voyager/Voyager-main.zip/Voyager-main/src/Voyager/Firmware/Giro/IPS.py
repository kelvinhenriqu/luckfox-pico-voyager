import smbus # type: ignore
import time
import math
import numpy as np
import sys

# Inicializa o barramento I2C
bus = smbus.SMBus(3)
MPU6050_ADDR = 0x69

# Configurações do MPU6050
bus.write_byte_data(MPU6050_ADDR, 0x6B, 0x00)  # Desativar sleep mode

# Fator de escala do acelerômetro (MPU6050 configurado para ±2g)
ACCEL_SCALE = 16384.0  # 1g = 16384 LSB

# Parâmetros de detecção de impacto
IMPACT_THRESHOLD_G = 0.25  # Impacto detectado acima de 2.5g
ALPHA = 0.1  # Constante do filtro passa-alta
IPS_CONVERSION = 386.088  # 1g = 386.088 inches/s²
DAMPING_FACTOR = 0.95 # Perde X% da velocidade a cada iteração - simula a dissipação de energia em sistemas dinâmicos, impede crescimento indefinidamente 
HISTERESE_MINIMA = 0.002 # valores entre -0.002 e 0.002 serão considerados 0 - filtro de faixa morta (Deadband Filter)
INTEGRATION_TIME = 0 # tempo de integração do IPS

class IPS:

    def __init__(self):
        self.accel_data = []
        self.IPS_data = []
        self.timestamps = []
        self.accel_last_x, self.accel_last_y, self.accel_last_z = 0, 0, 0
        self.velocity_x, self.velocity_y, self.velocity_z, self.IPS = 0, 0, 0, 0
        self.accel_drift_offset = 0
        self.last_time = time.time()
        self.start_time = time.time()       

        #self.run()

    def twos_complement(self, val, bits=16):
        """
        Converte um valor de 16 bits do sensor para número com sinal.

        Parâmetros:
        val (int): O valor a ser convertido.
        bits (int, opcional): O número de bits do valor. Padrão é 16.

        Retorna:
        int: O valor convertido para número com sinal.
        """
        if val & (1 << (bits - 1)):  
            val -= (1 << bits)
        return val

    def read_raw_data(self, addr):
        """Lê dois bytes do sensor e converte para um valor de 16 bits."""
        high = bus.read_byte_data(MPU6050_ADDR, addr)
        low = bus.read_byte_data(MPU6050_ADDR, addr + 1)
        value = (high << 8) | low
        return self.twos_complement(value)

    def acc_read_hpf(self):
        '''Read acceleration data and pass through the high pass filter'''

        # Leitura da aceleração (conversão, para g)
        accel_x = self.read_raw_data(0x3B) / ACCEL_SCALE
        accel_y = self.read_raw_data(0x3D) / ACCEL_SCALE
        accel_z = self.read_raw_data(0x3F) / ACCEL_SCALE

        # Aplicação do filtro passa-alta (remove gravidade)
        accel_x_hp = ALPHA * (self.accel_last_x + accel_x - self.accel_last_x)
        accel_y_hp = ALPHA * (self.accel_last_y + accel_y - self.accel_last_y)
        accel_z_hp = ALPHA * (self.accel_last_z + accel_z - self.accel_last_z)

        self.accel_last_x, self.accel_last_y, self.accel_last_z = accel_x_hp, accel_y_hp, accel_z_hp

        return accel_x_hp, accel_y_hp, accel_z_hp

    def read(self):
        return self.detect_impact()

    def detect_impact(self):
        '''Detect the impact in the equipament considering impact = value > IMPACT_THRESHOLD_G'''

        accel_x_hp, accel_y_hp, accel_z_hp = self.acc_read_hpf()

        # Calcula o tempo decorrido
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time

        # Cálculo da magnitude da aceleração para detectar impacto
        impact_magnitude = math.sqrt(accel_x_hp**2 + accel_y_hp**2 + accel_z_hp**2) # aceleração resultante
        impact_magnitude = impact_magnitude - self.accel_drift_offset # aplica offset 
        impact_magnitude = round(impact_magnitude,5) # arredonda  valor para 5 numeros após a virgula

        if impact_magnitude < HISTERESE_MINIMA and impact_magnitude > HISTERESE_MINIMA*-1: 
            impact_magnitude = 0

        #IPS = integral de G*386.088
        self.IPS += (impact_magnitude * IPS_CONVERSION) * dt
        self.IPS *= DAMPING_FACTOR
        self.IPS = max(self.IPS, 0) #nunca podera ser menor de 0
        self.IPS = round(self.IPS, 3) # arredonda  valor para 5 numeros após a virgula

        '''# Salva os valores no buffer
        self.accel_data.append(impact_magnitude)
        self.timestamps.append(current_time - self.start_time)
        self.IPS_data.append(self.IPS) #salva IPS em uma lista

        # Se o buffer for maior que 1000 amostras (10s com 1ms por amostra), limpar
        if len(self.accel_data) > 2000:
            self.accel_data.pop(0)
            self.timestamps.pop(0)
            self.IPS_data.pop(0)

        # Printa valores
        print(f"impact magnitude: {impact_magnitude}  - Impact Threshold: {IMPACT_THRESHOLD_G} - IPS: {self.IPS}")

        
        
        if impact_magnitude > IMPACT_THRESHOLD_G:
            velocity_magnitude = math.sqrt(self.velocity_x**2 + self.velocity_y**2 + self.velocity_z**2)
            #print(f"🔥 IMPACTO DETECTADO! Velocidade: {velocity_magnitude:.2f} IPS")'''

        time.sleep(INTEGRATION_TIME)
        return self.IPS, impact_magnitude
        return impact_magnitude > IMPACT_THRESHOLD_G

    def drift_correction(self):
        #print(f"Starting drift correction process. . .")
        self.accel_drift_offset = 0

        for i in range(200):
            accel_x_hp, accel_y_hp, accel_z_hp = self.acc_read_hpf()
            accel_hp = math.sqrt(accel_x_hp**2 + accel_y_hp**2 + accel_z_hp**2)
            self.accel_drift_offset += accel_hp

            if (i == 199):
                self.accel_drift_offset = self.accel_drift_offset / 200
                print(f"drift offset: {self.accel_drift_offset}")

    def run(self):
        '''Starts the acceleration reading and conversion into IPS, printing the data if impact = 1'''

        self.drift_correction()

        while True:
            impact = self.detect_impact()
            time.sleep(INTEGRATION_TIME)  # Amostragem a cada 1ms

            if impact:
                for i in range(1000):
                    self.detect_impact()
                    time.sleep(INTEGRATION_TIME)  # Amostragem a cada 1ms

                #print(f"dados:\n{self.accel_data}\n\n\n")
                #print(f"IPS data: {self.IPS_data}")
                sys.exit()

    def Start(self):
        try:
            print("Starting IPS drift correction")
            self.drift_correction()
            print("Done")
            return True
        except Exception as e:
            return False

                
if __name__ == '__main__':
    ##print("📡 Monitorando impactos...")
    #ips = IPS()
    pass
