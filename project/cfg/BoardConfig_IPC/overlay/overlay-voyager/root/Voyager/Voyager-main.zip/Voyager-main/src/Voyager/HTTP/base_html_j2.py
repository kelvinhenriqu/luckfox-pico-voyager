Base_html = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ title or "Voyager" }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --bg: #f8fafc;
            --container-bg: #fff;
            --text: #1e293b;
            --border: #e5e7eb;
            --radius: 14px;
            --shadow: 0 4px 24px rgba(0,0,0,0.07);
        }
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            margin: 0;
            padding: 0;
            color: var(--text);
        }
        .container {
            background: var(--container-bg);
            padding: 2.5rem 2rem;
            border-radius: var(--radius);
            max-width: 420px;
            margin: 48px auto;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }
        h1, h2 {
            color: var(--primary);
            margin-top: 0;
            font-weight: 700;
            letter-spacing: -1px;
        }
        a {
            color: var(--primary);
            text-decoration: none;
            transition: color 0.2s;
        }
        a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }
        .btn {
            background: linear-gradient(90deg, var(--primary), var(--primary-dark));
            color: #fff;
            padding: 0.75rem 1.5rem;
            margin-top: 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(99,102,241,0.08);
            transition: background 0.2s, box-shadow 0.2s;
            display: inline-block;
        }
        .btn:hover {
            background: linear-gradient(90deg, var(--primary-dark), var(--primary));
            box-shadow: 0 4px 16px rgba(99,102,241,0.13);
        }
        @media (max-width: 600px) {
            .container {
                max-width: 98vw;
                padding: 1.2rem 0.5rem;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        {% block content %}{% endblock %}
    </div>
</body>
</html>
'''